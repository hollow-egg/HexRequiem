package at.petrak.hexcasting.api.casting.circles;

import ;
import F;
import J;
import Z;
import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.misc.Result;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.utils.MediaHelper;
import at.petrak.hexcasting.common.items.magic.ItemCreativeUnlocker;
import at.petrak.hexcasting.common.lib.HexItems;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

import java.text.DecimalFormat;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/**
 * Default impl for an impetus, not tecnically necessary but I'm exposing it for ease of use
 * <p>
 * This does assume a great deal so you might have to re-implement a lot of this yourself if you
 * wanna do something wild and new
 */
public abstract class BlockEntityAbstractImpetus extends HexBlockEntity implements SidedInventory {
    private static final DecimalFormat DUST_AMOUNT = new DecimalFormat("###,###.##");
    private static final long MAX_CAPACITY = 9_000_000_000_000_000_000L;

    public static final String
        TAG_EXECUTION_STATE = "executor",
        TAG_MEDIA = "media",
        TAG_ERROR_MSG = "errorMsg",
        TAG_ERROR_DISPLAY = "errorDisplay",
        TAG_PIGMENT = "pigment";

    // We might try to load the executor in loadModData when the level doesn't exist yet,
    // so save the tag and load it lazy
    @Nullable NbtCompound lazyExecutionState;
    @Nullable
    protected CircleExecutionState executionState;

    protected long media = 0;

    // these are null together
    @Nullable
    protected Text displayMsg = null;
    @Nullable
    protected ItemStack displayItem = null;
    @Nullable
    protected FrozenPigment pigment = null;


    public BlockEntityAbstractImpetus(BlockEntityType<?> pType, BlockPos pWorldPosition, BlockState pBlockState) {
        super(pType, pWorldPosition, pBlockState);
    }

    public Direction getStartDirection() {
        return this.getCachedState().get(Properties.FACING);
    }

    @Nullable
    public Text getDisplayMsg() {
        return displayMsg;
    }

    public void clearDisplay() {
        this.displayMsg = null;
        this.displayItem = null;
        this.sync();
    }

    public void postDisplay(Text error, ItemStack display) {
        this.displayMsg = error;
        this.displayItem = display;
        this.sync();
    }

    public void postMishap(Text mishapDisplay) {
        this.postDisplay(mishapDisplay, new ItemStack(Items.MUSIC_DISC_11));
    }

    public void postPrint(Text printDisplay) {
        this.postDisplay(printDisplay, new ItemStack(Items.BOOK));
    }

    // Pull this out because we may need to call it both on startup and halfway thru
    public void postNoExits(BlockPos pos) {
        this.postDisplay(
            Text.translatable("hexcasting.tooltip.circle.no_exit",
                Text.literal(pos.toShortString()).formatted(Formatting.RED)),
            new ItemStack(Items.OAK_SIGN));
    }

    //region execution

    public void tickExecution() {
        if (this.world == null)
            return;

        this.markDirty();

        var state = this.getExecutionState();
        if (state == null) {
            return;
        }

        var shouldContinue = state.tick(this);

        if (!shouldContinue) {
            this.endExecution();
            this.executionState = null;
        } else
            this.world.scheduleBlockTick(this.getPos(), this.getCachedState().getBlock(), state.getTickSpeed());
    }

    public void endExecution() {
        if (this.executionState == null)
            return;

        this.executionState.endExecution(this);
    }

    /**
     * ONLY CALL THIS WHEN YOU KNOW THE WORLD EXISTS AND ON THE SERVER, lazy-loads it
     */
    public @Nullable CircleExecutionState getExecutionState() {
        if (this.world == null) {
            throw new IllegalStateException("didn't you read the doc comment, don't call this if the level is null");
        }

        if (this.executionState != null)
            return this.executionState;

        if (this.lazyExecutionState != null)
            this.executionState = CircleExecutionState.load(this.lazyExecutionState, (ServerWorld) this.world);

        return this.executionState;
    }

    public void startExecution(@Nullable ServerPlayerEntity player) {
        if (this.world == null)
            return; // TODO: error here?
        if (this.world.isClient)
            return; // TODO: error here?

        if (this.executionState != null) {
            return;
        }
        var result = CircleExecutionState.createNew(this, player);
        if (result.isErr()) {
            var errPos = result.unwrapErr();
            if (errPos == null) {
                ICircleComponent.sfx(this.getPos(), this.getCachedState(), this.world, null, false);
                this.postNoExits(this.getPos());
            } else {
                ICircleComponent.sfx(errPos, this.world.getBlockState(errPos), this.world, null, false);
                this.postDisplay(Text.translatable("hexcasting.tooltip.circle.no_closure",
                        Text.literal(errPos.toShortString()).formatted(Formatting.RED)),
                    new ItemStack(Items.LEAD));
            }

            return;
        }
        this.executionState = result.unwrap();

        this.clearDisplay();
        var serverLevel = (ServerWorld) this.world;
        serverLevel.scheduleBlockTick(this.getPos(), this.getCachedState().getBlock(),
            this.executionState.getTickSpeed());
        serverLevel.setBlockState(this.getPos(),
            this.getCachedState().with(BlockCircleComponent.ENERGIZED, true));
    }

    @Contract(pure = true)
    protected static Box getBounds(List<BlockPos> poses) {
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;

        for (var pos : poses) {
            if (pos.getX() < minX) {
                minX = pos.getX();
            }
            if (pos.getY() < minY) {
                minY = pos.getY();
            }
            if (pos.getZ() < minZ) {
                minZ = pos.getZ();
            }
            if (pos.getX() > maxX) {
                maxX = pos.getX();
            }
            if (pos.getY() > maxY) {
                maxY = pos.getY();
            }
            if (pos.getZ() > maxZ) {
                maxZ = pos.getZ();
            }
        }

        return new Box(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1);
    }

    //endregion

    //region media handling

    public long getMedia() {
        return this.media;
    }

    public void setMedia(long media) {
        this.media = media;
        sync();
    }

    public long extractMediaFromInsertedItem(ItemStack stack, boolean simulate) {
        if (this.media < 0) {
            return 0;
        }
        return MediaHelper.extractMedia(stack, remainingMediaCapacity(), true, simulate);
    }

    public void insertMedia(ItemStack stack) {
        if (getMedia() >= 0 && !stack.isEmpty() && stack.getItem() == HexItems.CREATIVE_UNLOCKER) {
            setInfiniteMedia();
            stack.decrement(1);
        } else {
            var mediamount = extractMediaFromInsertedItem(stack, false);
            if (mediamount > 0) {
                this.media = Math.min(mediamount + media, MAX_CAPACITY);
                this.sync();
            }
        }
    }

    public void setInfiniteMedia() {
        this.media = -1;
        this.sync();
    }

    public long remainingMediaCapacity() {
        if (this.media < 0) {
            return 0;
        }
        return Math.max(0, MAX_CAPACITY - this.media);
    }

    //endregion


    public FrozenPigment getPigment() {
        if (pigment != null)
            return pigment;
        if (executionState != null && executionState.casterPigment != null)
            return executionState.casterPigment;
        return FrozenPigment.DEFAULT.get();
    }

    public @Nullable FrozenPigment setPigment(@Nullable FrozenPigment pigment) {
        this.pigment = pigment;
        return this.pigment;
    }

    @Override
    protected void saveModData(NbtCompound tag) {
        if (this.executionState != null) {
            tag.put(TAG_EXECUTION_STATE, this.executionState.save());
        }

        tag.putLong(TAG_MEDIA, this.media);

        if (this.displayMsg != null && this.displayItem != null) {
            tag.putString(TAG_ERROR_MSG, Text.Serializer.toJson(this.displayMsg));
            var itemTag = new NbtCompound();
            this.displayItem.writeNbt(itemTag);
            tag.put(TAG_ERROR_DISPLAY, itemTag);
        }
        if (this.pigment != null)
            tag.put(TAG_PIGMENT, this.pigment.serializeToNBT());
    }

    @Override
    protected void loadModData(NbtCompound tag) {
        this.executionState = null;
        if (tag.contains(TAG_EXECUTION_STATE, NbtElement.COMPOUND_TYPE)) {
            this.lazyExecutionState = tag.getCompound(TAG_EXECUTION_STATE);
        } else {
            this.lazyExecutionState = null;
        }

        if (tag.contains(TAG_MEDIA, NbtElement.LONG_TYPE)) {
            this.media = tag.getLong(TAG_MEDIA);
        }

        if (tag.contains(TAG_ERROR_MSG, NbtElement.STRING_TYPE) && tag.contains(TAG_ERROR_DISPLAY, NbtElement.COMPOUND_TYPE)) {
            var msg = Text.Serializer.fromJson(tag.getString(TAG_ERROR_MSG));
            var display = ItemStack.fromNbt(tag.getCompound(TAG_ERROR_DISPLAY));
            this.displayMsg = msg;
            this.displayItem = display;
        } else {
            this.displayMsg = null;
            this.displayItem = null;
        }
        if (tag.contains(TAG_PIGMENT, NbtElement.COMPOUND_TYPE))
            this.pigment = FrozenPigment.fromNBT(tag.getCompound(TAG_PIGMENT));
    }

    public void applyScryingLensOverlay(List<Pair<ItemStack, Text>> lines,
        BlockState state, BlockPos pos, PlayerEntity observer, World world, Direction hitFace) {
        if (world.getBlockEntity(pos) instanceof BlockEntityAbstractImpetus beai) {
            if (beai.getMedia() < 0) {
                lines.add(new Pair<>(new ItemStack(HexItems.AMETHYST_DUST), ItemCreativeUnlocker.infiniteMedia(world)));
            } else {
                var dustCount = (float) beai.getMedia() / (float) MediaConstants.DUST_UNIT;
                var dustCmp = Text.translatable("hexcasting.tooltip.media",
                    DUST_AMOUNT.format(dustCount));
                lines.add(new Pair<>(new ItemStack(HexItems.AMETHYST_DUST), dustCmp));
            }

            if (this.displayMsg != null && this.displayItem != null) {
                lines.add(new Pair<>(this.displayItem, this.displayMsg));
            }
        }
    }

    //region music

    protected int semitoneFromScale(int note) {
        var blockBelow = this.world.getBlockState(this.getPos().down());
        var scale = MAJOR_SCALE;
        if (blockBelow.isOf(Blocks.CRYING_OBSIDIAN)) {
            scale = MINOR_SCALE;
        } else if (blockBelow.isIn(BlockTags.DOORS) || blockBelow.isIn(BlockTags.TRAPDOORS)) {
            scale = DORIAN_SCALE;
        } else if (blockBelow.isOf(Blocks.PISTON) || blockBelow.isOf(Blocks.STICKY_PISTON)) {
            scale = MIXOLYDIAN_SCALE;
        } else if (blockBelow.isOf(Blocks.BLUE_WOOL)
            || blockBelow.isOf(Blocks.BLUE_CONCRETE) || blockBelow.isOf(Blocks.BLUE_CONCRETE_POWDER)
            || blockBelow.isOf(Blocks.BLUE_TERRACOTTA) || blockBelow.isOf(Blocks.BLUE_GLAZED_TERRACOTTA)
            || blockBelow.isOf(Blocks.BLUE_STAINED_GLASS) || blockBelow.isOf(Blocks.BLUE_STAINED_GLASS_PANE)) {
            scale = BLUES_SCALE;
        } else if (blockBelow.isOf(Blocks.BONE_BLOCK)) {
            scale = BAD_TIME;
        } else if (blockBelow.isOf(Blocks.COMPOSTER)) {
            scale = SUSSY_BAKA;
        }

        note = MathHelper.clamp(note, 0, scale.length - 1);
        return scale[note];
    }

    // this is a good use of my time
    private static final int[] MAJOR_SCALE = {0, 2, 4, 5, 7, 9, 11, 12};
    private static final int[] MINOR_SCALE = {0, 2, 3, 5, 7, 8, 11, 12};
    private static final int[] DORIAN_SCALE = {0, 2, 3, 5, 7, 9, 10, 12};
    private static final int[] MIXOLYDIAN_SCALE = {0, 2, 4, 5, 7, 9, 10, 12};
    private static final int[] BLUES_SCALE = {0, 3, 5, 6, 7, 10, 12};
    private static final int[] BAD_TIME = {0, 0, 12, 7, 6, 5, 3, 0, 3, 5};
    private static final int[] SUSSY_BAKA = {5, 8, 10, 11, 10, 8, 5, 3, 7, 5};

    //endregion

    //region item handler contract stuff
    private static final int[] SLOTS = {0};

    @Override
    public int[] getAvailableSlots(Direction var1) {
        return SLOTS;
    }

    @Override
    public boolean canInsert(int index, ItemStack stack, @Nullable Direction dir) {
        return this.isValid(index, stack);
    }

    @Override
    public boolean canExtract(int var1, ItemStack var2, Direction var3) {
        return false;
    }

    @Override
    public int size() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public ItemStack getStack(int index) {
        return ItemStack.EMPTY.copy();
    }

    @Override
    public ItemStack removeStack(int index, int count) {
        return ItemStack.EMPTY.copy();
    }

    @Override
    public ItemStack removeStack(int index) {
        return ItemStack.EMPTY.copy();
    }

    @Override
    public void setStack(int index, ItemStack stack) {
        insertMedia(stack);
    }

    @Override
    public boolean canPlayerUse(PlayerEntity player) {
        return false;
    }

    @Override
    public void clear() {
        // NO-OP
    }

    @Override
    public boolean isValid(int index, ItemStack stack) {
        if (remainingMediaCapacity() == 0) {
            return false;
        }

        if (stack.isOf(HexItems.CREATIVE_UNLOCKER)) {
            return true;
        }

        var mediamount = extractMediaFromInsertedItem(stack, true);
        return mediamount > 0;
    }

    //endregion
}
