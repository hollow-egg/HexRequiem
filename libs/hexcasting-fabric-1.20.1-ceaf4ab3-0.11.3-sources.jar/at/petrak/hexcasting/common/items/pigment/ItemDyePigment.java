package at.petrak.hexcasting.common.items.pigment;

import at.petrak.hexcasting.api.item.PigmentItem;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import java.util.UUID;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.Vec3d;

public class ItemDyePigment extends Item implements PigmentItem {
    private final DyeColor dyeColor;

    public ItemDyePigment(DyeColor dyeColor, Settings pProperties) {
        super(pProperties);
        this.dyeColor = dyeColor;
    }

    public DyeColor getDyeColor() {
        return dyeColor;
    }

    @Override
    public ColorProvider provideColor(ItemStack stack, UUID owner) {
        return colorProvider;
    }

    protected MyColorProvider colorProvider = new MyColorProvider();

    protected class MyColorProvider extends ColorProvider {
        @Override
        protected int getRawColor(float time, Vec3d position) {
            return dyeColor.getSignColor();
        }
    }
}
