package at.petrak.hexcasting.fabric.datagen;

import at.petrak.hexcasting.datagen.IXplatConditionsBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.resource.conditions.v1.ConditionJsonProvider;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.fabricmc.fabric.impl.datagen.FabricDataGenHelper;
import net.minecraft.advancement.criterion.CriterionConditions;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.item.Item;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class HexFabricConditionsBuilder implements IXplatConditionsBuilder {
    private final List<ConditionJsonProvider> conditions = new ArrayList<>();
    private final CraftingRecipeJsonBuilder parent;

    public HexFabricConditionsBuilder(CraftingRecipeJsonBuilder parent) {
        this.parent = parent;
    }

    @Override
    public IXplatConditionsBuilder whenModLoaded(String modid) {
        conditions.add(DefaultResourceConditions.allModsLoaded(modid));
        return this;
    }

    @Override
    public IXplatConditionsBuilder whenModMissing(String modid) {
        conditions.add(DefaultResourceConditions.not(DefaultResourceConditions.allModsLoaded(modid)));
        return this;
    }

    @Override
    public CraftingRecipeJsonBuilder criterion(@NotNull String string, @NotNull CriterionConditions criterionTriggerInstance) {
        return parent.criterion(string, criterionTriggerInstance);
    }

    @Override
    public CraftingRecipeJsonBuilder group(@Nullable String string) {
        return parent.group(string);
    }

    @Override
    public Item getOutputItem() {
        return parent.getOutputItem();
    }

    @Override
    @SuppressWarnings("UnstableApiUsage")
    public void offerTo(@NotNull Consumer<RecipeJsonProvider> consumer, @NotNull Identifier resourceLocation) {
        Consumer<RecipeJsonProvider> withConditions = json -> {
            FabricDataGenHelper.addConditions(json, conditions.toArray(new ConditionJsonProvider[0]));

            consumer.accept(new RecipeJsonProvider() {
                @Override
                public void serialize(@NotNull JsonObject jsonObject) {
                    json.serialize(jsonObject);
                    ConditionJsonProvider[] conditions = FabricDataGenHelper.consumeConditions(json);
                    ConditionJsonProvider.write(jsonObject, conditions);
                }

                @Override
                public Identifier getRecipeId() {
                    return json.getRecipeId();
                }

                @Override
                public RecipeSerializer<?> getSerializer() {
                    return json.getSerializer();
                }

                @Nullable
                @Override
                public JsonObject toAdvancementJson() {
                    return json.toAdvancementJson();
                }

                @Nullable
                @Override
                public Identifier getAdvancementId() {
                    return json.getAdvancementId();
                }
            });
        };

        parent.offerTo(withConditions, resourceLocation);
    }
}
