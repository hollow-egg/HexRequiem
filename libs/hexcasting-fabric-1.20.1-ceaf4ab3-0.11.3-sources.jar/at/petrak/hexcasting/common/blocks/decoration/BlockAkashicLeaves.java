package at.petrak.hexcasting.common.blocks.decoration;

import at.petrak.hexcasting.annotations.SoftImplement;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;

public class BlockAkashicLeaves extends LeavesBlock {
    public BlockAkashicLeaves(Settings props) {
        super(props);
    }

    @SoftImplement("forge")
    public boolean isFlammable(BlockState state, BlockView level, BlockPos pos, Direction direction) {
        return true;
    }

    @SoftImplement("forge")
    public int getFlammability(BlockState state, BlockView level, BlockPos pos, Direction direction) {
        return 60;
    }

    @SoftImplement("forge")
    public int getFireSpreadSpeed(BlockState state, BlockView level, BlockPos pos, Direction direction) {
        return 30;
    }
}
