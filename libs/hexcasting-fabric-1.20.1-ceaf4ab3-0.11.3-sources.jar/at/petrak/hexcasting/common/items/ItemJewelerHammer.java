package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.common.lib.HexItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.util.math.BlockPos;

public class ItemJewelerHammer extends PickaxeItem {
    public ItemJewelerHammer(ToolMaterial tier, int damageMod, float attackSpeedMod, Settings props) {
        super(tier, damageMod, attackSpeedMod, props);
    }

    public static boolean shouldFailToBreak(PlayerEntity player, BlockState state, BlockPos pos) {
        ItemStack stack = player.getMainHandStack();
        return stack.isOf(HexItems.JEWELER_HAMMER) && Block.isShapeFullCube(state.getOutlineShape(player.getWorld(), pos));
    }
}
