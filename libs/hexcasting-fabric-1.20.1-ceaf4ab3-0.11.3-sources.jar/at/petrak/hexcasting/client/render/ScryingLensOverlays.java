package at.petrak.hexcasting.client.render;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.client.ScryingLensOverlayRegistry;
import at.petrak.hexcasting.common.blocks.akashic.BlockEntityAkashicBookshelf;
import at.petrak.hexcasting.common.lib.HexBlocks;
import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ComparatorBlock;
import net.minecraft.block.MapColor;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.PoweredRailBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.enums.ComparatorMode;
import net.minecraft.block.enums.Instrument;
import net.minecraft.block.enums.RailShape;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.level.block.*;
import java.util.function.UnaryOperator;

public class ScryingLensOverlays {
    public static void addScryingLensStuff() {
        ScryingLensOverlayRegistry.addPredicateDisplayer(
            (state, pos, observer, world, direction) -> state.getBlock() instanceof BlockAbstractImpetus,
            (lines, state, pos, observer, world, direction) -> {
                if (world.getBlockEntity(pos) instanceof BlockEntityAbstractImpetus beai) {
                    beai.applyScryingLensOverlay(lines, state, pos, observer, world, direction);
                }
            });

        ScryingLensOverlayRegistry.addDisplayer(Blocks.NOTE_BLOCK,
            (lines, state, pos, observer, world, direction) -> {
                int note = state.get(NoteBlock.NOTE);

                float rCol = Math.max(0.0F, MathHelper.sin((note / 24F + 0.0F) * MathHelper.TAU) * 0.65F + 0.35F);
                float gCol = Math.max(0.0F, MathHelper.sin((note / 24F + 0.33333334F) * MathHelper.TAU) * 0.65F + 0.35F);
                float bCol = Math.max(0.0F, MathHelper.sin((note / 24F + 0.6666667F) * MathHelper.TAU) * 0.65F + 0.35F);

                int noteColor = 0xFF_000000 | MathHelper.packRgb(rCol, gCol, bCol);

                var instrument = state.get(NoteBlock.INSTRUMENT);

                lines.add(new Pair<>(
                    new ItemStack(Items.MUSIC_DISC_CHIRP),
                    Text.literal(String.valueOf(instrument.ordinal()))
                        .styled(color(instrumentColor(instrument)))));
                lines.add(new Pair<>(
                    new ItemStack(Items.NOTE_BLOCK),
                    Text.literal(String.valueOf(note))
                        .styled(color(noteColor))));
            });

        ScryingLensOverlayRegistry.addDisplayer(HexBlocks.AKASHIC_BOOKSHELF,
            (lines, state, pos, observer, world, direction) -> {
                if (world.getBlockEntity(pos) instanceof BlockEntityAkashicBookshelf tile) {
                    var iotaTag = tile.getIotaTag();
                    if (iotaTag != null) {
                        var display = IotaType.getDisplay(iotaTag);
                        lines.add(new Pair<>(new ItemStack(Items.BOOK), display));
                    }
                }
            });

        ScryingLensOverlayRegistry.addDisplayer(Blocks.COMPARATOR,
            (lines, state, pos, observer, world, direction) -> {
                int comparatorValue = state.getComparatorOutput(world, pos);
                lines.add(new Pair<>(
                    new ItemStack(Items.REDSTONE),
                    Text.literal(comparatorValue == -1 ? "" : String.valueOf(comparatorValue))
                        .styled(redstoneColor(comparatorValue))));

                boolean compare = state.get(ComparatorBlock.MODE) == ComparatorMode.COMPARE;

                lines.add(new Pair<>(
                    new ItemStack(Items.REDSTONE_TORCH),
                    Text.literal(compare ? ">=" : "-")
                        .styled(redstoneColor(compare ? 0 : 15))));
            });

        ScryingLensOverlayRegistry.addDisplayer(Blocks.POWERED_RAIL,
            (lines, state, pos, observer, world, direction) -> {
                int power = getPoweredRailStrength(world, pos, state);
                lines.add(new Pair<>(
                    new ItemStack(Items.POWERED_RAIL),
                    Text.literal(String.valueOf(power))
                        .styled(redstoneColor(power, 9))));
            });

        ScryingLensOverlayRegistry.addDisplayer(Blocks.REPEATER,
            (lines, state, pos, observer, world, direction) -> lines.add(new Pair<>(
                new ItemStack(Items.CLOCK),
                Text.literal(String.valueOf(state.get(RepeaterBlock.DELAY)))
                    .formatted(Formatting.YELLOW))));

        ScryingLensOverlayRegistry.addPredicateDisplayer(
            (state, pos, observer, world, direction) -> state.emitsRedstonePower() && !state.isOf(
                Blocks.COMPARATOR),
            (lines, state, pos, observer, world, direction) -> {
                int signalStrength = 0;
                if (state.getBlock() instanceof RedstoneWireBlock) {
                    signalStrength = state.get(RedstoneWireBlock.POWER);
                } else {
                    for (Direction dir : Direction.values()) {
                        signalStrength = Math.max(signalStrength, state.getWeakRedstonePower(world, pos, dir));
                    }
                }

                lines.add(0, new Pair<>(
                    new ItemStack(Items.REDSTONE),
                    Text.literal(String.valueOf(signalStrength))
                        .styled(redstoneColor(signalStrength))));
            });
    }

    private static int getPoweredRailStrength(World level, BlockPos pos, BlockState state) {
        if (level.isReceivingRedstonePower(pos))
            return 9;
        int positiveValue = findPoweredRailSignal(level, pos, state, true, 0);
        int negativeValue = findPoweredRailSignal(level, pos, state, false, 0);
        return Math.max(positiveValue, negativeValue);
    }

    // Copypasta from PoweredRailBlock.class
    private static int findPoweredRailSignal(World level, BlockPos pos, BlockState state, boolean travelPositive,
        int depth) {
        if (depth >= 8) {
            return 0;
        } else {
            int x = pos.getX();
            int y = pos.getY();
            int z = pos.getZ();
            boolean descending = true;
            RailShape shape = state.get(PoweredRailBlock.SHAPE);
            switch (shape) {
                case NORTH_SOUTH:
                    if (travelPositive) {
                        ++z;
                    } else {
                        --z;
                    }
                    break;
                case EAST_WEST:
                    if (travelPositive) {
                        --x;
                    } else {
                        ++x;
                    }
                    break;
                case ASCENDING_EAST:
                    if (travelPositive) {
                        --x;
                    } else {
                        ++x;
                        ++y;
                        descending = false;
                    }

                    shape = RailShape.EAST_WEST;
                    break;
                case ASCENDING_WEST:
                    if (travelPositive) {
                        --x;
                        ++y;
                        descending = false;
                    } else {
                        ++x;
                    }

                    shape = RailShape.EAST_WEST;
                    break;
                case ASCENDING_NORTH:
                    if (travelPositive) {
                        ++z;
                    } else {
                        --z;
                        ++y;
                        descending = false;
                    }

                    shape = RailShape.NORTH_SOUTH;
                    break;
                case ASCENDING_SOUTH:
                    if (travelPositive) {
                        ++z;
                        ++y;
                        descending = false;
                    } else {
                        --z;
                    }

                    shape = RailShape.NORTH_SOUTH;
            }

            int power = getPowerFromRail(level, new BlockPos(x, y, z), travelPositive, depth,
                shape);

            if (power > 0) {
                return power;
            } else if (descending) {
                return getPowerFromRail(level, new BlockPos(x, y - 1, z), travelPositive, depth,
                    shape);
            } else {
                return 0;
            }
        }
    }


    private static UnaryOperator<Style> color(int color) {
        return (style) -> style.withColor(TextColor.fromRgb(color));
    }

    private static UnaryOperator<Style> redstoneColor(int power) {
        return redstoneColor(power, 15);
    }

    private static UnaryOperator<Style> redstoneColor(int power, int max) {
        return color(RedstoneWireBlock.getWireColor(MathHelper.clamp((power * max) / 15, 0, 15)));
    }

    private static int instrumentColor(Instrument instrument) {
        return switch (instrument) {
            case BASEDRUM -> MapColor.STONE_GRAY.color;
            case SNARE, XYLOPHONE, PLING -> MapColor.PALE_YELLOW.color;
            case HAT -> MapColor.OFF_WHITE.color;
            case BASS -> MapColor.OAK_TAN.color;
            case FLUTE -> MapColor.LIGHT_BLUE_GRAY.color;
            case BELL -> MapColor.GOLD.color;
            case GUITAR -> MapColor.WHITE_GRAY.color;
            case CHIME -> MapColor.PALE_PURPLE.color;
            case IRON_XYLOPHONE -> MapColor.IRON_GRAY.color;
            case COW_BELL -> MapColor.BROWN.color;
            case DIDGERIDOO -> MapColor.ORANGE.color;
            case BIT -> MapColor.EMERALD_GREEN.color;
            case BANJO -> MapColor.YELLOW.color;
            default -> -1;
        };
    }

    private static int getPowerFromRail(World level, BlockPos pos, boolean travelPositive, int depth, RailShape shape) {
        BlockState otherState = level.getBlockState(pos);
        if (!otherState.isOf(Blocks.POWERED_RAIL)) {
            return 0;
        } else {
            RailShape otherShape = otherState.get(PoweredRailBlock.SHAPE);
            if (shape == RailShape.EAST_WEST && (otherShape == RailShape.NORTH_SOUTH || otherShape == RailShape.ASCENDING_NORTH || otherShape == RailShape.ASCENDING_SOUTH)) {
                return 0;
            } else if (shape == RailShape.NORTH_SOUTH && (otherShape == RailShape.EAST_WEST || otherShape == RailShape.ASCENDING_EAST || otherShape == RailShape.ASCENDING_WEST)) {
                return 0;
            } else if (otherState.get(PoweredRailBlock.POWERED)) {
                return level.isReceivingRedstonePower(pos) ? 8 - depth : findPoweredRailSignal(level, pos, otherState,
                    travelPositive, depth + 1);
            } else {
                return 0;
            }
        }
    }
}
