package at.petrak.hexcasting.api.casting.eval.env;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.advancements.HexAdvancementTriggers;
import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.eval.CastResult;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.eval.MishapEnvironment;
import at.petrak.hexcasting.api.casting.eval.sideeffects.OperatorSideEffect;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.api.mod.HexStatistics;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.api.utils.MediaHelper;
import at.petrak.hexcasting.common.lib.HexAttributes;
import at.petrak.hexcasting.common.lib.HexDamageTypes;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import D;
import I;
import J;

public abstract class PlayerBasedCastEnv extends CastingEnvironment {
    public static final double DEFAULT_AMBIT_RADIUS = 32.0;
    private double ambitRadius;
    public static final double DEFAULT_SENTINEL_RADIUS = 16.0;
    private double sentinelRadius;

    protected final ServerPlayerEntity caster;
    protected final Hand castingHand;

    protected PlayerBasedCastEnv(ServerPlayerEntity caster, Hand castingHand) {
        super(caster.getServerWorld());
        this.caster = caster;
        this.castingHand = castingHand;
        this.ambitRadius = caster.getAttributeValue(HexAttributes.AMBIT_RADIUS);
        this.sentinelRadius = caster.getAttributeValue(HexAttributes.SENTINEL_RADIUS);
    }

    @Override
    public LivingEntity getCastingEntity() {
        return this.caster;
    }

    @Override
    public ServerPlayerEntity getCaster() {
        return this.caster;
    }

    @Override
    public void postExecution(CastResult result) {
        super.postExecution(result);

        for (var sideEffect : result.getSideEffects()) {
            if (sideEffect instanceof OperatorSideEffect.DoMishap doMishap) {
                this.sendMishapMsgToPlayer(doMishap);
            }
        }
        if (this.caster != null){
            double ambitAttribute = this.caster.getAttributeValue(HexAttributes.AMBIT_RADIUS);
            if (this.ambitRadius != ambitAttribute){
                this.ambitRadius = ambitAttribute;
            }
            double sentinelAttribute = this.caster.getAttributeValue(HexAttributes.SENTINEL_RADIUS);
            if (this.sentinelRadius != sentinelAttribute){
                this.sentinelRadius = sentinelAttribute;
            }
        }
    }

    @Override
    protected List<ItemStack> getUsableStacks(StackDiscoveryMode mode) {
        return getUsableStacksForPlayer(mode, castingHand, caster);
    }

    @Override
    protected List<HeldItemInfo> getPrimaryStacks() {
        return getPrimaryStacksForPlayer(this.castingHand, this.caster);
    }

    public double getAmbitRadius() {
        return this.ambitRadius;
    }

    public double getSentinelRadius(){
        return this.sentinelRadius;
    }

    @Override
    public boolean replaceItem(Predicate<ItemStack> stackOk, ItemStack replaceWith, @Nullable Hand hand) {
        return replaceItemForPlayer(stackOk, replaceWith, hand, this.caster);
    }

    @Override
    public boolean isVecInRangeEnvironment(Vec3d vec) {
        var sentinel = HexAPI.instance().getSentinel(this.caster);
        if (sentinel != null
            && sentinel.extendsRange()
            && this.caster.getWorld().getRegistryKey() == sentinel.dimension()
                // adding 0.00000000001 to avoid machine precision errors at specific angles
                && vec.squaredDistanceTo(sentinel.position()) <= sentinelRadius * sentinelRadius + 0.00000000001
        ) {
            return true;
        }

        return vec.squaredDistanceTo(this.caster.getPos()) <= ambitRadius * ambitRadius + 0.00000000001;
    }

    @Override
    public boolean hasEditPermissionsAtEnvironment(BlockPos pos) {
        return this.caster.interactionManager.getGameMode() != GameMode.ADVENTURE && this.world.canPlayerModifyAt(this.caster, pos);
    }

    /**
     * Search the player's inventory for media ADs and use them.
     */
    protected long extractMediaFromInventory(long costLeft, boolean allowOvercast, boolean simulate) {
        List<ADMediaHolder> sources = MediaHelper.scanPlayerForMediaStuff(this.caster);

        var startCost = costLeft;

        for (var source : sources) {
            var found = MediaHelper.extractMedia(source, costLeft, false, simulate);
            costLeft -= found;
            if (costLeft <= 0) {
                break;
            }
        }

        if (costLeft > 0 && allowOvercast) {
            double mediaToHealth = HexConfig.common().mediaToHealthRate();
            double healthToRemove = Math.max(costLeft / mediaToHealth, 0.5);
            if (simulate) {
                long simulatedRemovedMedia = MathHelper.ceil(Math.min(this.caster.getHealth(), healthToRemove) * mediaToHealth);
                if (this.caster.isInvulnerableTo(this.caster.getDamageSources().create(HexDamageTypes.OVERCAST))) {
                    simulatedRemovedMedia = 0;
                }
                costLeft -= simulatedRemovedMedia;
            } else {
                var mediaAbleToCastFromHP = this.caster.getHealth() * mediaToHealth;

                Mishap.trulyHurt(this.caster, this.caster.getDamageSources().create(HexDamageTypes.OVERCAST), (float) healthToRemove);

                var actuallyTaken = MathHelper.ceil(mediaAbleToCastFromHP - (this.caster.getHealth() * mediaToHealth));

                HexAdvancementTriggers.OVERCAST_TRIGGER.trigger(this.caster, actuallyTaken);
                this.caster.increaseStat(HexStatistics.MEDIA_OVERCAST, actuallyTaken);

                costLeft -= actuallyTaken;
            }
        }

        if (!simulate) {
            this.caster.increaseStat(HexStatistics.MEDIA_USED, (int) (startCost - costLeft));
            HexAdvancementTriggers.SPEND_MEDIA_TRIGGER.trigger(
                    this.caster,
                    startCost - costLeft,
                    costLeft < 0 ? -costLeft : 0
            );
        }

        return costLeft;
    }

    protected boolean canOvercast() {
        var adv = this.world.getServer().getAdvancementLoader().get(modLoc("y_u_no_cast_angy"));
        var advs = this.caster.getAdvancementTracker();
        return advs.getProgress(adv).isDone();
    }

    @Override
    public @Nullable FrozenPigment setPigment(@Nullable FrozenPigment pigment) {
        return IXplatAbstractions.INSTANCE.setPigment(caster, pigment);
    }

    @Override
    public void produceParticles(ParticleSpray particles, FrozenPigment pigment) {
        particles.sprayParticles(this.world, pigment);
    }

    @Override
    public Vec3d mishapSprayPos() {
        return this.caster.getPos();
    }

    @Override
    public MishapEnvironment getMishapEnvironment() {
        return new PlayerBasedMishapEnv(this.caster);
    }

    protected void sendMishapMsgToPlayer(OperatorSideEffect.DoMishap mishap) {
        var msg = mishap.getMishap().errorMessageWithName(this, mishap.getErrorCtx());
        if (msg != null) {
            this.caster.sendMessage(msg);
        }
    }

    @Override
    protected boolean isCreativeMode() {
        // not sure what the diff between this and isCreative() is
        return this.caster.getAbilities().creativeMode;
    }

    @Override
    public void printMessage(Text message) {
        caster.sendMessage(message);
    }
}
