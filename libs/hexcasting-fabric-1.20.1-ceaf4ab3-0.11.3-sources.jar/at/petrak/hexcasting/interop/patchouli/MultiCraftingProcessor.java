/*
 * This class is distributed as part of the Botania Mod.
 * Get the Source Code in github:
 * https://github.com/Vazkii/Botania
 *
 * Botania is Open Source and distributed under the
 * Botania License: http://botaniamod.net/license.php
 */
package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.api.HexAPI;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.world.World;

public class MultiCraftingProcessor implements IComponentProcessor {
    private List<CraftingRecipe> recipes;
    private boolean shapeless = true;
    private int longestIngredientSize = 0;
    private boolean hasCustomHeading;

    @Override
    public void setup(World level, IVariableProvider vars) {
        List<String> names = vars.get("recipes").asStream().map(IVariable::asString).collect(Collectors.toList());
        this.recipes = new ArrayList<>();
        for (String name : names) {
            CraftingRecipe recipe = PatchouliUtils.getRecipe(RecipeType.CRAFTING, new Identifier(name));
            if (recipe != null) {
                recipes.add(recipe);
                if (shapeless) {
                    shapeless = !(recipe instanceof ShapedRecipe);
                }
                for (Ingredient ingredient : recipe.getIngredients()) {
                    int size = ingredient.getMatchingStacks().length;
                    if (longestIngredientSize < size) {
                        longestIngredientSize = size;
                    }
                }
            } else {
                HexAPI.LOGGER.warn("Missing crafting recipe " + name);
            }
        }
        this.hasCustomHeading = vars.has("heading");
    }

    @Override
    public IVariable process(World level, String key) {
        if (recipes.isEmpty()) {
            return null;
        }
        if (key.equals("heading")) {
            if (!hasCustomHeading) {
                return IVariable.from(recipes.get(0).getOutput(level.getRegistryManager()).getName());
            }
            return null;
        }
        if (key.startsWith("input")) {
            int index = Integer.parseInt(key.substring(5)) - 1;
            int shapedX = index % 3;
            int shapedY = index / 3;
            List<Ingredient> ingredients = new ArrayList<>();
            for (CraftingRecipe recipe : recipes) {
                if (recipe instanceof ShapedRecipe shaped) {
                    if (shaped.getWidth() < shapedX + 1) {
                        ingredients.add(Ingredient.EMPTY);
                    } else {
                        int realIndex = index - (shapedY * (3 - shaped.getWidth()));
                        DefaultedList<Ingredient> list = recipe.getIngredients();
                        ingredients.add(list.size() > realIndex ? list.get(realIndex) : Ingredient.EMPTY);
                    }

                } else {
                    DefaultedList<Ingredient> list = recipe.getIngredients();
                    ingredients.add(list.size() > index ? list.get(index) : Ingredient.EMPTY);
                }
            }
            return PatchouliUtils.interweaveIngredients(ingredients, longestIngredientSize);
        }
        if (key.equals("output")) {
            return IVariable.wrapList(
                recipes.stream().map(recipe -> recipe.getOutput(level.getRegistryManager())).map(IVariable::from).collect(Collectors.toList()));
        }
        if (key.equals("shapeless")) {
            return IVariable.wrap(shapeless);
        }
        return null;
    }
}
