package at.petrak.hexcasting.mixin.client;

import at.petrak.hexcasting.api.client.ClientRenderHelper;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class MixinPlayerRenderer {
    @Inject(method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("HEAD"))
    public void hex$onRender(AbstractClientPlayerEntity player, float $$1, float pticks, MatrixStack ps, VertexConsumerProvider bufferSource, int $$5, CallbackInfo ci) {
        ClientRenderHelper.renderCastingStack(ps, player, pticks);
    }
}
