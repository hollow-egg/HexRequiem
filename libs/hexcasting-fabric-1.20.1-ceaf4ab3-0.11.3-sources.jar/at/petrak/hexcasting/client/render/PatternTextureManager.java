package at.petrak.hexcasting.client.render;

import java.awt.Rectangle;
import java.awt.geom.Line2D;
import java.awt.geom.Line2D.Float;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Pair;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;

public class PatternTextureManager {

    //TODO: remove if not needed anymore for comparison
    public static boolean useTextures = true;
    public static int repaintIndex = 0;

    private static final ConcurrentMap<String, Map<String, Identifier>> patternTexturesToAdd = new ConcurrentHashMap<>();
    private static final Set<String> inProgressPatterns = new HashSet<>();
    // basically newCachedThreadPool, but with a max pool size
    private static final ExecutorService executor = new ThreadPoolExecutor(0, 16, 60L, TimeUnit.SECONDS, new LinkedBlockingDeque<>());

    private static final HashMap<String, Map<String, Identifier>> patternTextures = new HashMap<>();

    public static Optional<Map<String, Identifier>> getTextures(HexPatternLike patternlike, PatternSettings patSets, double seed, int resPerUnit) {
        String patCacheKey = patSets.getCacheKey(patternlike, seed) + "_" + resPerUnit;

        // move textures from concurrent map to normal hashmap as needed
        if (patternTexturesToAdd.containsKey(patCacheKey)) {
            var patternTexture = patternTexturesToAdd.remove(patCacheKey);
            var oldPatternTexture = patternTextures.put(patCacheKey, patternTexture);
            inProgressPatterns.remove(patCacheKey);
            if (oldPatternTexture != null) // TODO: is this needed? when does this ever happen?
                for(Identifier oldPatternTextureSingle : oldPatternTexture.values())
                    MinecraftClient.getInstance().getTextureManager().getTexture(oldPatternTextureSingle).close();

            return Optional.empty(); // try not giving it immediately to avoid flickering?
        }
        if (patternTextures.containsKey(patCacheKey))
            return Optional.of(patternTextures.get(patCacheKey));

        // render a higher-resolution texture in a background thread so it eventually becomes all nice nice and pretty
        if(!inProgressPatterns.contains(patCacheKey)){
            inProgressPatterns.add(patCacheKey);
            executor.submit(() -> {
                var slowTextures = createTextures(patternlike, patSets, seed, resPerUnit);

                // TextureManager#register doesn't look very thread-safe, so move back to the main thread after the slow part is done
                MinecraftClient.getInstance().execute(() -> {
                        registerTextures(patCacheKey, slowTextures);
                });
            });
        }
        return Optional.empty();
    }

    private static Map<String, NativeImageBackedTexture> createTextures(HexPatternLike patternlike, PatternSettings patSets, double seed, int resPerUnit) {
        HexPatternPoints staticPoints = HexPatternPoints.getStaticPoints(patternlike, patSets, seed);

        List<Vec2f> zappyRenderSpace = staticPoints.scaleVecs(staticPoints.zappyPoints);

        Map<String, NativeImageBackedTexture> patTexts = new HashMap<>();

        NativeImage innerLines = drawLines(zappyRenderSpace, staticPoints, (float)patSets.getInnerWidth((staticPoints.finalScale)), resPerUnit);
        patTexts.put("inner", new NativeImageBackedTexture(innerLines));

        NativeImage outerLines = drawLines(zappyRenderSpace, staticPoints, (float)patSets.getOuterWidth((staticPoints.finalScale)), resPerUnit);
        patTexts.put("outer", new NativeImageBackedTexture(outerLines));

        return patTexts;
    }

    private static Map<String, Identifier> registerTextures(String patTextureKeyBase, Map<String, NativeImageBackedTexture> dynamicTextures) {
        Map<String, Identifier> resLocs = new HashMap<>();
        for(Map.Entry<String, NativeImageBackedTexture> textureEntry : dynamicTextures.entrySet()){
            String name = "hex_pattern_texture_" + patTextureKeyBase + "_" + textureEntry.getKey() + "_" + repaintIndex + ".png";
            Identifier resourceLocation = MinecraftClient.getInstance().getTextureManager().registerDynamicTexture(name, textureEntry.getValue());
            resLocs.put(textureEntry.getKey(), resourceLocation);
        }
        patternTexturesToAdd.put(patTextureKeyBase, resLocs);
        return resLocs;
    }

    private static NativeImage drawLines(List<Vec2f> points, HexPatternPoints staticPoints, float unscaledLineWidth, int resPerUnit) {
        NativeImage nativeImage = new NativeImage((int)(staticPoints.fullWidth*resPerUnit), (int)(staticPoints.fullHeight*resPerUnit), true);
        for (int i = 0; i < points.size() - 1; i++) {
            Pair<Integer, Integer> pointFrom = getTextureCoordinates(points.get(i), staticPoints, resPerUnit);
            Pair<Integer, Integer> pointTo = getTextureCoordinates(points.get(i+1), staticPoints, resPerUnit);
           drawLine(nativeImage, pointFrom.getLeft(), pointFrom.getRight(), pointTo.getLeft(), pointTo.getRight(), unscaledLineWidth * resPerUnit);
        }
        return nativeImage;
    }

    private static void drawLine(NativeImage image, int x0, int y0, int x1, int y1, float width) {
        var line = new Line2D.Float(x0, y0, x1, y1);
        var bounds = line.getBounds();
        double halfWidth = width / 2;
        for (int x = (int) (bounds.x - width - 1); x < (int) (bounds.x + bounds.width + width + 1); x++) {
            for (int y = (int) (bounds.y - width - 1); y < (int) (bounds.y + bounds.height + width + 1); y++) {
                double dist = line.ptSegDist(x, y);
                int alpha = (int) (MathHelper.clamp(halfWidth - dist + 0.5, 0, 1) * 255);
                if (alpha > 0) {
                    int oldAlpha = ColorHelper.Argb.getAlpha(image.getColor(x, y));
                    int newAlpha = Math.max(oldAlpha, alpha);
                    image.setColor(x, y, 0xFFFFFF | (newAlpha << 24));
                }
            }
        }
    }

    private static Pair<Integer, Integer> getTextureCoordinates(Vec2f point, HexPatternPoints staticPoints, int resPerUnit) {
        int x = (int) ( point.x * resPerUnit);
        int y = (int) ( point.y * resPerUnit);
        return new Pair<>(x, y);
    }

    public static void repaint() {
        repaintIndex++;
        patternTexturesToAdd.clear();
        patternTextures.clear();
    }
}