package at.petrak.hexcasting.mixin.accessor.client;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

// https://github.com/VazkiiMods/Botania/blob/13b7bcd9cbb6b1a418b0afe455662d29b46f1a7f/Xplat/src/main/java/vazkii/botania/mixin/client/AccessorRenderType.java
@Mixin(RenderLayer.class)
public interface AccessorRenderType {
    @Invoker("create")
    static RenderLayer.MultiPhase hex$create(String string, VertexFormat vertexFormat,
                                                 VertexFormat.DrawMode mode, int bufSize, boolean hasCrumbling, boolean sortOnUpload,
                                                 RenderLayer.MultiPhaseParameters compositeState) {
        throw new IllegalStateException();
    }
}
