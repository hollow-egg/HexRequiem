package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.xplat.IXplatTags;
import at.petrak.paucal.api.datagen.PaucalBlockTagProvider;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.data.DataOutput;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public class HexBlockTagProvider extends PaucalBlockTagProvider {
    public final IXplatTags xtags;

    public HexBlockTagProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider,
        IXplatTags xtags) {
        super(output, lookupProvider);
        this.xtags = xtags;
    }

    @Override
    protected void configure(RegistryWrapper.WrapperLookup provider) {
        add(getOrCreateTagBuilder(HexTags.Blocks.IMPETI),
            HexBlocks.IMPETUS_LOOK, HexBlocks.IMPETUS_RIGHTCLICK, HexBlocks.IMPETUS_REDSTONE);
        add(getOrCreateTagBuilder(HexTags.Blocks.DIRECTRICES),
            HexBlocks.DIRECTRIX_REDSTONE, HexBlocks.DIRECTRIX_BOOLEAN);
        getOrCreateTagBuilder(HexTags.Blocks.MINDFLAYED_CIRCLE_COMPONENTS)
            .addTag(HexTags.Blocks.IMPETI)
            .addTag(HexTags.Blocks.DIRECTRICES);

        add(getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE),
            HexBlocks.SLATE_BLOCK, HexBlocks.SLATE_TILES, HexBlocks.SLATE_BRICKS,
            HexBlocks.SLATE_BRICKS_SMALL, HexBlocks.SLATE_PILLAR, HexBlocks.SLATE,
            HexBlocks.EMPTY_DIRECTRIX, HexBlocks.DIRECTRIX_REDSTONE, HexBlocks.DIRECTRIX_BOOLEAN,
            HexBlocks.IMPETUS_EMPTY,
            HexBlocks.IMPETUS_RIGHTCLICK, HexBlocks.IMPETUS_LOOK, HexBlocks.IMPETUS_REDSTONE,
            HexBlocks.AMETHYST_TILES, HexBlocks.AMETHYST_BRICKS, HexBlocks.AMETHYST_BRICKS_SMALL,
            HexBlocks.AMETHYST_PILLAR, HexBlocks.SLATE_AMETHYST_TILES, HexBlocks.SLATE_AMETHYST_BRICKS,
            HexBlocks.SLATE_AMETHYST_BRICKS_SMALL, HexBlocks.SLATE_AMETHYST_PILLAR, HexBlocks.SCONCE,
            HexBlocks.QUENCHED_ALLAY, HexBlocks.QUENCHED_ALLAY_TILES, HexBlocks.QUENCHED_ALLAY_BRICKS,
            HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL);

        add(getOrCreateTagBuilder(BlockTags.SHOVEL_MINEABLE),
            HexBlocks.AMETHYST_DUST_BLOCK);

        add(getOrCreateTagBuilder(BlockTags.AXE_MINEABLE),
            HexBlocks.AKASHIC_RECORD, HexBlocks.AKASHIC_BOOKSHELF, HexBlocks.AKASHIC_LIGATURE,
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD,
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_PANEL, HexBlocks.EDIFIED_TILE,
            HexBlocks.EDIFIED_DOOR, HexBlocks.EDIFIED_TRAPDOOR, HexBlocks.EDIFIED_SLAB,
            HexBlocks.EDIFIED_BUTTON, HexBlocks.EDIFIED_STAIRS, HexBlocks.EDIFIED_FENCE, HexBlocks.EDIFIED_FENCE_GATE);

        add(getOrCreateTagBuilder(BlockTags.HOE_MINEABLE),
            HexBlocks.AMETHYST_EDIFIED_LEAVES, HexBlocks.AVENTURINE_EDIFIED_LEAVES,
            HexBlocks.CITRINE_EDIFIED_LEAVES);

        add(getOrCreateTagBuilder(BlockTags.CRYSTAL_SOUND_BLOCKS),
            HexBlocks.CONJURED_LIGHT, HexBlocks.CONJURED_BLOCK, HexBlocks.AMETHYST_TILES,
            HexBlocks.SCONCE);

        add(getOrCreateTagBuilder(HexTags.Blocks.EDIFIED_LOGS),
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD);
        add(getOrCreateTagBuilder(BlockTags.LOGS),
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD);
        add(getOrCreateTagBuilder(BlockTags.LOGS_THAT_BURN),
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
            HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
            HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD);
        add(getOrCreateTagBuilder(BlockTags.LEAVES),
            HexBlocks.AMETHYST_EDIFIED_LEAVES, HexBlocks.AVENTURINE_EDIFIED_LEAVES,
            HexBlocks.CITRINE_EDIFIED_LEAVES);

        add(getOrCreateTagBuilder(BlockTags.PLANKS),
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_PANEL, HexBlocks.EDIFIED_TILE);
        add(getOrCreateTagBuilder(HexTags.Blocks.EDIFIED_PLANKS),
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_PANEL, HexBlocks.EDIFIED_TILE);
        add(getOrCreateTagBuilder(BlockTags.SLABS),
            HexBlocks.EDIFIED_SLAB);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_SLABS),
            HexBlocks.EDIFIED_SLAB);
        add(getOrCreateTagBuilder(BlockTags.STAIRS),
            HexBlocks.EDIFIED_STAIRS);
        add(getOrCreateTagBuilder(BlockTags.FENCES),
            HexBlocks.EDIFIED_FENCE);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_FENCES),
            HexBlocks.EDIFIED_FENCE);
        add(getOrCreateTagBuilder(BlockTags.FENCE_GATES),
            HexBlocks.EDIFIED_FENCE_GATE);
        add(getOrCreateTagBuilder(BlockTags.UNSTABLE_BOTTOM_CENTER),
            HexBlocks.EDIFIED_FENCE_GATE);


        add(getOrCreateTagBuilder(BlockTags.WOODEN_FENCES),
            HexBlocks.EDIFIED_FENCE);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_STAIRS),
            HexBlocks.EDIFIED_STAIRS);
        add(getOrCreateTagBuilder(BlockTags.DOORS),
            HexBlocks.EDIFIED_DOOR);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_DOORS),
            HexBlocks.EDIFIED_DOOR);
        add(getOrCreateTagBuilder(BlockTags.TRAPDOORS),
            HexBlocks.EDIFIED_TRAPDOOR);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_TRAPDOORS),
            HexBlocks.EDIFIED_TRAPDOOR);
        add(getOrCreateTagBuilder(BlockTags.PRESSURE_PLATES),
            HexBlocks.EDIFIED_PRESSURE_PLATE);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_PRESSURE_PLATES),
            HexBlocks.EDIFIED_PRESSURE_PLATE);
        add(getOrCreateTagBuilder(BlockTags.BUTTONS),
            HexBlocks.EDIFIED_BUTTON);
        add(getOrCreateTagBuilder(BlockTags.WOODEN_BUTTONS),
            HexBlocks.EDIFIED_BUTTON);

        add(getOrCreateTagBuilder(HexTags.Blocks.WATER_PLANTS),
            Blocks.KELP, Blocks.KELP_PLANT, Blocks.SEAGRASS, Blocks.TALL_SEAGRASS);
        add(getOrCreateTagBuilder(HexTags.Blocks.CHEAP_TO_BREAK_BLOCK),
            HexBlocks.CONJURED_BLOCK, HexBlocks.CONJURED_LIGHT);

        add(getOrCreateTagBuilder(HexTags.Blocks.SLATE_BLOCKS),
            HexBlocks.SLATE_BLOCK, HexBlocks.SLATE_BRICKS, HexBlocks.SLATE_BRICKS_SMALL, HexBlocks.SLATE_TILES, HexBlocks.SLATE_PILLAR);
        add(getOrCreateTagBuilder(HexTags.Blocks.AMETHYST_BLOCKS),
            Blocks.AMETHYST_BLOCK, HexBlocks.AMETHYST_BRICKS, HexBlocks.AMETHYST_BRICKS_SMALL, HexBlocks.AMETHYST_TILES, HexBlocks.AMETHYST_PILLAR);
        add(getOrCreateTagBuilder(HexTags.Blocks.QUENCHED_ALLAY_BLOCKS),
            HexBlocks.QUENCHED_ALLAY, HexBlocks.QUENCHED_ALLAY_BRICKS, HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL, HexBlocks.QUENCHED_ALLAY_TILES);

        // this is a hack but fixes #532
        var createBrittle = TagKey.of(RegistryKeys.BLOCK, new Identifier("create", "brittle"));
        getOrCreateTagBuilder(createBrittle).addOptionalTag(Registries.BLOCK.getId(HexBlocks.SLATE));
    }

    void add(ProvidedTagBuilder<Block> appender, Block... blocks) {
        for (Block block : blocks) {
            appender.add(Registries.BLOCK.getKey(block).orElseThrow());
        }
    }
}
