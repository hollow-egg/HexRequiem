package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.misc.MediaConstants;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemMediaBattery extends ItemMediaHolder {
    public static final Identifier MEDIA_PREDICATE = modLoc("media");
    public static final Identifier MAX_MEDIA_PREDICATE = modLoc("max_media");

    public ItemMediaBattery(Settings pProperties) {
        super(pProperties);
    }

    @Override
    public boolean canProvideMedia(ItemStack stack) {
        return true;
    }

    @Override
    public boolean canRecharge(ItemStack stack) {
        return true;
    }
}
