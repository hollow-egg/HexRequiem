package at.petrak.hexcasting.interop.inline;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.PatternShapeMatch;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.lib.HexItems;
import com.mojang.serialization.Codec;
import com.samsthenerd.inline.api.InlineData;
import net.minecraft.item.ItemStack;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;

public class InlinePatternData implements InlineData<InlinePatternData>{

    public static final Identifier rendererId = HexAPI.modLoc("pattern");

    @NotNull
    public final HexPattern pattern;

    public InlinePatternData(@NotNull HexPattern pattern){
        this.pattern = pattern;
    }

    @Override
    public InlinePatternDataType getType(){
        return InlinePatternDataType.INSTANCE;
    }

    @Override
    public Identifier getRendererId(){
        return rendererId;
    }

    @Override
    public Style getExtraStyle() {
        ItemStack scrollStack = new ItemStack(HexItems.SCROLL_MEDIUM);
        HexItems.SCROLL_MEDIUM.writeDatum(scrollStack, new PatternIota(pattern));
        scrollStack.setCustomName(getPatternName(pattern).copy().formatted(Formatting.WHITE));
        HoverEvent he = new HoverEvent(HoverEvent.Action.SHOW_ITEM, new HoverEvent.ItemStackContent(scrollStack));
        ClickEvent ce = new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, pattern.toString());
        return Style.EMPTY.withHoverEvent(he).withClickEvent(ce);
    }

    public static Text getPatternName(HexPattern pattern){
        try {
            PatternShapeMatch shapeMatch = PatternRegistryManifest.matchPattern(pattern, null, false);
            if(shapeMatch instanceof PatternShapeMatch.Normal normMatch){
                return HexAPI.instance().getActionI18n(normMatch.key, false);
            }
            // TODO: this doesn't actually ever hit because it errors out with server castinv env stuff first :(
            if(shapeMatch instanceof PatternShapeMatch.Special specialMatch){
                return HexAPI.instance().getSpecialHandlerI18n(specialMatch.key);
            }
        } catch (Exception e){
            // nop
        }
        return PatternIota.displayNonInline(pattern);
    }

    @Override
    public Text asText(boolean withExtra) {
        return Text.literal(pattern.toString()).fillStyle(asStyle(withExtra));
    }

    public static class InlinePatternDataType implements InlineDataType<InlinePatternData> {
        private static final Identifier ID = new Identifier(HexAPI.MOD_ID, "pattern");
        public static final InlinePatternDataType INSTANCE = new InlinePatternDataType();

        @Override
        public Identifier getId(){
            return ID;
        }

        @Override
        public Codec<InlinePatternData> getCodec(){
            return HexPattern.CODEC.xmap(
                InlinePatternData::new,
                data -> data.pattern
            );
        }
    }
}
