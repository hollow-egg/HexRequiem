package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class PatternResLocArgument extends IdentifierArgumentType {
    private static final DynamicCommandExceptionType ERROR_UNKNOWN_PATTERN = new DynamicCommandExceptionType(
        (errorer) ->
            Text.translatable("hexcasting.pattern.unknown", errorer)
    );

    public static PatternResLocArgument identifier() {
        return new PatternResLocArgument();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        var suggestions = new ArrayList<String>();
        var registry = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : registry.getKeys()) {
            if (HexUtils.isOfTag(registry, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                suggestions.add(key.getValue().toString());
            }
        }

        return CommandSource.suggestMatching(suggestions, builder);
    }

    public static HexPattern getPattern(
        CommandContext<ServerCommandSource> ctx, String argumentName) throws CommandSyntaxException {
        var targetId = ctx.getArgument(argumentName, Identifier.class);
        var targetKey = RegistryKey.of(IXplatAbstractions.INSTANCE.getActionRegistry().getKey(), targetId);
        var foundPat = PatternRegistryManifest.getCanonicalStrokesPerWorld(targetKey, ctx.getSource().getServer().getOverworld());
        if (foundPat == null) {
            throw ERROR_UNKNOWN_PATTERN.create(targetId);
        } else {
            return foundPat;
        }
    }
}
