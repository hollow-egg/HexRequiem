package at.petrak.hexcasting.common.blocks.circles.impetuses;

import at.petrak.hexcasting.api.addldata.ADIotaHolder;
import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.api.casting.iota.EntityIota;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class BlockRedstoneImpetus extends BlockAbstractImpetus {
    public static final BooleanProperty POWERED = Properties.POWERED;

    public BlockRedstoneImpetus(Settings p_49795_) {
        super(p_49795_);
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pPos, BlockState pState) {
        return new BlockEntityRedstoneImpetus(pPos, pState);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(POWERED);
    }

    @Override
    public ActionResult onUse(BlockState pState, World pLevel, BlockPos pPos, PlayerEntity pPlayer, Hand pHand,
        BlockHitResult pHit) {
        if (pLevel instanceof ServerWorld level
            && level.getBlockEntity(pPos) instanceof BlockEntityRedstoneImpetus tile) {
            var usedStack = pPlayer.getStackInHand(pHand);
            if (usedStack.isEmpty() && pPlayer.isSneaky()) {
                tile.clearPlayer();
                tile.sync();
                pLevel.playSound(null, pPos, HexSounds.IMPETUS_REDSTONE_CLEAR, SoundCategory.BLOCKS, 1f, 1f);
                return ActionResult.success(pLevel.isClient);
            } else {
                var datumContainer = IXplatAbstractions.INSTANCE.findDataHolder(usedStack);
                if (datumContainer != null) {
                    var stored = datumContainer.readIota(level);
                    if (stored instanceof EntityIota eieio) {
                        var entity = eieio.getEntity();
                        if (entity instanceof PlayerEntity player) {
                            // phew, we got something
                            tile.setPlayer(player.getGameProfile(), entity.getUuid());
                            tile.sync();

                            pLevel.playSound(null, pPos, HexSounds.IMPETUS_REDSTONE_DING,
                                SoundCategory.BLOCKS, 1f, 1f);
                            return ActionResult.success(pLevel.isClient);
                        }
                    }
                }
            }
        }

        return ActionResult.PASS;
    }

    @Override
    public void scheduledTick(BlockState pState, ServerWorld pLevel, BlockPos pPos, Random pRandom) {
        super.scheduledTick(pState, pLevel, pPos, pRandom);
        if (pLevel.getBlockEntity(pPos) instanceof BlockEntityRedstoneImpetus tile) {
            tile.updatePlayerProfile();
        }
    }

    @Override
    public void neighborUpdate(BlockState pState, World pLevel, BlockPos pPos, Block pBlock, BlockPos pFromPos,
        boolean pIsMoving) {
        super.neighborUpdate(pState, pLevel, pPos, pBlock, pFromPos, pIsMoving);

        if (pLevel instanceof ServerWorld slevel) {
            boolean prevPowered = pState.get(POWERED);
            boolean isPowered = pLevel.isReceivingRedstonePower(pPos);

            if (prevPowered != isPowered) {
                pLevel.setBlockState(pPos, pState.with(POWERED, isPowered));

                if (isPowered && pLevel.getBlockEntity(pPos) instanceof BlockEntityRedstoneImpetus tile) {
                    var player = tile.getStoredPlayer();
                    tile.startExecution(player);
                }
            }
        }
    }
}
