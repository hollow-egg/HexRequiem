package at.petrak.hexcasting.client;

import at.petrak.hexcasting.client.render.GaslightingTracker;
import net.minecraft.client.MinecraftClient;

public class ClientTickCounter {
    public static long ticksInGame = 0L;
    public static float partialTicks = 0.0F;

    public static float getTotal() {
        return (float) ticksInGame + partialTicks;
    }

    public static void renderTickStart(float renderTickTime) {
        partialTicks = renderTickTime;
    }

    public static void clientTickEnd() {
        if (!MinecraftClient.getInstance().isPaused()) {
            ++ticksInGame;
            partialTicks = 0.0F;
            GaslightingTracker.postFrameCheckRendered();
        }
    }
}
