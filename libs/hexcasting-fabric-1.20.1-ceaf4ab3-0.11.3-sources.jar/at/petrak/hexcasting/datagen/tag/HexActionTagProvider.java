package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.Platform;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexActionTagProvider extends TagProvider<ActionRegistryEntry> {
    public HexActionTagProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> provider) {
        super(output, IXplatAbstractions.INSTANCE.getActionRegistry().getKey(), provider);
    }

    @Override
    protected void configure(RegistryWrapper.WrapperLookup provider) {
        // In-game almost all great spells are always per-world
        for (var normalGreat : new String[]{
            "lightning", "flight", "create_lava", "teleport/great", "sentinel/create/great",
            "dispel_rain", "summon_rain", "brainsweep", "craft/battery",
            "potion/regeneration", "potion/night_vision", "potion/absorption", "potion/haste", "potion/strength"
        }) {
            var loc = modLoc(normalGreat);
            var key = RegistryKey.of(IXplatAbstractions.INSTANCE.getActionRegistry().getKey(), loc);
            getOrCreateTagBuilder(ersatzActionTag(HexTags.Actions.REQUIRES_ENLIGHTENMENT)).add(key);
            getOrCreateTagBuilder(ersatzActionTag(HexTags.Actions.CAN_START_ENLIGHTEN)).add(key);
            getOrCreateTagBuilder(ersatzActionTag(HexTags.Actions.PER_WORLD_PATTERN)).add(key);
        }
        // deciding that akashic write can be just a normal spell (as a treat)
    }

    private static TagKey<ActionRegistryEntry> ersatzActionTag(TagKey<ActionRegistryEntry> real) {
        if (IXplatAbstractions.INSTANCE.platform() == Platform.FABRIC) {
            // Vanilla (and Fabric) has a bug here where it *writes* hexcasting action tags to `.../tags/action`
            // instead of `.../tags/hexcasting/action`.
            // So we pull this bullshit
            var fakeKey = RegistryKey.<ActionRegistryEntry>ofRegistry(
                new Identifier("foobar", "hexcasting/tags/action"));
            return TagKey.of(fakeKey, real.id());
        } else {
            return real;
        }
    }
}
