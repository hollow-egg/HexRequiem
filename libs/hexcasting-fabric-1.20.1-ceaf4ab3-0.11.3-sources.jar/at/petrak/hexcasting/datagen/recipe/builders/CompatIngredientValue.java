package at.petrak.hexcasting.datagen.recipe.builders;

import com.google.gson.JsonObject;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.stream.Stream;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Ingredient;

public class CompatIngredientValue implements Ingredient.Entry {
    public final String item;

    public CompatIngredientValue(String name) {
        this.item = name;
    }

    public @NotNull Collection<ItemStack> getStacks() {
        return Collections.emptyList();
    }

    public @NotNull JsonObject toJson() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("item", item);
        return jsonObject;
    }

    public static Ingredient of(String itemName) {
        return new Ingredient(Stream.of(new CompatIngredientValue(itemName)));
    }
}

