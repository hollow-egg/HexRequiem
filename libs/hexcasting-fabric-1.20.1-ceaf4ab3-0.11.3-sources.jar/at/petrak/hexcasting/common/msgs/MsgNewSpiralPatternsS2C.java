package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.client.ClientCastingStack;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import I;

public record MsgNewSpiralPatternsS2C(UUID playerUUID, List<HexPattern> patterns, int lifetime) implements IMessage {
    public static final Identifier ID = modLoc("spi_pats_sc");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static MsgNewSpiralPatternsS2C deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);

        var player = buf.readUuid();
        var patterns = buf.readCollection(ArrayList::new, buff -> HexPattern.fromNBT(buf.readNbt()));
        var lifetime = buf.readInt();


        return new MsgNewSpiralPatternsS2C(player, patterns, lifetime);
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        buf.writeUuid(playerUUID);
        buf.writeCollection(patterns, (buff, pattern) -> buff.writeNbt(pattern.serializeToNBT()));
        buf.writeInt(lifetime);
    }

    public static void handle(MsgNewSpiralPatternsS2C self) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var mc = MinecraftClient.getInstance();
                assert mc.world != null;
                var player = mc.world.getPlayerByUuid(self.playerUUID);
                var stack = IClientXplatAbstractions.INSTANCE.getClientCastingStack(player);

                for (var pattern : self.patterns)
                    stack.addPattern(pattern, self.lifetime);
            }
        });
    }
}
