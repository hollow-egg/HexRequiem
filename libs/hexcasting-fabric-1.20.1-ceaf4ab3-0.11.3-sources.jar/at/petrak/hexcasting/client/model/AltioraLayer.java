package at.petrak.hexcasting.client.model;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.ElytraEntityModel;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import at.petrak.hexcasting.api.player.AltioraAbility;

public class AltioraLayer<M extends EntityModel<AbstractClientPlayerEntity>> extends FeatureRenderer<AbstractClientPlayerEntity, M> {
    private static final Identifier TEX_LOC = modLoc("textures/misc/altiora.png");

    private final ElytraEntityModel<AbstractClientPlayerEntity> elytraModel;

    public AltioraLayer(FeatureRendererContext<AbstractClientPlayerEntity, M> renderer, EntityModelLoader ems) {
        super(renderer);
        this.elytraModel = new ElytraEntityModel<>(ems.getModelPart(HexModelLayers.ALTIORA));
    }

    @Override
    public void render(MatrixStack ps, VertexConsumerProvider buffer, int packedLight, AbstractClientPlayerEntity player,
        float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw,
        float headPitch) {
        var altiora = IXplatAbstractions.INSTANCE.getAltiora(player);
        // do a best effort to not render over other elytra, although we can never patch up everything
        var chestSlot = player.getEquippedStack(EquipmentSlot.CHEST);
        if (altiora != null && !chestSlot.isOf(Items.ELYTRA)) {
            ps.push();
            ps.translate(0.0, 0.0, 0.125);

            this.getContextModel().copyStateTo(this.elytraModel);
            this.elytraModel.setAngles(player, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            VertexConsumer verts = ItemRenderer.getArmorGlintConsumer(
                buffer, RenderLayer.getArmorCutoutNoCull(TEX_LOC), false, true);
            this.elytraModel.render(ps, verts, packedLight, OverlayTexture.DEFAULT_UV, 1.0F, 1.0F, 1.0F, 1.0F);

            ps.pop();
        }
    }
}
