package at.petrak.hexcasting.common.blocks.entity;

import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import java.util.function.BiFunction;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;

/**
 * No-op BE just to have a BER
 */
public class BlockEntityQuenchedAllay extends HexBlockEntity {
    public BlockEntityQuenchedAllay(BlockQuenchedAllay block, BlockPos pos, BlockState blockState) {
        super(HexBlockEntities.typeForQuenchedAllay(block), pos, blockState);
    }

    public static BiFunction<BlockPos, BlockState, BlockEntityQuenchedAllay> fromKnownBlock(BlockQuenchedAllay block) {
        return (pos, state) -> new BlockEntityQuenchedAllay(block, pos, state);
    }

    @Override
    protected void saveModData(NbtCompound tag) {

    }

    @Override
    protected void loadModData(NbtCompound tag) {

    }
}
