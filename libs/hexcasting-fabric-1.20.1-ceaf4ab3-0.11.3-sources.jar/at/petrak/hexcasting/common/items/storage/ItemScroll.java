package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.client.gui.PatternTooltipComponent;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import at.petrak.hexcasting.common.misc.PatternTooltip;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.interop.inline.InlinePatternData;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.item.TooltipData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import java.util.List;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

/**
 * TAG_OP_ID and TAG_PATTERN: "Ancient Scroll of %s" (per-world pattern preloaded)
 * <br>
 * TAG_OP_ID: "Ancient Scroll of %s" (per-world pattern loaded on inv tick)
 * <br>
 * TAG_PATTERN: "Scroll" (custom)
 * <br>
 * (none): "Empty Scroll"
 */
public class ItemScroll extends Item implements IotaHolderItem {
    public static final String TAG_OP_ID = "op_id";
    public static final String TAG_PATTERN = "pattern";
    public static final String TAG_NEEDS_PURCHASE = "needs_purchase";
    public static final Identifier ANCIENT_PREDICATE = modLoc("ancient");

    public final int blockSize;

    public ItemScroll(Settings pProperties, int blockSize) {
        super(pProperties);
        this.blockSize = blockSize;
    }

    // this produces a scroll that will load the correct pattern for your world once it ticks
    public static ItemStack withPerWorldPattern(ItemStack stack, String op_id) {
        Item item = stack.getItem();
        if (item instanceof ItemScroll)
            NBTHelper.putString(stack, TAG_OP_ID, op_id);

        return stack;
    }

    @Override
    public @Nullable
    NbtCompound readIotaTag(ItemStack stack) {
        NbtCompound pattern = NBTHelper.getCompound(stack, TAG_PATTERN);
        if (pattern == null) {
            return null;
        }
        // We store only the data part of the iota; pretend the rest of it's there
        var out = new NbtCompound();
        out.putString(HexIotaTypes.KEY_TYPE, "hexcasting:pattern");
        out.put(HexIotaTypes.KEY_DATA, pattern);
        return out;
    }

    @Override
    public boolean writeable(ItemStack stack) {
        return true;
    }

    @Override
    public boolean canWrite(ItemStack stack, Iota datum) {
        return datum instanceof PatternIota || datum == null;
    }

    @Override
    public void writeDatum(ItemStack stack, Iota datum) {
        if (this.canWrite(stack, datum)) {
            if (datum instanceof PatternIota pat) {
                NBTHelper.putCompound(stack, TAG_PATTERN, pat.getPattern().serializeToNBT());
            } else if (datum == null) {
                NBTHelper.remove(stack, TAG_PATTERN);
            }
        }
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        var posClicked = ctx.getBlockPos();
        var direction = ctx.getSide();
        var posInFront = posClicked.offset(direction);
        PlayerEntity player = ctx.getPlayer();
        ItemStack itemstack = ctx.getStack();
        if (player != null && !this.mayPlace(player, direction, itemstack, posInFront)) {
            return ActionResult.FAIL;
        }
        var level = ctx.getWorld();
        var scrollStack = itemstack.copy();
        scrollStack.setCount(1);
        var scrollEntity = new EntityWallScroll(level, posInFront, direction, scrollStack, false, this.blockSize);

        // i guess
        var stackTag = itemstack.getNbt();
        if (stackTag != null) {
            EntityType.loadFromEntityNbt(level, player, scrollEntity, stackTag);
        }

        if (scrollEntity.canStayAttached()) {
            if (!level.isClient) {
                scrollEntity.onPlace();
                level.emitGameEvent(player, GameEvent.ENTITY_PLACE, posClicked);
                level.spawnEntity(scrollEntity);
            }

            itemstack.decrement(1);
            return ActionResult.success(level.isClient);
        } else {
            return ActionResult.CONSUME;
        }
    }

    // [VanillaCopy] of HangingEntityItem
    protected boolean mayPlace(PlayerEntity pPlayer, Direction pDirection, ItemStack pHangingEntityStack, BlockPos pPos) {
        return !pDirection.getAxis().isVertical() && pPlayer.canPlaceOn(pPos, pDirection, pHangingEntityStack);
    }

    @Override
    public Text getName(ItemStack pStack) {
        var descID = this.getTranslationKey(pStack);
        var ancientId = NBTHelper.getString(pStack, TAG_OP_ID);
        if (ancientId != null) {
            return Text.translatable(descID + ".of",
                Text.translatable("hexcasting.action." + Identifier.tryParse(ancientId)));
        } else if (NBTHelper.hasCompound(pStack, TAG_PATTERN)) {
            var compound = NBTHelper.getCompound(pStack, TAG_PATTERN);
            var patternLabel = Text.literal("");
            if (compound != null) {
                var pattern = HexPattern.fromNBT(compound);
                patternLabel = Text.literal(": ").append(new InlinePatternData(pattern).asText(false));
            }
            return Text.translatable(descID).append(patternLabel);
        } else {
            return Text.translatable(descID + ".empty");
        }
    }

    @Override
    public void inventoryTick(ItemStack pStack, World pLevel, Entity pEntity, int pSlotId, boolean pIsSelected) {
        // the needs_purchase tag is used so you can't see the pattern on scrolls sold by a wandering trader
        // once you put the scroll into your inventory, this removes the tag to reveal the pattern
        if (NBTHelper.getBoolean(pStack, TAG_NEEDS_PURCHASE)) {
            NBTHelper.remove(pStack, TAG_NEEDS_PURCHASE);
        }
        // if op_id is set but there's no stored pattern, attempt to load the pattern on inv tick
        if (NBTHelper.hasString(pStack, TAG_OP_ID) && !NBTHelper.hasCompound(pStack, TAG_PATTERN) && pEntity.getServer() != null) {
            var opID = Identifier.tryParse(NBTHelper.getString(pStack, TAG_OP_ID));
            if (opID == null) {
                // if the provided op_id is invalid, remove it so we don't keep trying every tick
                NBTHelper.remove(pStack, TAG_OP_ID);
                return;
            }
            var patternKey = RegistryKey.of(IXplatAbstractions.INSTANCE.getActionRegistry().getKey(), opID);
            var pat = PatternRegistryManifest.getCanonicalStrokesPerWorld(patternKey, pEntity.getServer().getOverworld());
            NBTHelper.put(pStack, TAG_PATTERN, pat.serializeToNBT());
        }
    }

    @Override
    public void appendTooltip(ItemStack pStack, @Nullable World pLevel, List<Text> pTooltipComponents,
        TooltipContext pIsAdvanced) {
        if (NBTHelper.getBoolean(pStack, TAG_NEEDS_PURCHASE)) {
            var needsPurchase = Text.translatable("hexcasting.tooltip.scroll.needs_purchase");
            pTooltipComponents.add(needsPurchase.formatted(Formatting.GRAY));
        } else if (NBTHelper.hasString(pStack, TAG_OP_ID) && !NBTHelper.hasCompound(pStack, TAG_PATTERN)) {
            var notLoaded = Text.translatable("hexcasting.tooltip.scroll.pattern_not_loaded");
            pTooltipComponents.add(notLoaded.formatted(Formatting.GRAY));
        }
    }

    @Override
    public Optional<TooltipData> getTooltipData(ItemStack stack) {
        var compound = NBTHelper.getCompound(stack, TAG_PATTERN);
        if (compound != null && !NBTHelper.getBoolean(stack, TAG_NEEDS_PURCHASE)) {
            var pattern = HexPattern.fromNBT(compound);
            return Optional.of(new PatternTooltip(
                pattern,
                NBTHelper.hasString(stack, TAG_OP_ID)
                    ? PatternTooltipComponent.ANCIENT_BG
                    : PatternTooltipComponent.PRISTINE_BG));
        }

        return Optional.empty();
    }
}
