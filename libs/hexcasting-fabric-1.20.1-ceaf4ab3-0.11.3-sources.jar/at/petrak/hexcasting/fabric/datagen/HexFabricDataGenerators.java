package at.petrak.hexcasting.fabric.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.datagen.HexLootTables;
import at.petrak.hexcasting.datagen.IXplatIngredients;
import at.petrak.hexcasting.datagen.recipe.HexplatRecipes;
import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightToolIngredient;
import at.petrak.hexcasting.datagen.tag.HexActionTagProvider;
import at.petrak.hexcasting.datagen.tag.HexBlockTagProvider;
import at.petrak.hexcasting.datagen.tag.HexItemTagProvider;
import at.petrak.hexcasting.fabric.recipe.FabricModConditionalIngredient;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatTags;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator.Pack;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.item.DyeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.world.item.*;
import java.util.EnumMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class HexFabricDataGenerators implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator gen) {
        HexAPI.LOGGER.info("Starting Fabric-specific datagen");

        var pack = gen.createPack();
        var xtags = IXplatAbstractions.INSTANCE.tags();

        pack.addProvider((FabricDataGenerator.Pack.Factory<HexplatRecipes>) x -> new HexplatRecipes(x, INGREDIENTS, HexFabricConditionsBuilder::new));

        var btagProviderWrapper = new BlockTagProviderWrapper(); // CURSED
        pack.addProvider((output, lookup) -> {
            btagProviderWrapper.provider = new HexBlockTagProvider(output, lookup, xtags);
            return btagProviderWrapper.provider;
        });
        pack.addProvider((output, lookup) -> new HexItemTagProvider(output, lookup, btagProviderWrapper.provider, xtags));

        pack.addProvider(HexActionTagProvider::new);

        pack.addProvider((FabricDataGenerator.Pack.Factory<LootTableProvider>) (output) -> new LootTableProvider(
                output, Set.of(), List.of(new LootTableProvider.LootTypeGenerator(HexLootTables::new, LootContextTypes.GENERIC))
        ));
    }

    private static class BlockTagProviderWrapper {
        HexBlockTagProvider provider;
    }

    private static final IXplatIngredients INGREDIENTS = new IXplatIngredients() {
        @Override
        public Ingredient glowstoneDust() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.GLOWSTONE_DUST)),
                new Ingredient.TagEntry(tag("glowstone_dusts"))
            ));
        }

        @Override
        public Ingredient leather() {
            // apparently c:leather also includes rabbit hide
            return Ingredient.ofItems(Items.LEATHER);
        }

        @Override
        public Ingredient ironNugget() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.IRON_NUGGET)),
                new Ingredient.TagEntry(tag("iron_nuggets"))
            ));
        }

        @Override
        public Ingredient goldNugget() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.GOLD_NUGGET)),
                new Ingredient.TagEntry(tag("gold_nuggets"))
            ));
        }

        @Override
        public Ingredient copperIngot() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.COPPER_INGOT)),
                new Ingredient.TagEntry(tag("copper_ingots"))
            ));
        }

        @Override
        public Ingredient ironIngot() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.IRON_INGOT)),
                new Ingredient.TagEntry(tag("iron_ingots"))
            ));
        }

        @Override
        public Ingredient goldIngot() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.GOLD_INGOT)),
                new Ingredient.TagEntry(tag("gold_ingots"))
            ));
        }

        @Override
        public EnumMap<DyeColor, Ingredient> dyes() {
            var out = new EnumMap<DyeColor, Ingredient>(DyeColor.class);
            for (var col : DyeColor.values()) {
                out.put(col, new Ingredient(Stream.of(
                    new Ingredient.StackEntry(new ItemStack(DyeItem.byColor(col))),
                    new Ingredient.TagEntry(
                        TagKey.of(RegistryKeys.ITEM,
                            new Identifier("c", col.asString() + "_dye"))),
                    new Ingredient.TagEntry(
                        TagKey.of(RegistryKeys.ITEM,
                            new Identifier("c", col.asString() + "_dyes"))
                    ))));
            }
            return out;
        }

        @Override
        public Ingredient stick() {
            return new Ingredient(Stream.of(
                new Ingredient.StackEntry(new ItemStack(Items.STICK)),
                new Ingredient.TagEntry(tag("wood_sticks"))
            ));
        }

        @Override
        public Ingredient whenModIngredient(Ingredient defaultIngredient, String modid, Ingredient modIngredient) {
            return FabricModConditionalIngredient.of(defaultIngredient, modid, modIngredient);
        }

        private final FarmersDelightToolIngredient AXE_INGREDIENT = () -> {
            JsonObject object = new JsonObject();
            object.addProperty("type", "farmersdelight:tool");
            object.addProperty("tag", "c:tools/axes");
            return object;
        };

        @Override
        public FarmersDelightToolIngredient axeStrip() {
            return AXE_INGREDIENT;
        }

        @Override
        public FarmersDelightToolIngredient axeDig() {
            return AXE_INGREDIENT;
        }
    };

    private static TagKey<Item> tag(String s) {
        return tag("c", s);
    }

    private static TagKey<Item> tag(String namespace, String s) {
        return TagKey.of(RegistryKeys.ITEM, new Identifier(namespace, s));
    }
}
