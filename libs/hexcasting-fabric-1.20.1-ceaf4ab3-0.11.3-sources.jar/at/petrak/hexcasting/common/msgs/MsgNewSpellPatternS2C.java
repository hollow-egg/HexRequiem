package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.casting.eval.ExecutionClientView;
import at.petrak.hexcasting.api.casting.eval.ResolvedPatternType;
import at.petrak.hexcasting.client.gui.GuiSpellcasting;
import at.petrak.hexcasting.common.lib.HexSounds;
import io.netty.buffer.ByteBuf;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import I;
import Z;

/**
 * Sent server->client when the player finishes casting a spell.
 */
public record MsgNewSpellPatternS2C(ExecutionClientView info, int index) implements IMessage {
    public static final Identifier ID = modLoc("pat_sc");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static MsgNewSpellPatternS2C deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);

        var isStackEmpty = buf.readBoolean();
        var resolutionType = buf.readEnumConstant(ResolvedPatternType.class);
        var index = buf.readInt();

        var stack = buf.readList(PacketByteBuf::readNbt);
        var raven = buf.readOptional(PacketByteBuf::readNbt).orElse(null);

        return new MsgNewSpellPatternS2C(
            new ExecutionClientView(isStackEmpty, resolutionType, stack, raven), index
        );
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        buf.writeBoolean(this.info.isStackClear());
        buf.writeEnumConstant(this.info.getResolutionType());
        buf.writeInt(this.index);

        buf.writeCollection(this.info.getStackDescs(), PacketByteBuf::writeNbt);
        buf.writeOptional(Optional.ofNullable(this.info.getRavenmind()), PacketByteBuf::writeNbt);
    }

    public static void handle(MsgNewSpellPatternS2C self) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var mc = MinecraftClient.getInstance();
                if (self.info().isStackClear()) {
                    // don't pay attention to the screen, so it also stops when we die
                    mc.getSoundManager().stopSounds(HexSounds.CASTING_AMBIANCE.getId(), null);
                }
                var screen = MinecraftClient.getInstance().currentScreen;
                if (screen instanceof GuiSpellcasting spellGui) {
                    spellGui.recvServerUpdate(self.info(), self.index());
                }
            }
        });
    }
}
