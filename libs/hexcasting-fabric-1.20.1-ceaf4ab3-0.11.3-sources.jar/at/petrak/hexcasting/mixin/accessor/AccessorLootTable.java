package at.petrak.hexcasting.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.BiFunction;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContext;
import net.minecraft.loot.function.LootFunction;

@Mixin(LootTable.class)
public interface AccessorLootTable {
    @Accessor("functions")
    LootFunction[] hex$getFunctions();

    @Accessor("functions")
    @Mutable
    void hex$setFunctions(LootFunction[] lifs);

    @Accessor("compositeFunction")
    @Mutable
    void hex$setCompositeFunction(BiFunction<ItemStack, LootContext, ItemStack> bf);
}
