package at.petrak.hexcasting.fabric.cc;

import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import dev.onyxstudios.cca.api.v3.component.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.network.ServerPlayerEntity;

public class CCPatterns implements Component {
    public static final String TAG_PATTERNS = "patterns";

    private final PlayerEntity owner;

    private List<ResolvedPattern> patterns = Collections.emptyList();

    public CCPatterns(ServerPlayerEntity owner) {
        this.owner = owner;
    }


    public List<ResolvedPattern> getPatterns() {
        return patterns;
    }

    public void setPatterns(List<ResolvedPattern> patterns) {
        this.patterns = patterns;
    }

    @Override
    public void readFromNbt(NbtCompound tag) {
        NbtList patternsTag = tag.getList(TAG_PATTERNS, NbtElement.COMPOUND_TYPE);

        List<ResolvedPattern> patterns = new ArrayList<>(patternsTag.size());

        for (int i = 0; i < patternsTag.size(); i++) {
            patterns.add(ResolvedPattern.fromNBT(patternsTag.getCompound(i)));
        }
        this.patterns = patterns;
    }

    @Override
    public void writeToNbt(NbtCompound tag) {
        var listTag = new NbtList();
        for (ResolvedPattern pattern : patterns) {
            listTag.add(pattern.serializeToNBT());
        }
        tag.put(TAG_PATTERNS, listTag);
    }
}
