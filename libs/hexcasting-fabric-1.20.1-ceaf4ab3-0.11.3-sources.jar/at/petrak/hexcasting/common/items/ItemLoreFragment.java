package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.common.lib.HexSounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemLoreFragment extends Item {
    public static final List<Identifier> NAMES = List.of(new Identifier[]{
        modLoc("lore/cardamom1"),
        modLoc("lore/cardamom2"),
        modLoc("lore/cardamom3"),
        modLoc("lore/cardamom4"),
        modLoc("lore/cardamom5"),
        modLoc("lore/experiment1"),
        modLoc("lore/experiment2"),
        modLoc("lore/inventory"),
    });

    public static final String CRITEREON_KEY = "grant";

    public ItemLoreFragment(Settings properties) {
        super(properties);
    }

    @Override
    public TypedActionResult<ItemStack> use(World level, PlayerEntity player, Hand usedHand) {
        player.playSound(HexSounds.READ_LORE_FRAGMENT, 1f, 1f);

        var handStack = player.getStackInHand(usedHand);
        if (!(player instanceof ServerPlayerEntity splayer)) {
            handStack.decrement(1);
            return TypedActionResult.success(handStack);
        }

        Advancement unfoundLore = null;
        var shuffled = new ArrayList<>(NAMES);
        Collections.shuffle(shuffled);
        for (var advID : shuffled) {
            var adv = splayer.server.getAdvancementLoader().get(advID);
            if (adv == null) {
                continue; // uh oh
            }

            if (!splayer.getAdvancementTracker().getProgress(adv).isDone()) {
                unfoundLore = adv;
                break;
            }
        }

        if (unfoundLore == null) {
            splayer.sendMessage(Text.translatable("item.hexcasting.lore_fragment.all"), true);
            splayer.addExperience(20);
            level.playSound(null, player.getPos().x, player.getPos().y, player.getPos().z,
                HexSounds.READ_LORE_FRAGMENT, SoundCategory.PLAYERS, 1f, 1f);
        } else {
            // et voila!
            splayer.getAdvancementTracker().grantCriterion(unfoundLore, CRITEREON_KEY);
        }

        Criteria.CONSUME_ITEM.trigger(splayer, handStack);
        splayer.incrementStat(Stats.USED.getOrCreateStat(this));
        handStack.decrement(1);

        return TypedActionResult.success(handStack);
    }
}
