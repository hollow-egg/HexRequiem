package at.petrak.hexcasting.api.advancements;

import D;
import at.petrak.hexcasting.api.mod.HexConfig;
import com.google.gson.JsonObject;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.advancement.criterion.AbstractCriterionConditions;
import net.minecraft.advancements.critereon.*;
import net.minecraft.predicate.NumberRange;
import net.minecraft.predicate.entity.AdvancementEntityPredicateDeserializer;
import net.minecraft.predicate.entity.AdvancementEntityPredicateSerializer;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

// https://github.com/TelepathicGrunt/Bumblezone/blob/latest-released/src/main/java/com/telepathicgrunt/the_bumblezone/advancements/CleanupStickyHoneyResidueTrigger.java
// https://github.com/VazkiiMods/Botania/blob/b8706e2e0bba20f67f1e103559a4ce39d63d48f9/src/main/java/vazkii/botania/common/advancements/CorporeaRequestTrigger.java

public class OvercastTrigger extends AbstractCriterion<OvercastTrigger.Instance> {
    private static final Identifier ID = new Identifier("hexcasting", "overcast");

    private static final String TAG_MEDIA_GENERATED = "media_generated";
    private static final String TAG_HEALTH_USED = "health_used";
    // HEY KIDS DID YOYU KNOW THERE'S NOT A CRITERIA FOR HOW MUCH ***HEALTH*** AN ENTITY HAS
    private static final String TAG_HEALTH_LEFT =
        "mojang_i_am_begging_and_crying_please_add_an_entity_health_criterion";

    @Override
    public Identifier getId() {
        return ID;
    }

    @Override
    protected Instance conditionsFromJson(JsonObject json, LootContextPredicate predicate,
        AdvancementEntityPredicateDeserializer pContext) {
        return new Instance(predicate,
            NumberRange.IntRange.fromJson(json.get(TAG_MEDIA_GENERATED)),
            NumberRange.FloatRange.fromJson(json.get(TAG_HEALTH_USED)),
            NumberRange.FloatRange.fromJson(json.get(TAG_HEALTH_LEFT)));
    }

    public void trigger(ServerPlayerEntity player, int mediaGenerated) {
        super.trigger(player, inst -> {
            var mediaToHealth = HexConfig.common().mediaToHealthRate();
            var healthUsed = mediaGenerated / mediaToHealth;
            return inst.test(mediaGenerated, healthUsed / player.getMaxHealth(), player.getHealth());
        });
    }

    public static class Instance extends AbstractCriterionConditions {
        protected final NumberRange.IntRange mediaGenerated;
        // This is the *proporttion* of the health bar.
        protected final NumberRange.FloatRange healthUsed;
        // DID YOU KNOW THERES ONE TO CHECK THE WORLD TIME, BUT NOT THE HEALTH!?
        protected final NumberRange.FloatRange healthLeft;

        public Instance(LootContextPredicate predicate, NumberRange.IntRange mediaGenerated,
            NumberRange.FloatRange healthUsed, NumberRange.FloatRange healthLeft) {
            super(OvercastTrigger.ID, predicate);
            this.mediaGenerated = mediaGenerated;
            this.healthUsed = healthUsed;
            // DID YOU KNOW THERE'S ONE TO CHECK THE FUCKING C A T T Y P E BUT NOT THE HEALTH
            this.healthLeft = healthLeft;
        }

        @Override
        public Identifier getId() {
            return ID;
        }

        @Override
        public JsonObject toJson(AdvancementEntityPredicateSerializer ctx) {
            JsonObject json = super.toJson(ctx);
            if (!this.mediaGenerated.isDummy()) {
                json.add(TAG_MEDIA_GENERATED, this.mediaGenerated.toJson());
            }
            if (!this.healthUsed.isDummy()) {
                json.add(TAG_HEALTH_USED, this.healthUsed.toJson());
            }
            if (!this.healthLeft.isDummy()) {
                json.add(TAG_HEALTH_LEFT, this.healthLeft.toJson());
            }
            return json;
        }

        private boolean test(int mediaGeneratedIn, double healthUsedIn, float healthLeftIn) {
            return this.mediaGenerated.test(mediaGeneratedIn)
                && this.healthUsed.test(healthUsedIn)
                // DID YOU KNOW ALL THE ENEITYT PREDICATES ARE HARD-CODED AND YOU CANT MAKE NEW ONES
                && this.healthLeft.test(healthLeftIn);
        }
    }
}
