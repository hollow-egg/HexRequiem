package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.gson.annotations.SerializedName;
import vazkii.patchouli.api.IVariable;

import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;

/**
 * Grab the pattern from the registry
 */
public class LookupPatternComponent extends AbstractPatternComponent {
    @SerializedName("op_id")
    public String opNameRaw;

    protected Identifier opName;
    protected boolean strokeOrder;

    @Override
    public List<HexPattern> getPatterns(UnaryOperator<IVariable> lookup) {
        var key = RegistryKey.of(IXplatAbstractions.INSTANCE.getActionRegistry().getKey(), this.opName);
        var entry = IXplatAbstractions.INSTANCE.getActionRegistry().get(key);

        this.strokeOrder =
            !IXplatAbstractions.INSTANCE.getActionRegistry().entryOf(key).isIn(HexTags.Actions.PER_WORLD_PATTERN);
        return List.of(entry.prototype());
    }

    @Override
    public boolean showStrokeOrder() {
        return this.strokeOrder;
    }

    @Override
    public void onVariablesAvailable(UnaryOperator<IVariable> lookup) {
        var opName = lookup.apply(IVariable.wrap(this.opNameRaw)).asString();
        this.opName = Identifier.tryParse(opName);

        super.onVariablesAvailable(lookup);
    }
}
