package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtLongArray;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class Vec3Iota extends Iota {
    public Vec3Iota(@NotNull Vec3d datum) {
        super(HexIotaTypes.VEC3, datum);
    }

    public Vec3d getVec3() {
        var v = (Vec3d) this.payload;
        return new Vec3d(
            HexUtils.fixNAN(v.x),
            HexUtils.fixNAN(v.y),
            HexUtils.fixNAN(v.z)
        );
    }

    @Override
    public boolean isTruthy() {
        var v = this.getVec3();
        return !(v.x == 0.0 && v.y == 0.0 && v.z == 0.0);
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof Vec3Iota viota
            && this.getVec3().squaredDistanceTo(viota.getVec3()) < DoubleIota.TOLERANCE * DoubleIota.TOLERANCE;
    }

    @Override
    public @NotNull NbtElement serialize() {
        return HexUtils.serializeToNBT(this.getVec3());
    }

    public static IotaType<Vec3Iota> TYPE = new IotaType<>() {
        @Nullable
        @Override
        public Vec3Iota deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException {
            return Vec3Iota.deserialize(tag);
        }

        @Override
        public Text display(NbtElement tag) {
            return Vec3Iota.display(Vec3Iota.deserialize(tag).getVec3());
        }

        @Override
        public int color() {
            return 0xff_ff3030;
        }
    };

    public static Vec3Iota deserialize(NbtElement tag) throws IllegalArgumentException {
        Vec3d vec;
        if (tag.getNbtType() == NbtLongArray.TYPE) {
            var lat = HexUtils.downcast(tag, NbtLongArray.TYPE);
            vec = HexUtils.vecFromNBT(lat.getLongArray());
        } else
            vec = HexUtils.vecFromNBT(HexUtils.downcast(tag, NbtCompound.TYPE));
        return new Vec3Iota(vec);
    }

    public static Text display(double x, double y, double z) {
        return Text.literal(String.format("(%.2f, %.2f, %.2f)", x, y, z))
            .formatted(Formatting.RED);
    }

    public static Text display(Vec3d v) {
        return display(v.x, v.y, v.z);
    }
}
