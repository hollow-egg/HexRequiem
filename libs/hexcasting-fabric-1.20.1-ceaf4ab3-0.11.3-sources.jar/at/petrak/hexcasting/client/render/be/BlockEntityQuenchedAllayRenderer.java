package at.petrak.hexcasting.client.render.be;

import I;
import at.petrak.hexcasting.client.RegisterClientStuff;
import at.petrak.hexcasting.client.render.GaslightingTracker;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.entity.BlockEntityQuenchedAllay;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Box;

// TODO: this doesn't cover the block being *behind* something. Is it possible to cleanly do that?
// it would probably require some depth-texture bullshit that I don't want to worry about
public class BlockEntityQuenchedAllayRenderer implements BlockEntityRenderer<BlockEntityQuenchedAllay> {
    private final BlockEntityRendererFactory.Context ctx;

    public BlockEntityQuenchedAllayRenderer(BlockEntityRendererFactory.Context ctx) {
        this.ctx = ctx;
    }

    private static void doRender(BlockQuenchedAllay block, BlockRenderManager dispatcher, MatrixStack ps, VertexConsumerProvider bufSource,
        int packedLight, int packedOverlay) {
        var buffer = bufSource.getBuffer(RenderLayer.getTranslucent());
        var pose = ps.peek();

        var idx = Math.abs(GaslightingTracker.getGaslightingAmount() % BlockQuenchedAllay.VARIANTS);
        var model = RegisterClientStuff.QUENCHED_ALLAY_VARIANTS.get(Registries.BLOCK.getId(block)).get(idx);

        dispatcher.getModelRenderer().render(pose, buffer, null, model, 1f, 1f, 1f, packedLight, packedOverlay);
    }

    @Override
    public void render(BlockEntityQuenchedAllay blockEntity, float partialTick, MatrixStack poseStack,
        VertexConsumerProvider bufferSource, int packedLight, int packedOverlay) {
        // https://github.com/MinecraftForge/MinecraftForge/blob/79dfdb0ace9694f9dd0f1d9e8c5c24a0ae2d77f8/patches/minecraft/net/minecraft/client/renderer/LevelRenderer.java.patch#L68
        // Forge fixes BEs rendering offscreen; Fabric doesn't!
        // So we do a special check on Fabric only
        var pos = blockEntity.getPos();
        var aabb = new Box(pos.add(-1, 0, -1), pos.add(1, 1, 1));
        if (IClientXplatAbstractions.INSTANCE.fabricAdditionalQuenchFrustumCheck(aabb)) {
            doRender((BlockQuenchedAllay) blockEntity.getCachedState().getBlock(), this.ctx.getRenderManager(), poseStack, bufferSource, packedLight, packedOverlay);
        }
    }

    @Override
    public boolean shouldRenderOffScreen(BlockEntityQuenchedAllay blockEntity) {
        return false;
    }

}
