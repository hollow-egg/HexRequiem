package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.server.ScrungledPatternsSave;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public class RecalcPatternsCommand {
    public static void add(LiteralArgumentBuilder<ServerCommandSource> cmd) {
        cmd.then(CommandManager.literal("recalcPatterns")
            .requires(dp -> dp.hasPermissionLevel(CommandManager.field_31840))
            .executes(ctx -> {
                var world = ctx.getSource().getServer().getOverworld();
                var ds = world.getPersistentStateManager();
                ds.set(ScrungledPatternsSave.TAG_SAVED_DATA,
                    ScrungledPatternsSave.createFromScratch(world.getSeed()));

                ctx.getSource().sendFeedback(() ->
                    Text.translatable("command.hexcasting.recalc"), true);
                return 1;
            }));
    }
}
