package at.petrak.hexcasting.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.blocks.circles.BlockEntitySlate;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.loot.HexLootHandler;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.paucal.api.datagen.PaucalLootTableSubProvider;
import net.minecraft.block.Block;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.condition.AnyOfLootCondition;
import net.minecraft.loot.condition.BlockStatePropertyLootCondition;
import net.minecraft.loot.condition.MatchToolLootCondition;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.condition.TableBonusLootCondition;
import net.minecraft.loot.entry.AlternativeEntry;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.ApplyBonusLootFunction;
import net.minecraft.loot.function.CopyNbtLootFunction;
import net.minecraft.loot.function.ExplosionDecayLootFunction;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.nbt.ContextLootNbtProvider;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.predicate.NumberRange;
import net.minecraft.predicate.StatePredicate;
import net.minecraft.predicate.item.EnchantmentPredicate;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.level.storage.loot.predicates.*;
import java.util.Map;

public class HexLootTables extends PaucalLootTableSubProvider {
    public HexLootTables() {
        super(HexAPI.MOD_ID);
    }

    @Override
    protected void makeLootTables(Map<Block, LootTable.Builder> blockTables,
        Map<Identifier, LootTable.Builder> lootTables) {
        dropSelf(blockTables, HexBlocks.IMPETUS_EMPTY,
            HexBlocks.IMPETUS_RIGHTCLICK, HexBlocks.IMPETUS_LOOK, HexBlocks.IMPETUS_REDSTONE,
            HexBlocks.EMPTY_DIRECTRIX, HexBlocks.DIRECTRIX_REDSTONE, HexBlocks.DIRECTRIX_BOOLEAN,
            HexBlocks.AKASHIC_RECORD, HexBlocks.AKASHIC_BOOKSHELF, HexBlocks.AKASHIC_LIGATURE,
            HexBlocks.SLATE_BLOCK, HexBlocks.SLATE_TILES, HexBlocks.SLATE_BRICKS, HexBlocks.SLATE_BRICKS_SMALL,
            HexBlocks.SLATE_PILLAR, HexBlocks.AMETHYST_DUST_BLOCK, HexBlocks.AMETHYST_TILES, HexBlocks.AMETHYST_BRICKS,
            HexBlocks.AMETHYST_BRICKS_SMALL, HexBlocks.AMETHYST_PILLAR, HexBlocks.SLATE_AMETHYST_TILES,
            HexBlocks.SLATE_AMETHYST_BRICKS, HexBlocks.SLATE_AMETHYST_BRICKS_SMALL, HexBlocks.SLATE_AMETHYST_PILLAR,
            HexBlocks.QUENCHED_ALLAY_TILES, HexBlocks.QUENCHED_ALLAY_BRICKS, HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL,
            HexBlocks.SCROLL_PAPER, HexBlocks.ANCIENT_SCROLL_PAPER, HexBlocks.SCROLL_PAPER_LANTERN,
            HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN, HexBlocks.SCONCE,
            HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST, HexBlocks.EDIFIED_LOG_AVENTURINE,
            HexBlocks.EDIFIED_LOG_CITRINE, HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.STRIPPED_EDIFIED_LOG,
            HexBlocks.EDIFIED_WOOD, HexBlocks.STRIPPED_EDIFIED_WOOD,
            HexBlocks.EDIFIED_PLANKS, HexBlocks.EDIFIED_TILE, HexBlocks.EDIFIED_PANEL,
            HexBlocks.EDIFIED_TRAPDOOR, HexBlocks.EDIFIED_STAIRS, HexBlocks.EDIFIED_FENCE, HexBlocks.EDIFIED_FENCE_GATE, HexBlocks.EDIFIED_PRESSURE_PLATE,
            HexBlocks.EDIFIED_BUTTON);

        makeSlabTable(blockTables, HexBlocks.EDIFIED_SLAB);

        makeLeafTable(blockTables, HexBlocks.AMETHYST_EDIFIED_LEAVES);
        makeLeafTable(blockTables, HexBlocks.AVENTURINE_EDIFIED_LEAVES);
        makeLeafTable(blockTables, HexBlocks.CITRINE_EDIFIED_LEAVES);

        var slatePool = LootPool.builder()
            .rolls(ConstantLootNumberProvider.create(1))
            .with(ItemEntry.builder(HexBlocks.SLATE)
                .apply(CopyNbtLootFunction.builder(ContextLootNbtProvider.BLOCK_ENTITY)
                    .withOperation(BlockEntitySlate.TAG_PATTERN, "BlockEntityTag." + BlockEntitySlate.TAG_PATTERN)));
        blockTables.put(HexBlocks.SLATE, LootTable.builder().pool(slatePool));

        var doorPool = dropThisPool(HexBlocks.EDIFIED_DOOR, 1)
            .conditionally(new BlockStatePropertyLootCondition.Builder(HexBlocks.EDIFIED_DOOR).properties(
                StatePredicate.Builder.create().exactMatch(DoorBlock.HALF, DoubleBlockHalf.LOWER)
            ));
        blockTables.put(HexBlocks.EDIFIED_DOOR, LootTable.builder().pool(doorPool));


        var silkTouchCond = MatchToolLootCondition.builder(
            ItemPredicate.Builder.create().enchantment(
                new EnchantmentPredicate(Enchantments.SILK_TOUCH, NumberRange.IntRange.ANY)));
        var noSilkTouchCond = silkTouchCond.invert();
        var goodAtAmethystingCond = MatchToolLootCondition.builder(
            ItemPredicate.Builder.create().tag(ItemTags.CLUSTER_MAX_HARVESTABLES)
        );

        var dustPoolWhenGood = LootPool.builder()
            .with(ItemEntry.builder(HexItems.AMETHYST_DUST))
            .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1, 4)))
            .apply(ApplyBonusLootFunction.oreDrops(Enchantments.FORTUNE))
            .conditionally(noSilkTouchCond).conditionally(goodAtAmethystingCond);

        var dustPoolWhenBad = LootPool.builder()
            .with(ItemEntry.builder(HexItems.AMETHYST_DUST))
            .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(0, 2)))
            .conditionally(noSilkTouchCond).conditionally(goodAtAmethystingCond.invert());

        var isThatAnMFingBrandonSandersonReference = LootPool.builder()
            .with(ItemEntry.builder(HexItems.CHARGED_AMETHYST))
            .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(1)))
            .conditionally(noSilkTouchCond).conditionally(goodAtAmethystingCond)
            .conditionally(TableBonusLootCondition.builder(Enchantments.FORTUNE,
                0.25f, 0.35f, 0.5f, 0.75f, 1.0f));

        var isThatAnMFingBadBrandonSandersonReference = LootPool.builder()
            .with(ItemEntry.builder(HexItems.CHARGED_AMETHYST))
            .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(1)))
            .conditionally(noSilkTouchCond).conditionally(goodAtAmethystingCond.invert())
            .conditionally(RandomChanceLootCondition.builder(0.125f));

        lootTables.put(HexLootHandler.TABLE_INJECT_AMETHYST_CLUSTER, LootTable.builder()
            .pool(dustPoolWhenGood)
            .pool(dustPoolWhenBad)
            .pool(isThatAnMFingBrandonSandersonReference)
            .pool(isThatAnMFingBadBrandonSandersonReference));

        // it looks like loot groups are bugged?
        // so instead we add some and then *increment* the amount, gated behind the cond
        var quenchedPool = LootPool.builder().with(AlternativeEntry.builder(
            ItemEntry.builder(HexBlocks.QUENCHED_ALLAY).conditionally(silkTouchCond),
            ItemEntry.builder(HexItems.QUENCHED_SHARD)
                .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(2f, 4f)))
                .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(1), true)
                    .conditionally(TableBonusLootCondition.builder(Enchantments.FORTUNE,
                        0.25f, 0.5f, 0.75f, 1.0f)))
        ));
        blockTables.put(HexBlocks.QUENCHED_ALLAY, LootTable.builder().pool(quenchedPool));
    }

    private void makeLeafTable(Map<Block, LootTable.Builder> lootTables, Block block) {
        var leafPool = dropThisPool(block, 1)
            .conditionally(AnyOfLootCondition.builder(
                IXplatAbstractions.INSTANCE.isShearsCondition(),
                MatchToolLootCondition.builder(ItemPredicate.Builder.create()
                    .enchantment(new EnchantmentPredicate(Enchantments.SILK_TOUCH, NumberRange.IntRange.atLeast(1))))
            ));
        lootTables.put(block, LootTable.builder().pool(leafPool));
    }

    private void makeSlabTable(Map<Block, LootTable.Builder> lootTables, Block block) {
        var leafPool = dropThisPool(block, 1)
            .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(2))
                .conditionally(new BlockStatePropertyLootCondition.Builder(block).properties(
                    StatePredicate.Builder.create().exactMatch(SlabBlock.TYPE, SlabType.DOUBLE)
                )))
            .apply(ExplosionDecayLootFunction.builder());
        lootTables.put(block, LootTable.builder().pool(leafPool));
    }
}
