package at.petrak.hexcasting.client.particles;

import I;
import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.*;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ColorHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Random;

public class ConjureParticle extends SpriteBillboardParticle {
    private static final Random RANDOM = new Random();

    private final SpriteProvider sprites;

    ConjureParticle(ClientWorld pLevel, double x, double y, double z, double dx, double dy, double dz,
        SpriteProvider pSprites, int color) {
        super(pLevel, x, y, z, dx, dy, dz);
        this.scale *= 0.9f;
        this.setVelocity(dx, dy, dz);

        var r = ColorHelper.Argb.getRed(color);
        var g = ColorHelper.Argb.getGreen(color);
        var b = ColorHelper.Argb.getBlue(color);
        this.setColor(r / 255f, g / 255f, b / 255f);
        this.setAlpha(0.3f);

        this.velocityMultiplier = 0.96F;
        this.gravityStrength = dy != 0 && dx != 0 && dz != 0 ? -0.01F : 0F;
        this.ascending = true;
        this.sprites = pSprites;

        this.angle = RANDOM.nextFloat(360);
        this.prevAngle = this.angle;

        this.maxAge = (int) (64.0 / ((Math.random() + 3f) * 0.25f));
        this.collidesWithWorld = false;
        this.setSpriteForAge(pSprites);
    }

    public @NotNull ParticleTextureSheet getType() {
        return CONJURE_RENDER_TYPE;
    }

    public void tick() {
        super.tick();
        this.setSpriteForAge(this.sprites);
        this.alpha = 1.0f - ((float) this.age / (float) this.maxAge);
        this.alpha *= 0.3f;
        this.scale *= 0.96f;
    }

    public void setSpriteForAge(@NotNull SpriteProvider pSprite) {
        if (!this.dead) {
            int age = this.age * 4;
            if (age > this.maxAge) {
                age /= 4;
            }
            this.setSprite(pSprite.getSprite(age, this.maxAge));
        }
    }

    public static class Provider implements ParticleFactory<ConjureParticleOptions> {
        private final SpriteProvider sprite;

        public Provider(SpriteProvider pSprites) {
            this.sprite = pSprites;
        }

        @Nullable
        @Override
        public Particle createParticle(ConjureParticleOptions type, ClientWorld level,
            double pX, double pY, double pZ,
            double pXSpeed, double pYSpeed, double pZSpeed) {
            return new ConjureParticle(level, pX, pY, pZ, pXSpeed, pYSpeed, pZSpeed, this.sprite, type.color());
        }
    }

    // https://github.com/VazkiiMods/Botania/blob/db85d778ab23f44c11181209319066d1f04a9e3d/Xplat/src/main/java/vazkii/botania/client/fx/FXWisp.java
    private record ConjureRenderType() implements ParticleTextureSheet {
        @Override
        public void begin(BufferBuilder buf, TextureManager texMan) {
            MinecraftClient.getInstance().gameRenderer.getLightmapTextureManager().enable();
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);

            RenderSystem.setShaderTexture(0, SpriteAtlasTexture.PARTICLE_ATLAS_TEXTURE);
            var tex = texMan.getTexture(SpriteAtlasTexture.PARTICLE_ATLAS_TEXTURE);
            IClientXplatAbstractions.INSTANCE.setFilterSave(tex, true, false);
            buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR_LIGHT);
            RenderSystem.enableDepthTest();
        }

        @Override
        public void draw(Tessellator tess) {
            tess.draw();
            IClientXplatAbstractions.INSTANCE.restoreLastFilter(
                MinecraftClient.getInstance().getTextureManager().getTexture(SpriteAtlasTexture.PARTICLE_ATLAS_TEXTURE)
            );
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
        }

        @Override
        public String toString() {
            return HexAPI.MOD_ID + ":conjure";
        }
    }

    public static final ConjureRenderType CONJURE_RENDER_TYPE = new ConjureRenderType();
}
