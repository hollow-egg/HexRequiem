package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Locale;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.world.World;

// Partially based on:
// https://github.com/SlimeKnights/Mantle/blob/1.18.2/src/main/java/slimeknights/mantle/recipe/ingredient/EntityIngredient.java
// Licensed under MIT
//
// .equals must make sense
public abstract class BrainsweepeeIngredient {
    public abstract boolean test(Entity entity, ServerWorld level);

    public abstract Text getName();

    public abstract List<Text> getTooltip(boolean advanced);

    public abstract JsonObject serialize();

    public void wrapWrite(PacketByteBuf buf) {
        buf.writeEnumConstant(this.ingrType());
        this.write(buf);
    }

    public abstract void write(PacketByteBuf buf);

    /**
     * For the benefit of showing to the client, return an example of the entity.
     * <p>
     * Can return null in case someone did something stupid with a recipe
     */
    @Nullable
    public abstract Entity exampleEntity(World level);

    public abstract Type ingrType();

    public abstract String getSomeKindOfReasonableIDForEmi();

    public static BrainsweepeeIngredient read(PacketByteBuf buf) {
        var type = buf.readEnumConstant(Type.class);
        return switch (type) {
            case VILLAGER -> VillagerIngredient.read(buf);
            case ENTITY_TYPE -> EntityTypeIngredient.read(buf);
            case ENTITY_TAG -> EntityTagIngredient.read(buf);
        };
    }

    public static BrainsweepeeIngredient deserialize(JsonObject json) {
        var typestr = JsonHelper.getString(json, "type");
        var type = Type.valueOf(typestr.toUpperCase(Locale.ROOT));
        return switch (type) {
            case VILLAGER -> VillagerIngredient.deserialize(json);
            case ENTITY_TYPE -> EntityTypeIngredient.deserialize(json);
            case ENTITY_TAG -> EntityTagIngredient.deserialize(json);
        };
    }

    // TODO: make this a registry?
    public enum Type implements StringIdentifiable {
        VILLAGER,
        ENTITY_TYPE,
        ENTITY_TAG;

        @Override
        public String asString() {
            return this.name().toLowerCase(Locale.ROOT);
        }
    }

    public static Text getModNameComponent(String namespace) {
        String mod = IXplatAbstractions.INSTANCE.getModName(namespace);
        return Text.literal(mod).formatted(Formatting.BLUE, Formatting.ITALIC);
    }
}
