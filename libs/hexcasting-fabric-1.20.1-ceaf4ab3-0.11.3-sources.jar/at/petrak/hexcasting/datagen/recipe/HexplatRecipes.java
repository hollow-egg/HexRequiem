package at.petrak.hexcasting.datagen.recipe;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.advancements.OvercastTrigger.Instance;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.blocks.decoration.BlockAkashicLog;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.items.pigment.ItemDyePigment;
import at.petrak.hexcasting.common.items.pigment.ItemPridePigment;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.recipe.SealThingsRecipe;
import at.petrak.hexcasting.common.recipe.ingredient.StateIngredientHelper;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.EntityTypeIngredient;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.VillagerIngredient;
import at.petrak.hexcasting.datagen.HexAdvancements;
import at.petrak.hexcasting.datagen.IXplatConditionsBuilder;
import at.petrak.hexcasting.datagen.IXplatIngredients;
import at.petrak.hexcasting.datagen.recipe.builders.BrainsweepRecipeBuilder;
import at.petrak.hexcasting.datagen.recipe.builders.CompatIngredientValue;
import at.petrak.hexcasting.datagen.recipe.builders.CreateCrushingRecipeBuilder;
import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightCuttingRecipeBuilder;
import at.petrak.paucal.api.datagen.PaucalRecipeProvider;
import net.minecraft.block.Blocks;
import net.minecraft.data.DataOutput;
import net.minecraft.data.recipes.*;
import net.minecraft.data.server.recipe.ComplexRecipeJsonBuilder;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.data.server.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.data.server.recipe.SingleItemRecipeJsonBuilder;
import net.minecraft.entity.EntityType;
import net.minecraft.item.DyeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.SpecialRecipeSerializer;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.village.VillagerProfession;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.function.Function;

// TODO: need to do a big refactor of this class cause it's giant and unwieldy, probably as part of #360
public class HexplatRecipes extends PaucalRecipeProvider {
    private final IXplatIngredients ingredients;
    private final Function<CraftingRecipeJsonBuilder, IXplatConditionsBuilder> conditions;

    private final List<BlockAkashicLog> EDIFIED_LOGS = List.of(
        HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
        HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
        HexBlocks.EDIFIED_LOG_PURPLE);

    private final Map<BlockAkashicLog, BlockAkashicLog> EDIFIED_LOG_TO_WOOD = Map.ofEntries(
        Map.entry(HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_WOOD),
//      These don't exist, idk if they should
//        Map.entry(HexBlocks.EDIFIED_LOG_AMETHYST, HexBlocks.EDIFIED_WOOD_AMETHYST),
//        Map.entry(HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_WOOD_AVENTURINE),
//        Map.entry(HexBlocks.EDIFIED_LOG_CITRINE, HexBlocks.EDIFIED_WOOD_CITRINE),
//        Map.entry(HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.EDIFIED_WOOD_PURPLE),
        Map.entry(HexBlocks.STRIPPED_EDIFIED_LOG, HexBlocks.STRIPPED_EDIFIED_WOOD)
    );

    public HexplatRecipes(DataOutput output, IXplatIngredients ingredients,
                          Function<CraftingRecipeJsonBuilder, IXplatConditionsBuilder> conditions) {
        super(output, HexAPI.MOD_ID);
        this.ingredients = ingredients;
        this.conditions = conditions;
    }

    @Override
    public void generate(Consumer<RecipeJsonProvider> recipes) {
        specialRecipe(recipes, SealThingsRecipe.FOCUS_SERIALIZER);
        specialRecipe(recipes, SealThingsRecipe.SPELLBOOK_SERIALIZER);

        staffRecipe(recipes, HexItems.STAFF_OAK, Items.OAK_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_BIRCH, Items.BIRCH_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_SPRUCE, Items.SPRUCE_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_JUNGLE, Items.JUNGLE_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_DARK_OAK, Items.DARK_OAK_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_ACACIA, Items.ACACIA_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_CRIMSON, Items.CRIMSON_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_WARPED, Items.WARPED_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_MANGROVE, Items.MANGROVE_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_CHERRY, Items.CHERRY_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_BAMBOO, Items.BAMBOO_PLANKS);
        staffRecipe(recipes, HexItems.STAFF_EDIFIED, HexBlocks.EDIFIED_PLANKS.asItem());
        staffRecipe(recipes, HexItems.STAFF_QUENCHED, HexItems.QUENCHED_SHARD);
        staffRecipe(recipes, HexItems.STAFF_MINDSPLICE, Ingredient.fromTag(HexTags.Items.MINDFLAYED_CIRCLE_COMPONENTS));

        ShapelessRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.THOUGHT_KNOT)
            .input(HexItems.AMETHYST_DUST)
            .input(Items.STRING)
            .criterion("has_item", hasItem(HexTags.Items.STAVES))
            .offerTo(recipes);
        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.FOCUS)
            .input('G', ingredients.glowstoneDust())
            .input('L', ingredients.leather())
            .input('P', Items.PAPER)
            .input('A', HexItems.CHARGED_AMETHYST)
            .pattern("GLG")
            .pattern("PAP")
            .pattern("GLG")
            .criterion("has_item", hasItem(HexTags.Items.STAVES))
            .offerTo(recipes);
        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.FOCUS)
            .input('G', ingredients.glowstoneDust())
            .input('L', ingredients.leather())
            .input('P', Items.PAPER)
            .input('A', HexItems.CHARGED_AMETHYST)
            .pattern("GPG")
            .pattern("LAL")
            .pattern("GPG")
            .criterion("has_item", hasItem(HexTags.Items.STAVES))
            .offerTo(recipes, modLoc("focus_rotated"));

        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.SPELLBOOK)
            .input('N', ingredients.goldNugget())
            .input('B', Items.WRITABLE_BOOK)
            .input('A', HexItems.CHARGED_AMETHYST)
            .input('F', Items.CHORUS_FRUIT) // i wanna gate this behind the end SOMEHOW
            // hey look its my gender ^^
            .pattern("NBA")
            .pattern("NFA")
            .pattern("NBA")
            .criterion("has_focus", hasItem(HexItems.FOCUS))
            .criterion("has_chorus", hasItem(Items.CHORUS_FRUIT)).offerTo(recipes);

        ringCornerless(RecipeCategory.TOOLS,
            HexItems.CYPHER, 1,
            ingredients.copperIngot(),
            Ingredient.ofItems(HexItems.AMETHYST_DUST))
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ringCornerless(RecipeCategory.TOOLS,
            HexItems.TRINKET, 1,
            ingredients.ironIngot(),
            Ingredient.ofItems(Items.AMETHYST_SHARD))
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.ARTIFACT)
            .input('F', ingredients.goldIngot())
            .input('A', HexItems.CHARGED_AMETHYST)
            // why in god's name does minecraft have two different places for item tags
            .input('D', ItemTags.MUSIC_DISCS)
            .pattern(" F ")
            .pattern("FAF")
            .pattern(" D ")
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ringCornerless(RecipeCategory.TOOLS, HexItems.SCRYING_LENS, 1, Items.GLASS, HexItems.AMETHYST_DUST)
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.ABACUS)
            .input('S', Items.STICK)
            .input('A', Items.AMETHYST_SHARD)
            .input('W', ItemTags.PLANKS)
            .pattern("WAW")
            .pattern("SAS")
            .pattern("WAW")
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        // Why am I like this
        ShapedRecipeJsonBuilder.create(RecipeCategory.FOOD, HexItems.SUBMARINE_SANDWICH)
            .input('S', Items.STICK)
            .input('A', Items.AMETHYST_SHARD)
            .input('C', Items.COOKED_BEEF)
            .input('B', Items.BREAD)
            .pattern(" SA")
            .pattern(" C ")
            .pattern(" B ")
            .criterion("has_item", hasItem(Items.AMETHYST_SHARD)).offerTo(recipes);

        for (var dye : DyeColor.values()) {
            var item = HexItems.DYE_PIGMENTS.get(dye);
            ShapedRecipeJsonBuilder.create(RecipeCategory.MISC, item)
                .input('D', HexItems.AMETHYST_DUST)
                .input('C', DyeItem.byColor(dye))
                .pattern(" D ")
                .pattern("DCD")
                .pattern(" D ")
                .criterion("has_item", hasItem(HexItems.AMETHYST_DUST)).offerTo(recipes);
        }

        gayRecipe(recipes, ItemPridePigment.Type.AGENDER, Ingredient.ofItems(Items.GLASS));
        gayRecipe(recipes, ItemPridePigment.Type.AROACE, Ingredient.ofItems(Items.WHEAT_SEEDS));
        gayRecipe(recipes, ItemPridePigment.Type.AROMANTIC, Ingredient.ofItems(Items.ARROW));
        gayRecipe(recipes, ItemPridePigment.Type.ASEXUAL, Ingredient.ofItems(Items.BREAD));
        gayRecipe(recipes, ItemPridePigment.Type.BISEXUAL, Ingredient.ofItems(Items.WHEAT));
        gayRecipe(recipes, ItemPridePigment.Type.DEMIBOY, Ingredient.ofItems(Items.RAW_IRON));
        gayRecipe(recipes, ItemPridePigment.Type.DEMIGIRL, Ingredient.ofItems(Items.RAW_COPPER));
        gayRecipe(recipes, ItemPridePigment.Type.GAY, Ingredient.ofItems(Items.STONE_BRICK_WALL));
        gayRecipe(recipes, ItemPridePigment.Type.GENDERFLUID, Ingredient.ofItems(Items.WATER_BUCKET));
        gayRecipe(recipes, ItemPridePigment.Type.GENDERQUEER, Ingredient.ofItems(Items.GLASS_BOTTLE));
        gayRecipe(recipes, ItemPridePigment.Type.INTERSEX, Ingredient.ofItems(Items.AZALEA));
        gayRecipe(recipes, ItemPridePigment.Type.LESBIAN, Ingredient.ofItems(Items.HONEYCOMB));
        gayRecipe(recipes, ItemPridePigment.Type.NONBINARY, Ingredient.ofItems(Items.MOSS_BLOCK));
        gayRecipe(recipes, ItemPridePigment.Type.PANSEXUAL, ingredients.whenModIngredient(
            Ingredient.ofItems(Items.CARROT),
            "farmersdelight",
            CompatIngredientValue.of("farmersdelight:skillet")
        ));
        gayRecipe(recipes, ItemPridePigment.Type.PLURAL, Ingredient.ofItems(Items.REPEATER));
        gayRecipe(recipes, ItemPridePigment.Type.TRANSGENDER, Ingredient.ofItems(Items.EGG));

        ring(RecipeCategory.MISC, HexItems.UUID_PIGMENT, 1, HexItems.AMETHYST_DUST, Items.AMETHYST_SHARD)
            .criterion("has_item", hasItem(HexItems.AMETHYST_DUST)).offerTo(recipes);
        ringCornerless(RecipeCategory.MISC, HexItems.DEFAULT_PIGMENT, 1, HexItems.AMETHYST_DUST, Items.AMETHYST_SHARD)
            .criterion("has_item", hasItem(HexItems.AMETHYST_DUST)).offerTo(recipes);
        ringCornerless(RecipeCategory.MISC, HexItems.ANCIENT_PIGMENT, 1, HexItems.AMETHYST_DUST, Items.COPPER_INGOT)
            .criterion("has_item", hasItem(HexItems.AMETHYST_DUST)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.DECORATIONS, HexItems.SCROLL_SMOL)
            .input('P', Items.PAPER)
            .input('A', HexItems.AMETHYST_DUST)
            .pattern(" A")
            .pattern("P ")
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.DECORATIONS, HexItems.SCROLL_MEDIUM)
            .input('P', Items.PAPER)
            .input('A', HexItems.AMETHYST_DUST)
            .pattern("  A")
            .pattern("PP ")
            .pattern("PP ")
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.DECORATIONS, HexItems.SCROLL_LARGE)
            .input('P', Items.PAPER)
            .input('A', HexItems.AMETHYST_DUST)
            .pattern("PPA")
            .pattern("PPP")
            .pattern("PPP")
            .criterion("has_item", hasItem(HexTags.Items.STAVES)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.DECORATIONS, HexItems.SLATE, 6)
            .input('S', Items.DEEPSLATE)
            .input('A', HexItems.AMETHYST_DUST)
            .pattern(" A ")
            .pattern("SSS")
            .criterion("has_item", hasItem(HexItems.AMETHYST_DUST)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, HexItems.JEWELER_HAMMER)
            .input('I', ingredients.ironIngot())
            .input('N', ingredients.ironNugget())
            .input('A', Items.AMETHYST_SHARD)
            .input('S', ingredients.stick())
            .pattern("IAN")
            .pattern(" S ")
            .pattern(" S ")
            .criterion("has_item", hasItem(Items.AMETHYST_SHARD)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC, HexItems.AMETHYST_DUST,
                (int) (MediaConstants.QUENCHED_SHARD_UNIT / MediaConstants.DUST_UNIT) + 1)
            .input(HexItems.QUENCHED_SHARD)
            .input(HexItems.AMETHYST_DUST)
            .criterion("has_item", hasItem(HexItems.QUENCHED_SHARD))
            .offerTo(recipes, modLoc("decompose_quenched_shard/dust"));
        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC, Items.AMETHYST_SHARD,
                (int) (MediaConstants.QUENCHED_SHARD_UNIT / MediaConstants.SHARD_UNIT) + 1)
            .input(HexItems.QUENCHED_SHARD)
            .input(Items.AMETHYST_SHARD)
            .criterion("has_item", hasItem(HexItems.QUENCHED_SHARD))
            .offerTo(recipes, modLoc("decompose_quenched_shard/shard"));
        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC, HexItems.CHARGED_AMETHYST,
                (int) (MediaConstants.QUENCHED_SHARD_UNIT / MediaConstants.CRYSTAL_UNIT) + 1)
            .input(HexItems.QUENCHED_SHARD)
            .input(HexItems.CHARGED_AMETHYST)
            .criterion("has_item", hasItem(HexItems.QUENCHED_SHARD))
            .offerTo(recipes, modLoc("decompose_quenched_shard/charged"));

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SLATE_BLOCK)
            .input('S', HexItems.SLATE)
            .pattern("S")
            .pattern("S")
            .criterion("has_item", hasItem(HexItems.SLATE))
            .offerTo(recipes, modLoc("slate_block_from_slates"));

        ringAll(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SLATE_BLOCK, 8, Blocks.DEEPSLATE, HexItems.AMETHYST_DUST)
            .criterion("has_item", hasItem(HexItems.SLATE)).offerTo(recipes);

        packing(RecipeCategory.BUILDING_BLOCKS, HexItems.AMETHYST_DUST, HexBlocks.AMETHYST_DUST_BLOCK.asItem(), "amethyst_dust",
            false, recipes);

        ringAll(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SCROLL_PAPER, 8, Items.PAPER, Items.AMETHYST_SHARD)
            .criterion("has_item", hasItem(Items.AMETHYST_SHARD)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.ANCIENT_SCROLL_PAPER, 8)
            .input(ingredients.dyes().get(DyeColor.BROWN))
            .input(HexBlocks.SCROLL_PAPER, 8)
            .criterion("has_item", hasItem(HexBlocks.SCROLL_PAPER)).offerTo(recipes);

        stack(RecipeCategory.DECORATIONS, HexBlocks.SCROLL_PAPER_LANTERN, 1, HexBlocks.SCROLL_PAPER, Items.TORCH)
            .criterion("has_item", hasItem(HexBlocks.SCROLL_PAPER)).offerTo(recipes);

        stack(RecipeCategory.DECORATIONS, HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN, 1, HexBlocks.ANCIENT_SCROLL_PAPER, Items.TORCH)
            .criterion("has_item", hasItem(HexBlocks.ANCIENT_SCROLL_PAPER)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.DECORATIONS, HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN, 8)
            .input(ingredients.dyes().get(DyeColor.BROWN))
            .input(HexBlocks.SCROLL_PAPER_LANTERN, 8)
            .criterion("has_item", hasItem(HexBlocks.SCROLL_PAPER_LANTERN))
            .offerTo(recipes, modLoc("ageing_scroll_paper_lantern"));

        stack(RecipeCategory.DECORATIONS, HexBlocks.SCONCE, 4,
            Ingredient.ofItems(HexItems.CHARGED_AMETHYST),
            ingredients.copperIngot())
            .criterion("has_item", hasItem(HexItems.CHARGED_AMETHYST)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_PLANKS, 4)
            .input(HexTags.Items.EDIFIED_LOGS)
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_LOGS)).offerTo(recipes);

        for (var entry : EDIFIED_LOG_TO_WOOD.entrySet()) {
            var log = entry.getKey();
            var wood = entry.getValue();
            ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, wood, 3)
                    .input('W', log)
                    .pattern("WW")
                    .pattern("WW")
                    .criterion("has_item", hasItem(log)).offerTo(recipes);
        }

        ring(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_PANEL, 8,
            HexTags.Items.EDIFIED_PLANKS, null)
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_TILE, 6)
            .input('W', HexTags.Items.EDIFIED_PLANKS)
            .pattern("WW ")
            .pattern("W W")
            .pattern(" WW")
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.EDIFIED_DOOR, 3)
            .input('W', HexTags.Items.EDIFIED_PLANKS)
            .pattern("WW")
            .pattern("WW")
            .pattern("WW")
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.EDIFIED_TRAPDOOR, 2)
            .input('W', HexTags.Items.EDIFIED_PLANKS)
            .pattern("WWW")
            .pattern("WWW")
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_STAIRS, 4)
            .input('W', HexTags.Items.EDIFIED_PLANKS)
            .pattern("W  ")
            .pattern("WW ")
            .pattern("WWW")
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_FENCE, 3)
                .input('W', HexTags.Items.EDIFIED_PLANKS)
                .input('S', Items.STICK)
                .pattern("WSW")
                .pattern("WSW")
                .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_FENCE_GATE, 1)
                .input('W', HexTags.Items.EDIFIED_PLANKS)
                .input('S', Items.STICK)
                .pattern("SWS")
                .pattern("SWS")
                .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);


        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.EDIFIED_SLAB, 6)
            .input('W', HexTags.Items.EDIFIED_PLANKS)
            .pattern("WWW")
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.EDIFIED_PRESSURE_PLATE, 1)
            .input('W', HexTags.Items.EDIFIED_PLANKS)
            .pattern("WW")
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.EDIFIED_BUTTON)
            .input(HexTags.Items.EDIFIED_PLANKS)
            .criterion("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).offerTo(recipes);

        var enlightenment = HexAdvancements.ENLIGHTEN;
        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.IMPETUS_EMPTY)
            .input('B', Items.IRON_BARS)
            .input('A', HexItems.CHARGED_AMETHYST)
            .input('S', HexBlocks.SLATE_BLOCK)
            .input('P', Items.PURPUR_BLOCK)
            .pattern("PSS")
            .pattern("BAB")
            .pattern("SSP")
            .criterion("enlightenment", enlightenment).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.EMPTY_DIRECTRIX)
            .input('C', Items.COMPARATOR)
            .input('O', Items.OBSERVER)
            .input('A', HexItems.CHARGED_AMETHYST)
            .input('S', HexBlocks.SLATE_BLOCK)
            .pattern("CSS")
            .pattern("OAO")
            .pattern("SSC")
            .criterion("enlightenment", enlightenment).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.AKASHIC_BOOKSHELF)
            .input('L', HexTags.Items.EDIFIED_LOGS)
            .input('P', HexTags.Items.EDIFIED_PLANKS)
            .input('C', Items.BOOK)
            /*this is the*/.pattern("LPL") // and what i have for you today is
            .pattern("CCC")
            .pattern("LPL")
            .criterion("enlightenment", enlightenment).offerTo(recipes);

        ShapedRecipeJsonBuilder.create(RecipeCategory.REDSTONE, HexBlocks.AKASHIC_LIGATURE, 4)
            .input('L', HexTags.Items.EDIFIED_LOGS)
            .input('P', HexTags.Items.EDIFIED_PLANKS)
            .input('1', HexItems.AMETHYST_DUST)
            .input('2', Items.AMETHYST_SHARD)
            .input('3', HexItems.CHARGED_AMETHYST)
            .pattern("LPL")
            .pattern("123")
            .pattern("LPL")
            .criterion("enlightenment", enlightenment).offerTo(recipes);

        // Stone sets
        stoneSet(recipes, HexBlocks.SLATE_BLOCK.asItem(), HexBlocks.SLATE_BRICKS.asItem(), HexBlocks.SLATE_BRICKS_SMALL.asItem(), HexBlocks.SLATE_TILES.asItem(), HexBlocks.SLATE_PILLAR.asItem());
        stoneSet(recipes, Blocks.AMETHYST_BLOCK.asItem(), HexBlocks.AMETHYST_BRICKS.asItem(), HexBlocks.AMETHYST_BRICKS_SMALL.asItem(), HexBlocks.AMETHYST_TILES.asItem(), HexBlocks.AMETHYST_PILLAR.asItem());
        stoneSet(recipes, HexBlocks.QUENCHED_ALLAY.asItem(), HexBlocks.QUENCHED_ALLAY_BRICKS.asItem(), HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.asItem(), HexBlocks.QUENCHED_ALLAY_TILES.asItem(), null);

        // Stone sets in stonecutter
        stoneCutterFromTag(recipes, HexTags.Items.SLATE_BLOCKS, HexBlocks.SLATE_BRICKS.asItem(), HexBlocks.SLATE_BRICKS_SMALL.asItem(), HexBlocks.SLATE_TILES.asItem(), HexBlocks.SLATE_PILLAR.asItem());
        stoneCutterFromTag(recipes, HexTags.Items.AMETHYST_BLOCKS, HexBlocks.AMETHYST_BRICKS.asItem(), HexBlocks.AMETHYST_BRICKS_SMALL.asItem(), HexBlocks.AMETHYST_TILES.asItem(), HexBlocks.AMETHYST_PILLAR.asItem());
        stoneCutterFromTag(recipes, HexTags.Items.QUENCHED_ALLAY_BLOCKS, HexBlocks.QUENCHED_ALLAY_BRICKS.asItem(), HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.asItem(), HexBlocks.QUENCHED_ALLAY_TILES.asItem());

        // Slate & Amethyst block set
        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SLATE_AMETHYST_BRICKS.asItem(), 2)
                .input(HexBlocks.SLATE_BRICKS)
                .input(HexBlocks.AMETHYST_BRICKS)
                .criterion("has_item", conditionsFromItem(HexBlocks.SLATE)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SLATE_AMETHYST_BRICKS_SMALL.asItem(), 2)
                .input(HexBlocks.SLATE_BRICKS_SMALL)
                .input(HexBlocks.AMETHYST_BRICKS_SMALL)
                .criterion("has_item", conditionsFromItem(HexBlocks.SLATE)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SLATE_AMETHYST_TILES.asItem(), 2)
                .input(HexBlocks.SLATE_TILES)
                .input(HexBlocks.AMETHYST_TILES)
                .criterion("has_item", conditionsFromItem(HexBlocks.SLATE)).offerTo(recipes);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, HexBlocks.SLATE_AMETHYST_PILLAR.asItem(), 2)
                .input(HexBlocks.SLATE_PILLAR)
                .input(HexBlocks.AMETHYST_PILLAR)
                .criterion("has_item", conditionsFromItem(HexBlocks.SLATE)).offerTo(recipes);

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(Blocks.AMETHYST_BLOCK),
            new VillagerIngredient(null, null, 3),
            Blocks.BUDDING_AMETHYST.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/budding_amethyst"));

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(HexBlocks.IMPETUS_EMPTY),
            new VillagerIngredient(VillagerProfession.TOOLSMITH, null, 2),
            HexBlocks.IMPETUS_RIGHTCLICK.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/impetus_rightclick"));

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(HexBlocks.IMPETUS_EMPTY),
            new VillagerIngredient(VillagerProfession.FLETCHER, null, 2),
            HexBlocks.IMPETUS_LOOK.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/impetus_look"));

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(HexBlocks.IMPETUS_EMPTY),
            new VillagerIngredient(VillagerProfession.CLERIC, null, 2),
            HexBlocks.IMPETUS_REDSTONE.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/impetus_storedplayer"));

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(HexBlocks.EMPTY_DIRECTRIX),
            new VillagerIngredient(VillagerProfession.MASON, null, 1),
            HexBlocks.DIRECTRIX_REDSTONE.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/directrix_redstone"));

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(HexBlocks.EMPTY_DIRECTRIX),
                new VillagerIngredient(VillagerProfession.SHEPHERD, null, 1),
                HexBlocks.DIRECTRIX_BOOLEAN.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
                .criterion("enlightenment", enlightenment)
                .offerTo(recipes, modLoc("brainsweep/directrix_boolean"));

        new BrainsweepRecipeBuilder(StateIngredientHelper.of(HexBlocks.AKASHIC_LIGATURE),
            new VillagerIngredient(VillagerProfession.LIBRARIAN, null, 5),
            HexBlocks.AKASHIC_RECORD.getDefaultState(), MediaConstants.CRYSTAL_UNIT * 10)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/akashic_record"));

        // Temporary tests
        new BrainsweepRecipeBuilder(StateIngredientHelper.of(Blocks.AMETHYST_BLOCK),
            new EntityTypeIngredient(EntityType.ALLAY),
            HexBlocks.QUENCHED_ALLAY.getDefaultState(), MediaConstants.CRYSTAL_UNIT)
            .criterion("enlightenment", enlightenment)
            .offerTo(recipes, modLoc("brainsweep/quench_allay"));

        // Create compat
        this.conditions.apply(new CreateCrushingRecipeBuilder()
                .withInput(Blocks.AMETHYST_CLUSTER)
                .duration(150)
                .withOutput(Items.AMETHYST_SHARD, 7)
                .withOutput(HexItems.AMETHYST_DUST, 5)
                .withOutput(0.25f, HexItems.CHARGED_AMETHYST))
            .whenModLoaded("create")
            .offerTo(recipes, new Identifier("create", "crushing/amethyst_cluster"));

        this.conditions.apply(new CreateCrushingRecipeBuilder()
                .withInput(Blocks.AMETHYST_BLOCK)
                .duration(150)
                .withOutput(Items.AMETHYST_SHARD, 3)
                .withOutput(0.5f, HexItems.AMETHYST_DUST, 4))
            .whenModLoaded("create")
            .offerTo(recipes, new Identifier("create", "crushing/amethyst_block"));

        this.conditions.apply(new CreateCrushingRecipeBuilder()
                .withInput(Items.AMETHYST_SHARD)
                .duration(150)
                .withOutput(HexItems.AMETHYST_DUST, 4)
                .withOutput(0.5f, HexItems.AMETHYST_DUST))
            .whenModLoaded("create")
            .offerTo(recipes, modLoc("compat/create/crushing/amethyst_shard"));

        // FD compat
        for (var log : EDIFIED_LOGS) {
            this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                    .withInput(log)
                    .withTool(ingredients.axeStrip())
                    .withOutput(HexBlocks.STRIPPED_EDIFIED_LOG)
                    .withOutput("farmersdelight:tree_bark")
                    .withSound(SoundEvents.ITEM_AXE_STRIP))
                .whenModLoaded("farmersdelight")
                .offerTo(recipes, modLoc("compat/farmersdelight/cutting/" + Registries.BLOCK.getId(log).getPath()));
        }

        this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                .withInput(HexBlocks.EDIFIED_WOOD)
                .withTool(ingredients.axeStrip())
                .withOutput(HexBlocks.STRIPPED_EDIFIED_WOOD)
                .withOutput("farmersdelight:tree_bark")
                .withSound(SoundEvents.ITEM_AXE_STRIP))
            .whenModLoaded("farmersdelight")
            .offerTo(recipes, modLoc("compat/farmersdelight/cutting/akashic_wood"));

        this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                .withInput(HexBlocks.EDIFIED_TRAPDOOR)
                .withTool(ingredients.axeDig())
                .withOutput(HexBlocks.EDIFIED_PLANKS))
            .whenModLoaded("farmersdelight")
            .offerTo(recipes, modLoc("compat/farmersdelight/cutting/akashic_trapdoor"));

        this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                .withInput(HexBlocks.EDIFIED_DOOR)
                .withTool(ingredients.axeDig())
                .withOutput(HexBlocks.EDIFIED_PLANKS))
            .whenModLoaded("farmersdelight")
            .offerTo(recipes, modLoc("compat/farmersdelight/cutting/akashic_door"));
    }

    private void staffRecipe(Consumer<RecipeJsonProvider> recipes, ItemStaff staff, Item plank) {
        staffRecipe(recipes, staff, Ingredient.ofItems(plank));
    }

    private void staffRecipe(Consumer<RecipeJsonProvider> recipes, ItemStaff staff, Ingredient plank) {
        ShapedRecipeJsonBuilder.create(RecipeCategory.TOOLS, staff)
            .input('W', plank)
            .input('S', Items.STICK)
            .input('A', HexItems.CHARGED_AMETHYST)
            .pattern(" SA")
            .pattern(" WS")
            .pattern("S  ")
            .criterion("has_item", hasItem(HexItems.CHARGED_AMETHYST))
            .offerTo(recipes);
    }

    private void gayRecipe(Consumer<RecipeJsonProvider> recipes, ItemPridePigment.Type type, Ingredient material) {
        var colorizer = HexItems.PRIDE_PIGMENTS.get(type);
        ShapedRecipeJsonBuilder.create(RecipeCategory.MISC, colorizer)
            .input('D', HexItems.AMETHYST_DUST)
            .input('C', material)
            .pattern(" D ")
            .pattern("DCD")
            .pattern(" D ")
            .criterion("has_item", hasItem(HexItems.AMETHYST_DUST))
            .offerTo(recipes);
    }

    private void specialRecipe(Consumer<RecipeJsonProvider> consumer, SpecialRecipeSerializer<?> serializer) {
        var name = Registries.RECIPE_SERIALIZER.getId(serializer);
        ComplexRecipeJsonBuilder.create(serializer).offerTo(consumer, HexAPI.MOD_ID + ":dynamic" + name.getPath());
    }

    private void stoneSet(Consumer<RecipeJsonProvider> recipes, Item base, Item bricks, Item smallBricks, Item tiles, @Nullable Item pillar) {
        // Bricks from base block
        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, bricks, 4)
                .input('#', base)
                .pattern("##")
                .pattern("##")
                .criterion("has_item", hasItem(base))
                .offerTo(recipes);

        // Bricks from small bricks
        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, bricks)
                .input(smallBricks)
                .criterion("has_item", hasItem(base))
                .offerTo(recipes, modLoc(bricks + "_from_" + smallBricks));

        // Small bricks from bricks
        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, smallBricks)
                .input(bricks)
                .criterion("has_item", hasItem(base))
                .offerTo(recipes, modLoc(smallBricks + "_from_" + bricks));

        // Tiles from bricks
        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, tiles, 4)
                .input('#', bricks)
                .pattern("##")
                .pattern("##")
                .criterion("has_item", hasItem(base))
                .offerTo(recipes);

        // Pillar from base block
        if (pillar != null) {
            ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, pillar, 2)
                    .input('#', base)
                    .pattern("#")
                    .pattern("#")
                    .criterion("has_item", hasItem(base))
                    .offerTo(recipes);
        }
    }

    private void stoneCutterFromTag(Consumer<RecipeJsonProvider> recipes, TagKey<Item> tagKey, Item ...results) {
        for (Item result : results) {
            SingleItemRecipeJsonBuilder.createStonecutting(Ingredient.fromTag(tagKey), RecipeCategory.BUILDING_BLOCKS, result)
                    .criterion("has_item", hasItem(tagKey))
                    .offerTo(recipes, modLoc("stonecutting/" + result));
        }
    }
}
