package at.petrak.hexcasting.mixin.accessor;

import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.advancement.criterion.Criterion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Criteria.class)
public interface CriteriaTriggersAccessor {
    @Invoker("register")
    static <T extends Criterion<?>> T hex$register(T trigger) {
        throw new UnsupportedOperationException();
    }
}
