package at.petrak.hexcasting.fabric.cc;

import at.petrak.hexcasting.api.casting.eval.env.StaffCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import dev.onyxstudios.cca.api.v3.component.Component;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import org.jetbrains.annotations.Nullable;

public class CCStaffcastImage implements Component {
    public static final String TAG_VM = "harness";

    private final ServerPlayerEntity owner;
    private NbtCompound lazyLoadedTag = new NbtCompound();

    public CCStaffcastImage(ServerPlayerEntity owner) {
        this.owner = owner;
    }

    /**
     * Turn the saved image into a VM in a player staffcasting environment
     */
    public CastingVM getVM(Hand hand) {
        var img = this.lazyLoadedTag.isEmpty()
            ? new CastingImage()
            : CastingImage.loadFromNbt(this.lazyLoadedTag, this.owner.getServerWorld());
        var env = new StaffCastEnv(this.owner, hand);
        return new CastingVM(img, env);
    }

    public void setImage(@Nullable CastingImage image) {
        this.lazyLoadedTag =
            image == null
                ? new NbtCompound()
                : image.serializeToNbt();
    }

    @Override
    public void readFromNbt(NbtCompound tag) {
        this.lazyLoadedTag = tag.getCompound(TAG_VM);
    }

    @Override
    public void writeToNbt(NbtCompound tag) {
        tag.put(TAG_VM, this.lazyLoadedTag);
    }
}
