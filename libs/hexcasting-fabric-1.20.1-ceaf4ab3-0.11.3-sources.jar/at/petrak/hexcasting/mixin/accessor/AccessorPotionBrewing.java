package at.petrak.hexcasting.mixin.accessor;

import net.minecraft.item.Item;
import net.minecraft.potion.Potion;
import net.minecraft.recipe.BrewingRecipeRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(BrewingRecipeRegistry.class)
public interface AccessorPotionBrewing {
    @Invoker("addMix")
    static void addMix(Potion p_43514_, Item p_43515_, Potion p_43516_) {
    }
}
