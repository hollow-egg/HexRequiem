package at.petrak.hexcasting.common.blocks.circles.directrix;

import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.iota.BooleanIota;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.mishaps.circle.MishapBoolDirectrixEmptyStack;
import at.petrak.hexcasting.api.casting.mishaps.circle.MishapBoolDirectrixNotBool;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

// When pops a true, outputs to FACING, when pops a false, outputs to the opposite
public class BlockBooleanDirectrix extends BlockCircleComponent {
    public static final DirectionProperty FACING = Properties.FACING;
    public static final EnumProperty<State> STATE = EnumProperty.of("state", State.class);

    public BlockBooleanDirectrix(Settings properties) {
        super(properties);
        this.setDefaultState(this.stateManager.getDefaultState()
            .with(ENERGIZED, false)
            .with(STATE, State.NEITHER)
            .with(FACING, Direction.NORTH));
    }

    @Override
    public ControlFlow acceptControlFlow(CastingImage imageIn, CircleCastEnv env, Direction enterDir, BlockPos pos,
        BlockState bs, ServerWorld world) {
        var stack = new ArrayList<>(imageIn.getStack());
        if (stack.isEmpty()) {
            this.fakeThrowMishap(pos, bs, imageIn, env,
                new MishapBoolDirectrixEmptyStack(pos));
            return new ControlFlow.Stop();
        }
        var last = stack.remove(stack.size() - 1);

        if (!(last instanceof BooleanIota biota)) {
            this.fakeThrowMishap(pos, bs, imageIn, env,
                new MishapBoolDirectrixNotBool(last, pos));
            return new ControlFlow.Stop();
        }

        world.setBlockState(pos, bs.with(STATE, biota.getBool() ? State.TRUE : State.FALSE));

        var outputDir = biota.getBool()
            ? bs.get(FACING).getOpposite()
            : bs.get(FACING);
        var imageOut = imageIn.copy(stack, imageIn.getParenCount(), imageIn.getParenthesized(),
            imageIn.getEscapeNext(), imageIn.getOpsConsumed(), imageIn.getUserData());

        return new ControlFlow.Continue(imageOut, List.of(this.exitPositionFromDirection(pos, outputDir)));
    }

    @Override
    public boolean canEnterFromDirection(Direction enterDir, BlockPos pos, BlockState bs, ServerWorld world) {
        // No entering from either of the output faces
        return enterDir != bs.get(FACING).getOpposite() && enterDir != bs.get(FACING);
    }

    @Override
    public EnumSet<Direction> possibleExitDirections(BlockPos pos, BlockState bs, World world) {
        return EnumSet.of(bs.get(FACING), bs.get(FACING).getOpposite());
    }

    @Override
    public Direction normalDir(BlockPos pos, BlockState bs, World world, int recursionLeft) {
        return normalDirOfOther(pos.offset(bs.get(FACING)), world, recursionLeft);
    }

    @Override
    public float particleHeight(BlockPos pos, BlockState bs, World world) {
        return 0.5f;
    }

    @Override
    public BlockState endEnergized(BlockPos pos, BlockState bs, World world) {
        var newState = bs.with(ENERGIZED, false).with(STATE, State.NEITHER);
        world.setBlockState(pos, newState);
        return newState;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(STATE, FACING);
    }


    @Override
    public BlockState getPlacementState(ItemPlacementContext pContext) {
        return BlockCircleComponent.placeStateDirAndSneak(this.getDefaultState(), pContext);
    }

    @Override
    public BlockState rotate(BlockState pState, BlockRotation pRot) {
        return pState.with(FACING, pRot.rotate(pState.get(FACING)));
    }

    @Override
    public BlockState mirror(BlockState pState, BlockMirror pMirror) {
        return pState.rotate(pMirror.getRotation(pState.get(FACING)));
    }

    public enum State implements StringIdentifiable {
        // Freshly started
        NEITHER,
        // Popped a true
        TRUE,
        // Popped a false
        FALSE,
        ;

        @Override
        public String asString() {
            return this.name().toLowerCase(Locale.ROOT);
        }
    }
}
