package at.petrak.hexcasting.client.render.shader;

import at.petrak.hexcasting.mixin.accessor.client.AccessorCompositeRenderType;
import at.petrak.hexcasting.mixin.accessor.client.AccessorEmptyTextureStateShard;
import at.petrak.hexcasting.mixin.accessor.client.AccessorRenderStateShard;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.function.Function;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.util.Identifier;

public record FakeBufferSource(VertexConsumerProvider parent,
                               Function<Identifier, RenderLayer> mapper) implements VertexConsumerProvider {

    @Override
    @SuppressWarnings("ConstantConditions")
    public @NotNull VertexConsumer getBuffer(@NotNull RenderLayer renderType) {
        if (((AccessorRenderStateShard) renderType).hex$name().equals("entity_cutout_no_cull")
            && renderType instanceof RenderLayer.MultiPhase) {
            RenderLayer.MultiPhaseParameters state = ((AccessorCompositeRenderType) renderType).hex$state();
            RenderPhase.TextureBase shard = state.field_21406;
            Optional<Identifier> texture = ((AccessorEmptyTextureStateShard) shard).hex$cutoutTexture();
            if (texture.isPresent()) {
                return parent.getBuffer(mapper.apply(texture.get()));
            }
        }
        return parent.getBuffer(renderType);
    }
}
