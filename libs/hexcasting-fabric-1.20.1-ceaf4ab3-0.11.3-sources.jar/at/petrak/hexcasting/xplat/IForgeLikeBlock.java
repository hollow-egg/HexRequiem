package at.petrak.hexcasting.xplat;

import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

/**
 * An interface that mimics some methods of IForgeBlock.
 * Fabric implementation will use mixins to achieve the same effects.
 */
public interface IForgeLikeBlock {
    default boolean addLandingEffects(BlockState state, ServerWorld level, BlockPos pos, LivingEntity entity, int numberOfParticles) {
        return false;
    }

    default boolean hasEnchantPowerBonus(BlockState state, WorldView level, BlockPos pos) {
        return false;
    }
}
