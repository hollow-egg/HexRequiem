package at.petrak.hexcasting.common.items;

import com.google.common.collect.Multimap;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.ItemStack;

/**
 * Why don't we just use the same API mod on Forge and Fabric? Beats me. botania does it like this.
 * I feel like botnia probably does it this way becase it's older than xplat curios
 */
public interface HexBaubleItem {
    Multimap<EntityAttribute, EntityAttributeModifier> getHexBaubleAttrs(ItemStack stack);
}
