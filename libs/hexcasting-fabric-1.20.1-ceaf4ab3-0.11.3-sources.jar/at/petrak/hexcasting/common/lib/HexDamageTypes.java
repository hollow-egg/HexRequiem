package at.petrak.hexcasting.common.lib;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import net.minecraft.entity.damage.DamageScaling;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.registry.Registerable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

public class HexDamageTypes {
    public static final RegistryKey<DamageType> OVERCAST = RegistryKey.of(RegistryKeys.DAMAGE_TYPE, modLoc("overcast"));

    public static void bootstrap(Registerable<DamageType> ctx) {
        ctx.register(OVERCAST, new DamageType(
            "hexcasting.overcast",
            DamageScaling.WHEN_CAUSED_BY_LIVING_NON_PLAYER,
            0f
        ));
    }
}
