package at.petrak.hexcasting.common.misc;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;

/**
 * Dodge protected ctor
 */
public class HexMobEffect extends StatusEffect {
    public HexMobEffect(StatusEffectCategory category, int color) {
        super(category, color);
    }
}
