package at.petrak.hexcasting.common.msgs;

import io.netty.buffer.Unpooled;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

// https://github.com/VazkiiMods/Botania/blob/1.18.x/Common/src/main/java/vazkii/botania/network/IPacket.java
// yoink
public interface IMessage {
    default PacketByteBuf toBuf() {
        var ret = new PacketByteBuf(Unpooled.buffer());
        serialize(ret);
        return ret;
    }

    void serialize(PacketByteBuf buf);

    /**
     * Forge auto-assigns incrementing integers, Fabric requires us to declare an ID
     * These are sent using vanilla's custom plugin channel system and thus are written to every single packet.
     * So this ID tends to be more terse.
     */
    Identifier getFabricId();
}
