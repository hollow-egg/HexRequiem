package at.petrak.hexcasting.common.blocks.akashic;

import Z;
import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.client.render.HexPatternPoints;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public class BlockEntityAkashicBookshelf extends HexBlockEntity {
    public static final String TAG_PATTERN = "pattern";
    public static final String TAG_IOTA = "iota";
    public static final String TAG_DUMMY = "dummy";

    // This is only not null if this stores any data.
    private HexPattern pattern = null;
    // When the world is first loading we can sometimes try to deser this from nbt without the world existing yet.
    // We also need a way to display the iota to the client.
    // For both these cases we save just the tag of the iota.
    private NbtCompound iotaTag = null;

    public HexPatternPoints points;

    public BlockEntityAkashicBookshelf(BlockPos pWorldPosition, BlockState pBlockState) {
        super(HexBlockEntities.AKASHIC_BOOKSHELF_TILE, pWorldPosition, pBlockState);
    }

    @Nullable
    public HexPattern getPattern() {
        return pattern;
    }

    @Nullable
    public NbtCompound getIotaTag() {
        return iotaTag;
    }

    public void setNewMapping(HexPattern pattern, Iota iota) {
        var previouslyEmpty = this.pattern == null;
        this.pattern = pattern;
        this.iotaTag = IotaType.serialize(iota);

        if (previouslyEmpty) {
            var oldBs = this.getCachedState();
            var newBs = oldBs.with(BlockAkashicBookshelf.HAS_BOOKS, true);
            this.world.setBlockState(this.getPos(), newBs, 3);
            this.world.updateListeners(this.getPos(), oldBs, newBs, 3);
        } else {
            this.markDirty();
        }
    }

    public void clearIota() {
        var previouslyEmpty = this.pattern == null;
        this.pattern = null;
        this.iotaTag = null;

        if (!previouslyEmpty) {
            var oldBs = this.getCachedState();
            var newBs = oldBs.with(BlockAkashicBookshelf.HAS_BOOKS, false);
            this.world.setBlockState(this.getPos(), newBs, 3);
            this.world.updateListeners(this.getPos(), oldBs, newBs, 3);
        } else {
            this.markDirty();
        }
    }

    @Override
    protected void saveModData(NbtCompound compoundTag) {
        if (this.pattern != null && this.iotaTag != null) {
            compoundTag.put(TAG_PATTERN, this.pattern.serializeToNBT());
            compoundTag.put(TAG_IOTA, this.iotaTag);
        } else {
            compoundTag.putBoolean(TAG_DUMMY, false);
        }
    }

    @Override
    protected void loadModData(NbtCompound tag) {
        if (tag.contains(TAG_PATTERN) && tag.contains(TAG_IOTA)) {
            this.pattern = HexPattern.fromNBT(tag.getCompound(TAG_PATTERN));
            this.iotaTag = tag.getCompound(TAG_IOTA);
        } else if (tag.contains(TAG_DUMMY)) {
            this.pattern = null;
            this.iotaTag = null;
        }
    }
}
