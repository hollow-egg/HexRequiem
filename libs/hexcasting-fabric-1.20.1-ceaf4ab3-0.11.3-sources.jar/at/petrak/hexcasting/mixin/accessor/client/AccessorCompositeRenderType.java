package at.petrak.hexcasting.mixin.accessor.client;

import net.minecraft.client.render.RenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderLayer.MultiPhase.class)
public interface AccessorCompositeRenderType {
    @Invoker("state")
    RenderLayer.MultiPhaseParameters hex$state();
}
