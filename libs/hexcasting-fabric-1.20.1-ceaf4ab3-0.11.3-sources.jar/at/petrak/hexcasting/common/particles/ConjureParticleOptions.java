package at.petrak.hexcasting.common.particles;

import I;
import at.petrak.hexcasting.common.lib.HexParticles;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;

public record ConjureParticleOptions(int color) implements ParticleEffect {
    @Override
    public ParticleType<?> getType() {
        return HexParticles.CONJURE_PARTICLE;
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeInt(this.color);
    }

    @Override
    public String asString() {
        return String.format(Locale.ROOT, "%s %s", this.color);
    }

    public static final Factory<ConjureParticleOptions> DESERIALIZER = new Factory<>() {
        @Override
        public ConjureParticleOptions read(ParticleType<ConjureParticleOptions> type,
            StringReader reader) throws CommandSyntaxException {

            reader.expect(' ');
            var color = reader.readInt();
            return new ConjureParticleOptions(color);
        }

        @Override
        public ConjureParticleOptions read(ParticleType<ConjureParticleOptions> type,
            PacketByteBuf buf) {
            var col = buf.readInt();
            return new ConjureParticleOptions(col);
        }
    };

    public static class Type extends ParticleType<ConjureParticleOptions> {
        public Type(boolean pOverrideLimiter) {
            super(pOverrideLimiter, DESERIALIZER);
        }

        public static final Codec<ConjureParticleOptions> CODEC = RecordCodecBuilder.create(
            instance -> instance.group(
                    Codec.INT.fieldOf("color")
                        .forGetter((ConjureParticleOptions o) -> o.color)
                )
                .apply(instance, ConjureParticleOptions::new)
        );

        @Override
        public Codec<ConjureParticleOptions> getCodec() {
            return CODEC;
        }
    }
}
