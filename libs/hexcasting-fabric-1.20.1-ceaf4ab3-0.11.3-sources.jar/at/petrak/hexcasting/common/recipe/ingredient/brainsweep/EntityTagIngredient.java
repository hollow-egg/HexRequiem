package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.world.World;

public class EntityTagIngredient extends BrainsweepeeIngredient {
    public final TagKey<EntityType<?>> entityTypeTag;

    public EntityTagIngredient(TagKey<EntityType<?>> tag) {
        this.entityTypeTag = tag;
    }

    @Override
    public boolean test(Entity entity, ServerWorld level) {
        return entity.getType().isIn(this.entityTypeTag);
    }

    private static String tagKey(Identifier tagLoc) {
        return "tag."
            + tagLoc.getNamespace()
            + "."
            + tagLoc.getPath().replace('/', '.');
    }

    @Override
    public Text getName() {
        String key = tagKey(this.entityTypeTag.id());
        boolean moddersDidAGoodJob = I18n.hasTranslation(key);
        return moddersDidAGoodJob
            ? Text.translatable(key)
            : Text.literal("#" + this.entityTypeTag.id());
    }

    @Override
    public List<Text> getTooltip(boolean advanced) {
        Identifier loc = this.entityTypeTag.id();
        String key = tagKey(loc);
        boolean moddersDidAGoodJob = I18n.hasTranslation(key);

        var out = new ArrayList<Text>();
        out.add(moddersDidAGoodJob
            ? Text.translatable(key)
            : Text.literal("#" + loc));
        if (advanced && moddersDidAGoodJob) {
            // Print it anyways
            out.add(Text.literal("#" + loc).formatted(Formatting.DARK_GRAY));
        }

        out.add(BrainsweepeeIngredient.getModNameComponent(loc.getNamespace()));

        return out;
    }

    @Override
    public Entity exampleEntity(World level) {
        var someEntityTys = Registries.ENTITY_TYPE.iterateEntries(this.entityTypeTag).iterator();
        if (someEntityTys.hasNext()) {
            var someTy = someEntityTys.next();
            return someTy.value().create(level);
        } else {
            return null;
        }
    }

    @Override
    public JsonObject serialize() {
        var obj = new JsonObject();
        obj.addProperty("type", Type.ENTITY_TAG.asString());

        obj.addProperty("tag", this.entityTypeTag.id().toString());

        return obj;
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeIdentifier(this.entityTypeTag.id());
    }

    public static EntityTagIngredient deserialize(JsonObject obj) {
        var tagLoc = Identifier.tryParse(JsonHelper.getString(obj, "tag"));
        if (tagLoc == null) {
            throw new IllegalArgumentException("unknown tag " + obj);
        }
        var type = TagKey.of(RegistryKeys.ENTITY_TYPE, tagLoc);
        return new EntityTagIngredient(type);
    }

    public static EntityTagIngredient read(PacketByteBuf buf) {
        var typeLoc = buf.readIdentifier();
        var type = TagKey.of(RegistryKeys.ENTITY_TYPE, typeLoc);
        return new EntityTagIngredient(type);
    }

    @Override
    public Type ingrType() {
        return Type.ENTITY_TAG;
    }

    @Override
    public String getSomeKindOfReasonableIDForEmi() {
        var resloc = this.entityTypeTag.id();
        return resloc.getNamespace()
            + "//"
            + resloc.getPath();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityTagIngredient that = (EntityTagIngredient) o;
        return Objects.equals(entityTypeTag, that.entityTypeTag);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.entityTypeTag);
    }
}
