package at.petrak.hexcasting.common.blocks.akashic;

import at.petrak.hexcasting.api.misc.TriPredicate;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.HashSet;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public interface AkashicFloodfiller {
    default boolean canBeFloodedThrough(BlockPos pos, BlockState state, World world) {
        return true;
    }

    @Nullable
    static BlockPos floodFillFor(BlockPos start, World world, TriPredicate<BlockPos, BlockState, World> isTarget) {
        return floodFillFor(start, world, 0f, isTarget, 128);
    }

    @Nullable
    static BlockPos floodFillFor(BlockPos start, World world, float skipChance,
        TriPredicate<BlockPos, BlockState, World> isTarget, int maxRange) {
        var seenBlocks = new HashSet<BlockPos>();
        var todo = new ArrayDeque<BlockPos>();
        todo.add(start);
        var skippedBlocks = new HashSet<BlockPos>();

        while (!todo.isEmpty()) {
            var here = todo.remove();

            for (var dir : Direction.values()) {
                var neighbor = here.offset(dir);

                if (neighbor.getSquaredDistance(start) > maxRange * maxRange)
                    continue;

                if (seenBlocks.add(neighbor)) {
                    var bs = world.getBlockState(neighbor);
                    if (isTarget.test(neighbor, bs, world)) {
                        if (world.random.nextFloat() > skipChance) {
                            return neighbor;
                        } else {
                            skippedBlocks.add(neighbor);
                        }
                    }
                    if (canItBeFloodedThrough(neighbor, bs, world)) {
                        todo.add(neighbor);
                    }
                }
            }
        }

        if (!skippedBlocks.isEmpty()) {
            // We found something valid, we just skipped past it
            return skippedBlocks.iterator().next();
        }

        return null;
    }

    static boolean canItBeFloodedThrough(BlockPos pos, BlockState state, World world) {
        if (!(state.getBlock() instanceof AkashicFloodfiller flooder)) {
            return false;
        }

        return flooder.canBeFloodedThrough(pos, state, world);
    }
}
