package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.EnchantingTableBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EnchantingTableBlock.class)
public class FabricEnchantmentTableBlockMixin {
    @Inject(method = "isValidBookShelf", at = @At("HEAD"), cancellable = true)
    private static void treatAsBookshelf(World level, BlockPos blockPos, BlockPos blockPos2, CallbackInfoReturnable<Boolean> cir) {
        BlockState state = level.getBlockState(blockPos.add(blockPos2));
        if (state.getBlock() instanceof IForgeLikeBlock forgeLike) {
            boolean emptyBetween = level.isAir(blockPos.add(blockPos2.getX() / 2, blockPos2.getY(), blockPos2.getZ() / 2));
            cir.setReturnValue(emptyBetween && forgeLike.hasEnchantPowerBonus(state, level, blockPos));
        }
    }
}
