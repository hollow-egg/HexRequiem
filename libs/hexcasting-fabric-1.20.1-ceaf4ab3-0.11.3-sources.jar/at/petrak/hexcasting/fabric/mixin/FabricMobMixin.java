package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.fabric.event.VillagerConversionCallback;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MobEntity.class)
public class FabricMobMixin {
    @Inject(method = "convertTo", at = @At("RETURN"))
    public <T extends MobEntity> void onThunderHit(EntityType<T> entityType, boolean bl, CallbackInfoReturnable<T> cir) {
        var self = (MobEntity) (Object) this;
        var mob = cir.getReturnValue();
        if (mob != null) {
            VillagerConversionCallback.EVENT.invoker().interact(self, mob);
        }
    }
}
