package at.petrak.hexcasting.api.pigment;

import I;
import at.petrak.hexcasting.api.addldata.ADPigment;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.Vec3d;

public abstract class ColorProvider {
    /**
     * Implers, impl this function
     */
    protected abstract int getRawColor(float time, Vec3d position);

    private static final int[] MINIMUM_LUMINANCE_COLOR_WHEEL = {
        0xFF200000, 0xFF202000, 0xFF002000, 0xFF002020, 0xFF000020, 0xFF200020
    };

    /**
     * Gets a color with a minimum luminance applied.
     *
     * @param time     absolute world time in ticks
     * @param position a position for the icosahedron, a randomish number for particles.
     * @return an AARRGGBB color.
     */
    public final int getColor(float time, Vec3d position) {
        int raw = this.getRawColor(time, position);

        var r = ColorHelper.Argb.getRed(raw);
        var g = ColorHelper.Argb.getGreen(raw);
        var b = ColorHelper.Argb.getBlue(raw);
        double luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 0xFF; // Standard relative luminance calculation

        if (luminance < 0.05) {
            int rawMod = ADPigment.morphBetweenColors(MINIMUM_LUMINANCE_COLOR_WHEEL, new Vec3d(0.1, 0.1, 0.1),
                time / 20 / 20, position);

            r += ColorHelper.Argb.getRed(rawMod);
            g += ColorHelper.Argb.getGreen(rawMod);
            b += ColorHelper.Argb.getBlue(rawMod);
        }

        return 0xff_000000 | (r << 16) | (g << 8) | b;
    }

    public static final ColorProvider MISSING = new ColorProvider() {
        @Override
        protected int getRawColor(float time, Vec3d position) {
            return 0xFF_ff00dc;
        }
    };
}
