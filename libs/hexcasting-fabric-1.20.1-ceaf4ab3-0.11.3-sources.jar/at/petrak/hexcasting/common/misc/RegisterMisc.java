package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.mixin.accessor.AccessorAbstractArrow;
import at.petrak.hexcasting.mixin.accessor.AccessorVillager;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class RegisterMisc {
    public static void register() {
        HexAPI.instance().registerSpecialVelocityGetter(EntityType.PLAYER, player -> {
            if (player instanceof ServerPlayerEntity splayer) {
                return PlayerPositionRecorder.getMotion(splayer);
            } else {
                // bruh
                throw new IllegalStateException("Call this only on the server side, silly");
            }
        });

        HexAPI.instance().registerSpecialVelocityGetter(EntityType.ARROW, RegisterMisc::arrowVelocitizer);
        HexAPI.instance().registerSpecialVelocityGetter(EntityType.SPECTRAL_ARROW, RegisterMisc::arrowVelocitizer);
        // this is an arrow apparently
        HexAPI.instance().registerSpecialVelocityGetter(EntityType.TRIDENT, RegisterMisc::arrowVelocitizer);

        HexAPI.instance().registerCustomBrainsweepingBehavior(EntityType.VILLAGER, villager -> {
            ((AccessorVillager) villager).hex$releaseAllPois();
            HexAPI.instance().defaultBrainsweepingBehavior().accept(villager);
        });
        HexAPI.instance().registerCustomBrainsweepingBehavior(EntityType.ALLAY, allay -> {
            allay.getBrain().forget(MemoryModuleType.LIKED_PLAYER);
            HexAPI.instance().defaultBrainsweepingBehavior().accept(allay);
        });
    }

    private static Vec3d arrowVelocitizer(PersistentProjectileEntity arrow) {
        if (((AccessorAbstractArrow) arrow).hex$isInGround()) {
            return Vec3d.ZERO;
        } else {
            return arrow.getVelocity();
        }
    }
}
