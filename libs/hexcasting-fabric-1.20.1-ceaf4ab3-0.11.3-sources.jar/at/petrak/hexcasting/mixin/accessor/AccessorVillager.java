package at.petrak.hexcasting.mixin.accessor;

import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.VillagerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(VillagerEntity.class)
public interface AccessorVillager {
    @Invoker("tellWitnessesThatIWasMurdered")
    void hex$tellWitnessesThatIWasMurdered(Entity murderer);

    @Invoker("releaseAllPois")
    void hex$releaseAllPois();
}
