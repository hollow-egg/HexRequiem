package at.petrak.hexcasting.fabric.recipe;

import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.utils.NBTHelper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.github.tropheusj.serialization_hooks.ingredient.BaseCustomIngredient;
import io.github.tropheusj.serialization_hooks.ingredient.IngredientDeserializer;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import java.util.Objects;
import java.util.stream.Stream;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class FabricUnsealedIngredient extends BaseCustomIngredient {
    public static final Identifier ID = modLoc("unsealed");

    private final ItemStack stack;

    private static ItemStack createStack(ItemStack base) {
        ItemStack newStack = base.copy();
        NBTHelper.putString(newStack, IotaHolderItem.TAG_OVERRIDE_VISUALLY, "any");
        return newStack;
    }

    protected FabricUnsealedIngredient(ItemStack stack) {
        super(Stream.of(new Ingredient.StackEntry(createStack(stack))));
        this.stack = stack;
    }

    /**
     * Creates a new ingredient matching the given stack
     */
    public static FabricUnsealedIngredient of(ItemStack stack) {
        return new FabricUnsealedIngredient(stack);
    }

    @Override
    public boolean test(@Nullable ItemStack input) {
        if (input == null) {
            return false;
        }

        return false;
    }

    @Override
    public @NotNull JsonElement toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("type", Objects.toString(ID));
        json.addProperty("item", Objects.toString(Registries.ITEM.getId(this.stack.getItem())));
        return json;
    }

    @Override
    public IngredientDeserializer getDeserializer() {
        return Deserializer.INSTANCE;
    }

    public static Ingredient fromPacket(PacketByteBuf friendlyByteBuf) {
        return new FabricUnsealedIngredient(friendlyByteBuf.readItemStack());
    }

    public static Ingredient fromJson(JsonElement element) {
        if (element == null || element.isJsonNull() || !element.isJsonObject()) {
            return null;
        }

        JsonObject object = element.getAsJsonObject();

        if (object.has("type") && object.getAsJsonPrimitive("type").getAsString().equals(ID.toString())) {
            return new FabricUnsealedIngredient(new ItemStack(ShapedRecipe.getItem(object)));
        }

        return null;
    }

    @Override
    public void write(PacketByteBuf friendlyByteBuf) {
        friendlyByteBuf.writeIdentifier(ID);
        friendlyByteBuf.writeItemStack(stack);
    }

    public static class Deserializer implements IngredientDeserializer {
        public static final Deserializer INSTANCE = new Deserializer();

        @Override
        public Ingredient fromNetwork(PacketByteBuf buffer) {
            return FabricUnsealedIngredient.fromPacket(buffer);
        }

        @Nullable
        @Override
        public Ingredient fromJson(JsonObject object) {
            return FabricUnsealedIngredient.fromJson(object);
        }
    }
}
