package at.petrak.hexcasting.fabric.mixin.client;

import at.petrak.hexcasting.fabric.xplat.FabricClientXplatImpl;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.profiler.Profiler;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(WorldRenderer.class)
public class FabricLevelRendererMixin {
    @SuppressWarnings("InvalidInjectorMethodSignature")
    @Inject(
        method = "renderLevel",
        at = @At(
            value = "INVOKE", target = "Lnet/minecraft/client/renderer/FogRenderer;levelFogColor()V",
            ordinal = 0),
        locals = LocalCapture.CAPTURE_FAILSOFT)
    private void snagFrustumFromLevelRenderer(MatrixStack poseStack, float f, long arg2, boolean bl, Camera camera,
          GameRenderer gameRenderer, LightmapTextureManager lightTexture, Matrix4f matrix4f, CallbackInfo ci,
          Profiler profilerFiller, boolean bl2, Vec3d vec3, double d, double e, double g, Matrix4f matrix4f2,
          boolean bl3, Frustum frustum) {
        FabricClientXplatImpl.LEVEL_RENDERER_FRUSTUM = frustum;
    }
}
