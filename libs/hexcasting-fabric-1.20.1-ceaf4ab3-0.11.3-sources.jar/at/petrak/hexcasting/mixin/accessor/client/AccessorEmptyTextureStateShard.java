package at.petrak.hexcasting.mixin.accessor.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Optional;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.util.Identifier;

@Mixin(RenderPhase.TextureBase.class)
public interface AccessorEmptyTextureStateShard {
    @Invoker("cutoutTexture")
    Optional<Identifier> hex$cutoutTexture();
}
