package at.petrak.hexcasting.fabric.loot;

import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.loot.AddPerWorldPatternToScrollFunc;
import at.petrak.hexcasting.common.loot.AddHexToAncientCypherFunc;
import at.petrak.hexcasting.fabric.FabricHexInitializer;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import net.minecraft.block.Blocks;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.entry.LootTableEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;
import static at.petrak.hexcasting.common.loot.HexLootHandler.TABLE_INJECT_AMETHYST_CLUSTER;

public class FabricHexLootModJankery {
    public static final Identifier FUNC_AMETHYST_SHARD_REDUCER = modLoc("amethyst_shard_reducer");
    public static final Identifier RANDOM_SCROLL_TABLE = modLoc("random_scroll");
    public static final Identifier RANDOM_CYPHER_TABLE = modLoc("random_cypher");

    public static void lootLoad(Identifier id, Consumer<LootPool.Builder> addPool) {
        if (id.equals(Blocks.AMETHYST_CLUSTER.getLootTableId())) {
            addPool.accept(makeAmethystInjectPool());
        } else if (id.equals(RANDOM_SCROLL_TABLE)) {
            // -1 weight = guaranteed spawn
            addPool.accept(makeScrollAddPool(-1));
        } else if (id.equals(RANDOM_CYPHER_TABLE)) {
            // 1 chance = guaranteed spawn
            addPool.accept(makeCypherAddPool(1));
        }

        int countRange = FabricHexInitializer.CONFIG.server.scrollRangeForLootTable(id);
        if (countRange != -1) {
            addPool.accept(makeScrollAddPool(countRange));
        }

        if (FabricHexInitializer.CONFIG.server.shouldInjectLore(id)) {
            addPool.accept(makeLoreAddPool(FabricHexInitializer.CONFIG.server.loreChance()));
        }

        if (FabricHexInitializer.CONFIG.server.shouldInjectCyphers(id)) {
            addPool.accept(makeCypherAddPool(FabricHexInitializer.CONFIG.server.cypherChance()));
        }
    }

    @NotNull
    private static LootPool.Builder makeAmethystInjectPool() {
        return LootPool.builder()
            .with(LootTableEntry.builder(TABLE_INJECT_AMETHYST_CLUSTER));
    }

    private static LootPool.Builder makeScrollAddPool(int range) {
        return LootPool.builder()
            .rolls(range < 0 ? ConstantLootNumberProvider.create(1) : UniformLootNumberProvider.create(-range, range))
            .with(ItemEntry.builder(HexItems.SCROLL_LARGE))
            .apply(() -> new AddPerWorldPatternToScrollFunc(new LootCondition[0]));
    }

    private static LootPool.Builder makeLoreAddPool(double chance) {
        return LootPool.builder()
            .conditionally(RandomChanceLootCondition.builder((float) chance))
            .rolls(ConstantLootNumberProvider.create(1))
            .with(ItemEntry.builder(HexItems.LORE_FRAGMENT));
    }

    private static LootPool.Builder makeCypherAddPool(double chance) {
        return LootPool.builder()
            .conditionally(RandomChanceLootCondition.builder((float) chance))
            .rolls(ConstantLootNumberProvider.create(1))
            .with(ItemEntry.builder(HexItems.ANCIENT_CYPHER))
            .apply(() -> new AddHexToAncientCypherFunc(new LootCondition[0]));
    }
}
