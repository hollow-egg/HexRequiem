package at.petrak.hexcasting.common.blocks;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.common.blocks.entity.BlockEntityConjured;
import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BlockConjured extends Block implements BlockEntityProvider, IForgeLikeBlock {

    public BlockConjured(Settings properties) {
        super(properties);
    }

    @Override
    public void onBreak(World pLevel, BlockPos pPos, BlockState pState, PlayerEntity pPlayer) {
        super.onBreak(pLevel, pPos, pState, pPlayer);
        // For some reason the block doesn't play breaking noises. So we fix that!
        pPlayer.playSound(SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, 1f, 1f);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World pLevel, BlockState pState,
        BlockEntityType<T> pBlockEntityType) {
        if (pLevel.isClient()) {
            return BlockConjured::tick;
        } else {
            return null;
        }
    }

    private static <T extends BlockEntity> void tick(World level, BlockPos blockPos, BlockState blockState, T t) {
        if (t instanceof BlockEntityConjured conjured) {
            conjured.particleEffect();
        }
    }

    @Override
    public void onSteppedOn(World pLevel, @NotNull BlockPos pPos, @NotNull BlockState pState, @NotNull Entity pEntity) {
        BlockEntity tile = pLevel.getBlockEntity(pPos);
        if (tile instanceof BlockEntityConjured bec) {
            bec.walkParticle(pEntity);
        }
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(@NotNull BlockPos pPos, @NotNull BlockState pState) {
        return new BlockEntityConjured(pPos, pState);
    }

    public static void setColor(WorldAccess pLevel, BlockPos pPos, FrozenPigment colorizer) {
        BlockEntity blockentity = pLevel.getBlockEntity(pPos);
        if (blockentity instanceof BlockEntityConjured tile) {
            tile.setColorizer(colorizer);
        }
    }

    @Override
    public void onBlockAdded(@NotNull BlockState pState, World pLevel, @NotNull BlockPos pPos, @NotNull BlockState pOldState,
        boolean pIsMoving) {
        pLevel.updateListeners(pPos, pState, pState, Block.NOTIFY_LISTENERS);
        super.onBlockAdded(pState, pLevel, pPos, pOldState, pIsMoving);
    }

    @Override
    public boolean isTransparent(@NotNull BlockState pState, @NotNull BlockView pLevel,
        @NotNull BlockPos pPos) {
        return true;
    }

    @Override
    public @NotNull VoxelShape getCameraCollisionShape(BlockState pState, BlockView pLevel, BlockPos pPos,
        ShapeContext pContext) {
        return VoxelShapes.empty();
    }

    @Override
    public float getAmbientOcclusionLightLevel(BlockState pState, BlockView pLevel, BlockPos pPos) {
        return 1.0F;
    }

    @Override
    public @NotNull BlockRenderType getRenderType(@NotNull BlockState state) {
        return BlockRenderType.INVISIBLE;
    }

    @Override
    protected void spawnBreakParticles(World pLevel, PlayerEntity pPlayer, BlockPos pPos, BlockState pState) {
        // NO-OP
    }


    @SoftImplement("forge")
    public boolean addLandingEffects(BlockState state1, ServerWorld worldserver, BlockPos pos, BlockState state2,
        LivingEntity entity, int numberOfParticles) {
        return addLandingEffects(state1, worldserver, pos, entity, numberOfParticles);
    }

    @Override
    public boolean addLandingEffects(BlockState state, ServerWorld worldserver, BlockPos pos,
        LivingEntity entity, int numberOfParticles) {
        BlockEntity tile = worldserver.getBlockEntity(pos);
        if (tile instanceof BlockEntityConjured bec) {
            bec.landParticle(entity, numberOfParticles);
        }
        return true;
    }
}

