package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public class BrainsweepCommand {
    public static void add(LiteralArgumentBuilder<ServerCommandSource> cmd) {
        cmd.then(CommandManager.literal("brainsweep")
            .requires(dp -> dp.hasPermissionLevel(CommandManager.field_31840))
            .then(CommandManager.argument("target", EntityArgumentType.entity()).executes(ctx -> {
                var target = EntityArgumentType.getEntity(ctx, "target");
                if (target instanceof MobEntity mob) {
                    if (IXplatAbstractions.INSTANCE.isBrainswept(mob)) {
                        ctx.getSource().sendError(
                            Text.translatable("command.hexcasting.brainsweep.fail.already",
                                mob.getDisplayName()));
                        return 0;
                    }
                    HexAPI.instance().brainsweep(mob);
                    ctx.getSource().sendFeedback(
                        () -> Text.translatable("command.hexcasting.brainsweep", mob.getDisplayName()), true);
                    return 1;
                } else {
                    ctx.getSource().sendError(
                        Text.translatable("command.hexcasting.brainsweep.fail.badtype",
                            target.getDisplayName()));
                    return 0;
                }
            })));
    }
}
