package at.petrak.hexcasting.fabric.mixin.client;

import at.petrak.hexcasting.client.particles.ConjureParticle;
import com.google.common.collect.ImmutableList;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.particle.ParticleTextureSheet;

@Mixin(ParticleManager.class)
public class FabricParticleEngineMixin {
    @Mutable
    @Final
    @Shadow
    private static List<ParticleTextureSheet> RENDER_ORDER;

    @Inject(at = @At("RETURN"), method = "<clinit>")
    private static void addTypes(CallbackInfo ci) {
        RENDER_ORDER = ImmutableList.<ParticleTextureSheet>builder().addAll(RENDER_ORDER)
            .add(ConjureParticle.CONJURE_RENDER_TYPE, ConjureParticle.CONJURE_RENDER_TYPE)
            .build();
    }
}
