package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.eval.env.PlayerBasedCastEnv;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.entity.attribute.ClampedEntityAttribute;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

/**
 * On forge: these are setup in ForgeHexInit
 * On fabric: it's a mixin
 */
public class HexAttributes {
    public static void register(BiConsumer<EntityAttribute, Identifier> r) {
        for (var e : ATTRIBUTES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<Identifier, EntityAttribute> ATTRIBUTES = new LinkedHashMap<>();

    private static final String MOD_ID = HexAPI.MOD_ID;

    public static final EntityAttribute GRID_ZOOM = make("grid_zoom", new ClampedEntityAttribute(
        MOD_ID + ".attributes.grid_zoom", 1.0, 0.5, 4.0)).setTracked(true);

    /**
     * Whether you have the lens overlay when looking at something. 0 = no, > 0 = yes.
     */
    public static final EntityAttribute SCRY_SIGHT = make("scry_sight", new ClampedEntityAttribute(
        MOD_ID + ".attributes.scry_sight", 0.0, 0.0, 1.0)).setTracked(true);

    //whether the player is allowed to use staffcasting and scrying lenses
    public static final EntityAttribute FEEBLE_MIND = make("feeble_mind", new ClampedEntityAttribute(
            MOD_ID + ".attributes.feeble_mind", 0.0, 0.0, 1.0).setTracked(true));

    //a multiplier to adjust media consumption across the board
    public static final EntityAttribute MEDIA_CONSUMPTION_MODIFIER = make("media_consumption", new ClampedEntityAttribute(
            MOD_ID + ".attributes.media_consumption", 1.0, 0.0, Double.MAX_VALUE).setTracked(true));

    public static final EntityAttribute AMBIT_RADIUS = make("ambit_radius", new ClampedEntityAttribute(
            MOD_ID + ".attributes.ambit_radius", PlayerBasedCastEnv.DEFAULT_AMBIT_RADIUS, 0.0, Double.MAX_VALUE).setTracked(true));

    public static final EntityAttribute SENTINEL_RADIUS = make("sentinel_radius", new ClampedEntityAttribute(
            MOD_ID + ".attributes.sentinel_radius", PlayerBasedCastEnv.DEFAULT_SENTINEL_RADIUS, 0.0, Double.MAX_VALUE).setTracked(true));



    private static <T extends EntityAttribute> T make(String id, T attr) {
        var old = ATTRIBUTES.put(modLoc(id), attr);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return attr;
    }
}
