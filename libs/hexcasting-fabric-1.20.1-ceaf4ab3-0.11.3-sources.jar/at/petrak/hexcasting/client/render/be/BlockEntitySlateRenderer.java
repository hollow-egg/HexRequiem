package at.petrak.hexcasting.client.render.be;

import at.petrak.hexcasting.client.render.WorldlyPatternRenderHelpers;
import at.petrak.hexcasting.common.blocks.circles.BlockEntitySlate;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;

public class BlockEntitySlateRenderer implements BlockEntityRenderer<BlockEntitySlate> {
    public BlockEntitySlateRenderer(BlockEntityRendererFactory.Context ctx) {
        // NO-OP
    }

    @Override
    public void render(BlockEntitySlate tile, float pPartialTick, MatrixStack ps,
        VertexConsumerProvider buffer, int light, int overlay) {
        if (tile.pattern == null)
            return;

        var bs = tile.getCachedState();

        WorldlyPatternRenderHelpers.renderPatternForSlate(tile, tile.pattern, ps, buffer, light, bs);
    }
}