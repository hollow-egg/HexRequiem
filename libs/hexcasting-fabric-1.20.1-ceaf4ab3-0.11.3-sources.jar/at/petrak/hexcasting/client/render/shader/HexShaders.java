package at.petrak.hexcasting.client.render.shader;

import com.mojang.datafixers.util.Pair;
import java.io.IOException;
import java.util.function.Consumer;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.resource.ResourceFactory;

// https://github.com/VazkiiMods/Botania/blob/3a43accc2fbc439c9f2f00a698f8f8ad017503db/Common/src/main/java/vazkii/botania/client/core/helper/CoreShaders.java
public class HexShaders {
    private static ShaderProgram grayscale;

    public static void init(ResourceFactory resourceProvider,
                            Consumer<Pair<ShaderProgram, Consumer<ShaderProgram>>> registrations) throws IOException {
        registrations.accept(Pair.of(
            new ShaderProgram(resourceProvider, "hexcasting__grayscale", VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL),
            inst -> grayscale = inst)
        );
    }

    public static ShaderProgram grayscale() {
        return grayscale;
    }
}
