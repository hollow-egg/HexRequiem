package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.common.lib.HexDamageTypes;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.tag.vanilla.VanillaDamageTypeTagProvider;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.registry.tag.TagKey;

public class HexDamageTypeTagProvider extends VanillaDamageTypeTagProvider {
    public HexDamageTypeTagProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> provider) {
        super(output, provider);
    }

    @Override
    protected void configure(@NotNull RegistryWrapper.WrapperLookup provider) {
        add(HexDamageTypes.OVERCAST,
            DamageTypeTags.BYPASSES_ARMOR,
            DamageTypeTags.BYPASSES_EFFECTS,
            DamageTypeTags.BYPASSES_SHIELD
        );
    }

    @SafeVarargs
    private void add(RegistryKey<DamageType> damageType, TagKey<DamageType>... tags) {
        for (var tag : tags) {
            this.getOrCreateTagBuilder(tag).add(damageType);
        }
    }
}
