package at.petrak.hexcasting.common.blocks.decoration;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FacingBlock;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockAmethystDirectional extends FacingBlock {
    public BlockAmethystDirectional(Settings properties) {
        super(properties);
    }

    public void onProjectileHit(World level, BlockState state, BlockHitResult result, ProjectileEntity projectile) {
        if (!level.isClient) {
            BlockPos pos = result.getBlockPos();
            level.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_HIT, SoundCategory.BLOCKS, 1.0F, 0.5F + level.random.nextFloat() * 1.2F);
            level.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1.0F, 0.5F + level.random.nextFloat() * 1.2F);
        }

    }

    protected void appendProperties(StateManager.Builder<Block, BlockState> $$0) {
        $$0.add(FACING);
    }

    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return this.getDefaultState().with(FACING, ctx.getSide());
    }
}