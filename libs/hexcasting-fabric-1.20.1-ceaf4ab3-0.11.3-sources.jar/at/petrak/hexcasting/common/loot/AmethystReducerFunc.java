package at.petrak.hexcasting.common.loot;

import D;
import at.petrak.hexcasting.common.lib.HexLootFunctions;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.context.LootContext;
import net.minecraft.loot.function.ConditionalLootFunction;
import net.minecraft.loot.function.LootFunctionType;
import net.minecraft.util.JsonHelper;

public class AmethystReducerFunc extends ConditionalLootFunction {
    public final double delta;

    public AmethystReducerFunc(LootCondition[] lootItemConditions, double delta) {
        super(lootItemConditions);
        this.delta = delta;
    }

    public static ItemStack doStatic(ItemStack stack, LootContext ctx, double amount) {
        if (stack.isOf(Items.AMETHYST_SHARD)) {
            stack.setCount((int) (stack.getCount() * (1 + amount)));
        }
        return stack;
    }

    @Override
    protected ItemStack process(ItemStack stack, LootContext ctx) {
        return doStatic(stack, ctx, this.delta);
    }

    @Override
    public LootFunctionType getType() {
        return HexLootFunctions.AMETHYST_SHARD_REDUCER;
    }

    public static class Serializer extends ConditionalLootFunction.Serializer<AmethystReducerFunc> {
        @Override
        public void serialize(JsonObject json, AmethystReducerFunc value, JsonSerializationContext ctx) {
            super.toJson(json, value, ctx);
            json.addProperty("delta", value.delta);
        }

        @Override
        public AmethystReducerFunc fromJson(JsonObject object, JsonDeserializationContext ctx,
            LootCondition[] conditions) {
            var delta = JsonHelper.getDouble(object, "delta");
            return new AmethystReducerFunc(conditions, delta);
        }
    }
}
