package at.petrak.hexcasting.common.blocks.decoration;

import net.minecraft.block.PillarBlock;

public class BlockAxis extends PillarBlock {
    public BlockAxis(Settings p_55926_) {
        super(p_55926_);
    }
}
