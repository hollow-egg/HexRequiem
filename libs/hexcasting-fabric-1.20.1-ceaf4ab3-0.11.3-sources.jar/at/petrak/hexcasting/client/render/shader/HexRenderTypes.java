package at.petrak.hexcasting.client.render.shader;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.mixin.accessor.client.AccessorRenderType;
import java.util.function.Function;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

// https://github.com/VazkiiMods/Botania/blob/3a43accc2fbc439c9f2f00a698f8f8ad017503db/Common/src/main/java/vazkii/botania/client/core/helper/RenderHelper.java
public final class HexRenderTypes extends RenderLayer {

    private HexRenderTypes(String string, VertexFormat vertexFormat, VertexFormat.DrawMode mode, int i, boolean bl,
        boolean bl2, Runnable runnable, Runnable runnable2) {
        super(string, vertexFormat, mode, i, bl, bl2, runnable, runnable2);
        throw new UnsupportedOperationException("Should not be instantiated");
    }

    private static RenderLayer makeLayer(String name, VertexFormat format, VertexFormat.DrawMode mode,
        int bufSize, boolean hasCrumbling, boolean sortOnUpload, RenderLayer.MultiPhaseParameters glState) {
        return AccessorRenderType.hex$create(name, format, mode, bufSize, hasCrumbling, sortOnUpload, glState);
    }

    private static final Function<Identifier, RenderLayer> GRAYSCALE_PROVIDER = Util.memoize(texture -> {
        MultiPhaseParameters glState = RenderLayer.MultiPhaseParameters.builder()
            .program(new ShaderProgram(HexShaders::grayscale))
            .texture(new Texture(texture, false, false))
            .transparency(NO_TRANSPARENCY)
            .cull(DISABLE_CULLING)
            .lightmap(ENABLE_LIGHTMAP)
            .overlay(ENABLE_OVERLAY_COLOR)
            .build(true);

        return makeLayer(HexAPI.MOD_ID + ":grayscale", VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL, VertexFormat.DrawMode.QUADS, 256,
            true, false, glState);
    });

    public static RenderLayer getGrayscaleLayer(Identifier texture) {
        return GRAYSCALE_PROVIDER.apply(texture);
    }

}
