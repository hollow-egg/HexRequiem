package at.petrak.hexcasting.api.addldata;

import F;
import I;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import java.util.UUID;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public interface ADPigment {
    ColorProvider provideColor(UUID owner);

    static int morphBetweenColors(int[] colors, Vec3d gradientDir, float time, Vec3d position) {
        float fIdx = MathHelper.floorMod(time + (float) gradientDir.dotProduct(position), 1f) * colors.length;

        int baseIdx = MathHelper.floor(fIdx);
        float tRaw = fIdx - baseIdx;
        float t = tRaw < 0.5 ? 4 * tRaw * tRaw * tRaw : (float) (1 - Math.pow(-2 * tRaw + 2, 3) / 2);
        int start = colors[baseIdx % colors.length];
        int end = colors[(baseIdx + 1) % colors.length];

        var r1 = ColorHelper.Argb.getRed(start);
        var g1 = ColorHelper.Argb.getGreen(start);
        var b1 = ColorHelper.Argb.getBlue(start);
        var a1 = ColorHelper.Argb.getAlpha(start);
        var r2 = ColorHelper.Argb.getRed(end);
        var g2 = ColorHelper.Argb.getGreen(end);
        var b2 = ColorHelper.Argb.getBlue(end);
        var a2 = ColorHelper.Argb.getAlpha(end);

        var r = MathHelper.lerp(t, r1, r2);
        var g = MathHelper.lerp(t, g1, g2);
        var b = MathHelper.lerp(t, b1, b2);
        var a = MathHelper.lerp(t, a1, a2);

        return ColorHelper.Argb.getArgb((int) a, (int) r, (int) g, (int) b);
    }
}
