package at.petrak.hexcasting.interop.utils;

import at.petrak.hexcasting.api.casting.math.HexCoord;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import java.util.List;
import net.minecraft.util.math.Vec2f;

public record PatternEntry(HexPattern pattern, HexCoord origin, List<Vec2f> zappyPoints) {
    // NO-OP
}
