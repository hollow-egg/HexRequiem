package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import I;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.world.World;

public class EntityTypeIngredient extends BrainsweepeeIngredient {
    public final EntityType<?> entityType;

    public EntityTypeIngredient(EntityType<?> entityType) {
        this.entityType = entityType;
    }

    @Override
    public boolean test(Entity entity, ServerWorld level) {
        // entity types are singletons
        return entity.getType() == this.entityType;
    }

    @Override
    public Text getName() {
        return this.entityType.getName();
    }

    @Override
    public List<Text> getTooltip(boolean advanced) {
        return List.of(
            this.entityType.getName(),
            BrainsweepeeIngredient.getModNameComponent(Registries.ENTITY_TYPE.getId(this.entityType).getNamespace())
        );
    }

    @Override
    public Entity exampleEntity(World level) {
        return this.entityType.create(level);
    }

    @Override
    public JsonObject serialize() {
        var obj = new JsonObject();
        obj.addProperty("type", Type.ENTITY_TYPE.asString());
        obj.addProperty("entityType", Registries.ENTITY_TYPE.getId(this.entityType).toString());

        return obj;
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeVarInt(Registries.ENTITY_TYPE.getRawId(this.entityType));
    }

    public static EntityTypeIngredient deserialize(JsonObject obj) {
        var typeLoc = Identifier.tryParse(JsonHelper.getString(obj, "entityType"));
        if (typeLoc == null || !Registries.ENTITY_TYPE.containsId(typeLoc)) {
            throw new IllegalArgumentException("unknown entity type " + typeLoc);
        }
        return new EntityTypeIngredient(Registries.ENTITY_TYPE.get(typeLoc));
    }

    public static EntityTypeIngredient read(PacketByteBuf buf) {
        var tyId = buf.readVarInt();
        return new EntityTypeIngredient(Registries.ENTITY_TYPE.get(tyId));
    }

    @Override
    public Type ingrType() {
        return Type.ENTITY_TYPE;
    }

    @Override
    public String getSomeKindOfReasonableIDForEmi() {
        var resloc = Registries.ENTITY_TYPE.getId(this.entityType);
        return resloc.getNamespace()
            + "//"
            + resloc.getPath();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityTypeIngredient that = (EntityTypeIngredient) o;
        return Objects.equals(entityType, that.entityType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(entityType);
    }
}
