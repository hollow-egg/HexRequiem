package at.petrak.hexcasting.common.blocks.circles.directrix;

import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.joml.Vector3f;

// Outputs FACING when powered; outputs backwards otherwise
// The FACING face is the happy one, bc i guess it's happy to get the redstone power
public class BlockRedstoneDirectrix extends BlockCircleComponent {
    public static final DirectionProperty FACING = Properties.FACING;
    public static final BooleanProperty REDSTONE_POWERED = Properties.POWERED;

    public BlockRedstoneDirectrix(Settings p_49795_) {
        super(p_49795_);
        this.setDefaultState(this.stateManager.getDefaultState()
            .with(REDSTONE_POWERED, false)
            .with(ENERGIZED, false)
            .with(FACING, Direction.NORTH));
    }

    @Override
    public ControlFlow acceptControlFlow(CastingImage imageIn, CircleCastEnv env, Direction enterDir, BlockPos pos,
        BlockState bs, ServerWorld world) {
        return new ControlFlow.Continue(imageIn, List.of(this.exitPositionFromDirection(pos, getRealFacing(bs))));
    }

    @Override
    public boolean canEnterFromDirection(Direction enterDir, BlockPos pos, BlockState bs, ServerWorld world) {
        // No entering from either of the output faces
        return enterDir != bs.get(FACING).getOpposite() && enterDir != bs.get(FACING);
    }

    @Override
    public EnumSet<Direction> possibleExitDirections(BlockPos pos, BlockState bs, World world) {
        return EnumSet.of(bs.get(FACING), bs.get(FACING).getOpposite());
    }

    @Override
    public Direction normalDir(BlockPos pos, BlockState bs, World world, int recursionLeft) {
        return normalDirOfOther(pos.offset(getRealFacing(bs)), world, recursionLeft);
    }

    @Override
    public float particleHeight(BlockPos pos, BlockState bs, World world) {
        return 0.5f;
    }

    protected Direction getRealFacing(BlockState bs) {
        var facing = bs.get(FACING);
        if (bs.get(REDSTONE_POWERED)) {
            return facing;
        } else {
            return facing.getOpposite();
        }
    }

    @Override
    public void neighborUpdate(BlockState pState, World pLevel, BlockPos pPos, Block pBlock, BlockPos pFromPos,
        boolean pIsMoving) {
        super.neighborUpdate(pState, pLevel, pPos, pBlock, pFromPos, pIsMoving);

        if (!pLevel.isClient) {
            boolean currentlyPowered = pState.get(REDSTONE_POWERED);
            if (currentlyPowered != pLevel.isReceivingRedstonePower(pPos)) {
                pLevel.setBlockState(pPos, pState.with(REDSTONE_POWERED, !currentlyPowered), 2);
            }
        }
    }


    @Override
    public void randomDisplayTick(BlockState bs, World pLevel, BlockPos pos, Random rand) {
        if (bs.get(REDSTONE_POWERED)) {
            for (int i = 0; i < 2; i++) {
                var step = bs.get(FACING).getUnitVector();
                var center = Vec3d.ofCenter(pos).add(step.x() * 0.5, step.y() * 0.5, step.z() * 0.5);
                double x = center.x + (rand.nextDouble() - 0.5) * 0.5D;
                double y = center.y + (rand.nextDouble() - 0.5) * 0.5D;
                double z = center.z + (rand.nextDouble() - 0.5) * 0.5D;
                pLevel.addParticle(DustParticleEffect.DEFAULT, x, y, z,
                    step.x() * 0.1, step.y() * 0.1, step.z() * 0.1);
            }
        }
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(REDSTONE_POWERED, FACING);
    }


    @Override
    public BlockState getPlacementState(ItemPlacementContext pContext) {
        return BlockCircleComponent.placeStateDirAndSneak(this.getDefaultState(), pContext);
    }

    @Override
    public BlockState rotate(BlockState pState, BlockRotation pRot) {
        return pState.with(FACING, pRot.rotate(pState.get(FACING)));
    }

    @Override
    public BlockState mirror(BlockState pState, BlockMirror pMirror) {
        return pState.rotate(pMirror.getRotation(pState.get(FACING)));
    }
}
