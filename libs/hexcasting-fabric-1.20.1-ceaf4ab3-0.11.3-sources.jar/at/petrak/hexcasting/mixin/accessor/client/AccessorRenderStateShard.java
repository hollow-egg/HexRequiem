package at.petrak.hexcasting.mixin.accessor.client;

import net.minecraft.client.render.RenderPhase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(RenderPhase.class)
public interface AccessorRenderStateShard {
    @Accessor("name")
    String hex$name();
}
