package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import at.petrak.hexcasting.api.client.ClientCastingStack;

public record MsgClearSpiralPatternsS2C(UUID playerUUID) implements IMessage {
    public static final Identifier ID = modLoc("clr_spi_pats_sc");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static MsgClearSpiralPatternsS2C deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);

        var player = buf.readUuid();

        return new MsgClearSpiralPatternsS2C(player);
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        buf.writeUuid(playerUUID);
    }

    public static void handle(MsgClearSpiralPatternsS2C self) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var mc = MinecraftClient.getInstance();
                assert mc.world != null;
                var player = mc.world.getPlayerByUuid(self.playerUUID);
                var stack = IClientXplatAbstractions.INSTANCE.getClientCastingStack(player);
                stack.slowClear();
            }
        });
    }
}
