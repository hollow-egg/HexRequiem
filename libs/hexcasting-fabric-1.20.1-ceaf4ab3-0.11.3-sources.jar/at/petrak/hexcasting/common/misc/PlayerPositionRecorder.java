package at.petrak.hexcasting.common.misc;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

public final class PlayerPositionRecorder {
    private static final Map<PlayerEntity, Vec3d> LAST_SECOND_POSITION_MAP = new WeakHashMap<>();
    private static final Map<PlayerEntity, Vec3d> LAST_POSITION_MAP = new WeakHashMap<>();

    public static void updateAllPlayers(ServerWorld world) {
        for (ServerPlayerEntity player : world.getPlayers()) {
            var prev = LAST_POSITION_MAP.get(player);
            if (prev != null)
                LAST_SECOND_POSITION_MAP.put(player, prev);
            LAST_POSITION_MAP.put(player, player.getPos());
        }
    }

    public static Vec3d getMotion(ServerPlayerEntity player) {
        Vec3d vec = LAST_POSITION_MAP.get(player);
        Vec3d prev = LAST_SECOND_POSITION_MAP.get(player);

        if (vec == null)
            return Vec3d.ZERO;

        if (prev == null)
            return player.getPos().subtract(vec);

        return vec.subtract(prev);
    }
}
