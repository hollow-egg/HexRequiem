package at.petrak.hexcasting.common.entities;

import at.petrak.hexcasting.api.HexAPI;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexEntities {
    public static void registerEntities(BiConsumer<EntityType<?>, Identifier> r) {
        for (var e : ENTITIES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<Identifier, EntityType<?>> ENTITIES = new LinkedHashMap<>();

    public static final EntityType<EntityWallScroll> WALL_SCROLL = register("wall_scroll",
        EntityType.Builder.<EntityWallScroll>create(EntityWallScroll::new, SpawnGroup.MISC)
            .setDimensions(0.5f, 0.5f).maxTrackingRange(10).trackingTickInterval(Integer.MAX_VALUE)
            .build(HexAPI.MOD_ID + ":wall_scroll"));

    private static <T extends Entity> EntityType<T> register(String id, EntityType<T> type) {
        var old = ENTITIES.put(modLoc(id), type);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return type;
    }
}
