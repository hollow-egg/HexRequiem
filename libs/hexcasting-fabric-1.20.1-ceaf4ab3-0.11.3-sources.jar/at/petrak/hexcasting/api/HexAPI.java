package at.petrak.hexcasting.api;

import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.common.base.Suppliers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public interface HexAPI {
    String MOD_ID = "hexcasting";
    Logger LOGGER = LogManager.getLogger(MOD_ID);

    Supplier<HexAPI> INSTANCE = Suppliers.memoize(() -> {
        try {
            return (HexAPI) Class.forName("at.petrak.hexcasting.common.impl.HexAPIImpl")
                .getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            LogManager.getLogger().warn("Unable to find HexAPIImpl, using a dummy");
            return new HexAPI() {
            };
        }
    });

    /**
     * Return the localization key for the given action.
     * <p>
     * Note we're allowed to have action <em>resource keys</em> on the client, just no actual actions.
     * <p>
     * Special handlers should be calling {@link SpecialHandler#getName()}
     */
    default String getActionI18nKey(RegistryKey<ActionRegistryEntry> action) {
        return "hexcasting.action.%s".formatted(action.getValue().toString());
    }

    default String getSpecialHandlerI18nKey(RegistryKey<SpecialHandler.Factory<?>> action) {
        return "hexcasting.special.%s".formatted(action.getValue().toString());
    }

    /**
     * Currently introspection/retrospection/consideration are hardcoded, but at least their names won't be
     */
    default String getRawHookI18nKey(Identifier name) {
        return "hexcasting.rawhook.%s".formatted(name);
    }

    default Text getActionI18n(RegistryKey<ActionRegistryEntry> key, boolean isGreat) {
        return Text.translatable(getActionI18nKey(key))
            .formatted(isGreat ? Formatting.GOLD : Formatting.LIGHT_PURPLE);
    }

    default Text getSpecialHandlerI18n(RegistryKey<SpecialHandler.Factory<?>> key) {
        return Text.translatable(getSpecialHandlerI18nKey(key))
            .formatted(Formatting.LIGHT_PURPLE);
    }

    default Text getRawHookI18n(Identifier name) {
        return Text.translatable(getRawHookI18nKey(name)).formatted(Formatting.LIGHT_PURPLE);
    }

    /**
     * Register an entity with the given ID to have its velocity as perceived by OpEntityVelocity be different
     * than it's "normal" velocity
     */
    // Should be OK to use the type directly as the key as they're singleton identity objects
    default <T extends Entity> void registerSpecialVelocityGetter(EntityType<T> key, EntityVelocityGetter<T> getter) {
    }

    /**
     * If the entity has had a special getter registered with {@link HexAPI#registerSpecialVelocityGetter} then
     * return that, otherwise return its normal delta movement
     */
    default Vec3d getEntityVelocitySpecial(Entity entity) {
        return entity.getVelocity();
    }

    @FunctionalInterface
    interface EntityVelocityGetter<T extends Entity> {
        Vec3d getVelocity(T entity);
    }

    /**
     * Register an entity type to have a custom behavior when getting brainswept.
     * <p>
     * This knocks out the normal behavior; if you want that behavior you should call
     */
    default <T extends MobEntity> void registerCustomBrainsweepingBehavior(EntityType<T> key, Consumer<T> hook) {
    }

    /**
     * The default behavior when an entity gets brainswept.
     * <p>
     * Something registered with {@link HexAPI#registerCustomBrainsweepingBehavior} doesn't call this automatically;
     * you can use this to add things on top of the default behavior
     */
    default Consumer<MobEntity> defaultBrainsweepingBehavior() {
        return mob -> {
        };
    }

    /**
     * If something special's been returned with {@link HexAPI#registerCustomBrainsweepingBehavior}, return that,
     * otherwise return the default behavior
     */
    default <T extends MobEntity> Consumer<T> getBrainsweepBehavior(EntityType<T> mobType) {
        return mob -> {
        };
    }

    /**
     * Brainsweep (flay the mind of) the given mob.
     * <p>
     * This ignores the unbrainsweepable tag.
     */
    default void brainsweep(MobEntity mob) {
        var type = (EntityType<? extends MobEntity>) mob.getType();
        var behavior = this.getBrainsweepBehavior(type);
        var erasedBehavior = (Consumer<MobEntity>) behavior;
        erasedBehavior.accept(mob);

        IXplatAbstractions.INSTANCE.setBrainsweepAddlData(mob);
    }

    default boolean isBrainswept(MobEntity mob) {
        return IXplatAbstractions.INSTANCE.isBrainswept(mob);
    }

    //
    @Nullable
    default Sentinel getSentinel(ServerPlayerEntity player) {
        return null;
    }

    @Nullable
    default ADMediaHolder findMediaHolder(ItemStack stack) {
        return null;
    }

    default FrozenPigment getColorizer(PlayerEntity player) {
        return FrozenPigment.DEFAULT.get();
    }

    ArmorMaterial DUMMY_ARMOR_MATERIAL = new ArmorMaterial() {
        @Override
        public int getDurability(ArmorItem.Type type) {
            return 0;
        }

        @Override
        public int getProtection(ArmorItem.Type type) {
            return 0;
        }

        @Override
        public int getEnchantability() {
            return 0;
        }

        @NotNull
        @Override
        public SoundEvent getEquipSound() {
            return SoundEvents.ITEM_ARMOR_EQUIP_LEATHER;
        }

        @NotNull
        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.EMPTY;
        }

        @Override
        public String getName() {
            return "missingno";
        }

        @Override
        public float getToughness() {
            return 0;
        }

        @Override
        public float getKnockbackResistance() {
            return 0;
        }
    };

    default ArmorMaterial robesMaterial() {
        return DUMMY_ARMOR_MATERIAL;
    }

    /**
     * Location in the userdata of the ravenmind
     */
    String RAVENMIND_USERDATA = modLoc("ravenmind").toString();
    /**
     * Location in the userdata of the number of ops executed
     */
    String OP_COUNT_USERDATA = modLoc("op_count").toString();

    String MARKED_MOVED_USERDATA = modLoc("impulsed").toString();

    static HexAPI instance() {
        return INSTANCE.get();
    }

    static Identifier modLoc(String s) {
        return new Identifier(MOD_ID, s);
    }
}
