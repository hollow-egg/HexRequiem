package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.utils.NBTHelper;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// Would love to be able to just write to a piece of string but the api requires it to be the same item
public class ItemThoughtKnot extends Item implements IotaHolderItem {
    public static final Identifier WRITTEN_PRED = modLoc("written");

    public static final String TAG_DATA = "data";

    public ItemThoughtKnot(Settings properties) {
        super(properties);
    }

    @Override
    public @Nullable NbtCompound readIotaTag(ItemStack stack) {
        return NBTHelper.getCompound(stack, TAG_DATA);
    }

    @Override
    public boolean writeable(ItemStack stack) {
        return !NBTHelper.contains(stack, TAG_DATA);
    }

    @Override
    public boolean canWrite(ItemStack stack, @Nullable Iota iota) {
        return iota != null && writeable(stack);
    }

    @Override
    public void writeDatum(ItemStack stack, @Nullable Iota iota) {
        if (iota != null) {
            NBTHelper.putCompound(stack, TAG_DATA, IotaType.serialize(iota));
        }
    }

    @Override
    public void appendTooltip(ItemStack pStack, @Nullable World pLevel,
        List<Text> pTooltipComponents, TooltipContext pIsAdvanced) {
        IotaHolderItem.appendHoverText(this, pStack, pTooltipComponents, pIsAdvanced);
    }
}
