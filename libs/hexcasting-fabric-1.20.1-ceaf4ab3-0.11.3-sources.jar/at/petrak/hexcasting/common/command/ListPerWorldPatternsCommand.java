package at.petrak.hexcasting.common.command;

import I;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexDir;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.items.storage.ItemScroll;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.server.ScrungledPatternsSave;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.datafixers.util.Pair;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ListPerWorldPatternsCommand {
    public static void add(LiteralArgumentBuilder<ServerCommandSource> cmd) {
        cmd.then(CommandManager.literal("perWorldPatterns")
            .requires(dp -> dp.hasPermissionLevel(CommandManager.field_31839))
            .then(CommandManager.literal("list")
                .executes(ctx -> list(ctx.getSource())))
            .then(CommandManager.literal("give")
                .then(CommandManager.argument("patternName", PatternResLocArgument.identifier())
                    .executes(ctx ->
                        giveOne(ctx.getSource(),
                            getDefaultTarget(ctx.getSource()),
                            IdentifierArgumentType.getIdentifier(ctx, "patternName"),
                            PatternResLocArgument.getPattern(ctx, "patternName")))
                    .then(CommandManager.argument("targets", EntityArgumentType.players())
                        .executes(ctx ->
                            giveOne(ctx.getSource(),
                                EntityArgumentType.getPlayers(ctx, "targets"),
                                IdentifierArgumentType.getIdentifier(ctx, "patternName"),
                                PatternResLocArgument.getPattern(ctx, "patternName"))))))
            .then(CommandManager.literal("giveAll")
                .executes(ctx ->
                    giveAll(ctx.getSource(),
                        getDefaultTarget(ctx.getSource())))
                .then(CommandManager.argument("targets", EntityArgumentType.players())
                    .executes(ctx ->
                        giveAll(ctx.getSource(),
                            EntityArgumentType.getPlayers(ctx, "targets")))))
        );
    }

    private static Collection<ServerPlayerEntity> getDefaultTarget(ServerCommandSource source) {
        if (source.getEntity() instanceof ServerPlayerEntity player) {
            return List.of(player);
        }
        return List.of();
    }

    private static int list(ServerCommandSource source) {

        var keys = IXplatAbstractions.INSTANCE.getActionRegistry().getKeys();
        var listing = keys
            .stream()
            .sorted((a, b) -> compareResLoc(a.getValue(), b.getValue()))
            .toList();

        var ow = source.getWorld().getServer().getOverworld();
        source.sendFeedback(() -> Text.translatable("command.hexcasting.pats.listing"), false);
        for (var key : listing) {
            var pat = PatternRegistryManifest.getCanonicalStrokesPerWorld(key, ow);

            source.sendFeedback(() -> Text.literal(key.getValue().toString())
                .append(": ")
                .append(new PatternIota(pat).display()), false);
        }

        return keys.size();
    }

    private static int giveAll(ServerCommandSource source, Collection<ServerPlayerEntity> targets) {
        if (!targets.isEmpty()) {
            var ow = source.getWorld().getServer().getOverworld();
            var save = ScrungledPatternsSave.open(ow);
            Registry<ActionRegistryEntry> regi = IXplatAbstractions.INSTANCE.getActionRegistry();

            int count = 0;
            for (var entry : regi.getEntrySet()) {
                var key = entry.getKey();
                if (HexUtils.isOfTag(regi, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                    var found = save.lookupReverse(key);
                    var signature = found.getFirst();
                    var startDir = found.getSecond().canonicalStartDir();
                    var pat = HexPattern.fromAnglesUnchecked(signature, startDir);

                    var tag = new NbtCompound();
                    tag.putString(ItemScroll.TAG_OP_ID, key.getValue().toString());
                    tag.put(ItemScroll.TAG_PATTERN, pat.serializeToNBT());

                    var stack = new ItemStack(HexItems.SCROLL_LARGE);
                    stack.setNbt(tag);

                    for (var player : targets) {
                        var stackEntity = player.dropItem(stack, false);
                        if (stackEntity != null) {
                            stackEntity.resetPickupDelay();
                            stackEntity.setThrower(player.getUuid());
                        }

                        count++;
                    }
                }
            }

            int finalCount = count;
            source.sendFeedback(() ->
                Text.translatable("command.hexcasting.pats.all",
                    finalCount,
                    targets.size() == 1 ? targets.iterator().next().getDisplayName() : targets.size()),
                true);
            return count;
        } else {
            return 0;
        }
    }

    private static int giveOne(ServerCommandSource source, Collection<ServerPlayerEntity> targets,
        Identifier patternName, HexPattern pat) {
        if (!targets.isEmpty()) {
            var tag = new NbtCompound();
            tag.putString(ItemScroll.TAG_OP_ID, patternName.toString());
            tag.put(ItemScroll.TAG_PATTERN, pat.serializeToNBT());

            var stack = new ItemStack(HexItems.SCROLL_LARGE);
            stack.setNbt(tag);

            source.sendFeedback(() ->
                Text.translatable(
                    "command.hexcasting.pats.specific.success",
                    stack.toHoverableText(),
                    patternName,
                    targets.size() == 1 ? targets.iterator().next().getDisplayName() : targets.size()),
                true);

            for (var player : targets) {
                var stackEntity = player.dropItem(stack, false);
                if (stackEntity != null) {
                    stackEntity.resetPickupDelay();
                    stackEntity.setThrower(player.getUuid());
                }
            }

            return targets.size();
        } else {
            return 0;
        }
    }

    private static int compareResLoc(Identifier a, Identifier b) {
        var ns = a.getNamespace().compareTo(b.getNamespace());
        if (ns != 0) {
            return ns;
        }
        return a.getPath().compareTo(b.getPath());
    }
}
