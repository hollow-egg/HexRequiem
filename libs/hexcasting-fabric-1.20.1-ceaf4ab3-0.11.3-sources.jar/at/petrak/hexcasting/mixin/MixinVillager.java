package at.petrak.hexcasting.mixin;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.entity.passive.VillagerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Prevents the villager from any of its brain goals
@Mixin(VillagerEntity.class)
public class MixinVillager {
    @Inject(method = "canBreed", at = @At("HEAD"), cancellable = true)
    private void preventBreeding(CallbackInfoReturnable<Boolean> cir) {
        var self = (VillagerEntity) (Object) this;
        if (IXplatAbstractions.INSTANCE.isBrainswept(self)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "setUnhappy", at = @At("HEAD"), cancellable = true)
    private void preventUnhappiness(CallbackInfo ci) {
        var self = (VillagerEntity) (Object) this;
        if (IXplatAbstractions.INSTANCE.isBrainswept(self)) {
            ci.cancel();
        }
    }
}
