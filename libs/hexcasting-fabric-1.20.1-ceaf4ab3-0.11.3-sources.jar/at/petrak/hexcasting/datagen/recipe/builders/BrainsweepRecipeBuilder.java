package at.petrak.hexcasting.datagen.recipe.builders;

import at.petrak.hexcasting.common.recipe.HexRecipeStuffRegistry;
import at.petrak.hexcasting.common.recipe.ingredient.StateIngredient;
import at.petrak.hexcasting.common.recipe.ingredient.StateIngredientHelper;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredient;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.AdvancementRewards;
import net.minecraft.advancement.CriterionMerger;
import net.minecraft.advancement.criterion.CriterionConditions;
import net.minecraft.advancement.criterion.RecipeUnlockedCriterion;
import net.minecraft.block.BlockState;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.item.Item;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.util.Identifier;

public class BrainsweepRecipeBuilder implements CraftingRecipeJsonBuilder {
	private final StateIngredient blockIn;
	private final BrainsweepeeIngredient entityIn;
	private final long mediaCost;
	private final BlockState result;

	private final Advancement.Builder advancement;

	public BrainsweepRecipeBuilder(StateIngredient blockIn, BrainsweepeeIngredient entityIn, BlockState result,
		long mediaCost) {
		this.blockIn = blockIn;
		this.entityIn = entityIn;
		this.result = result;
		this.mediaCost = mediaCost;
		this.advancement = Advancement.Builder.create();
	}

	@Override
	public CraftingRecipeJsonBuilder criterion(String pCriterionName, CriterionConditions pCriterionTrigger) {
		this.advancement.criterion(pCriterionName, pCriterionTrigger);
		return this;
	}

	@Override
	public CraftingRecipeJsonBuilder group(@Nullable String pGroupName) {
		return this;
	}

	@Override
	public Item getOutputItem() {
		return this.result.getBlock().asItem();
	}

	@Override
	public void offerTo(Consumer<RecipeJsonProvider> pFinishedRecipeConsumer, Identifier pRecipeId) {
		if (this.advancement.getCriteria().isEmpty()) {
			throw new IllegalStateException("No way of obtaining recipe " + pRecipeId);
		}

		this.advancement.parent(new Identifier("recipes/root"))
			.criterion("has_the_recipe", RecipeUnlockedCriterion.create(pRecipeId))
			.rewards(AdvancementRewards.Builder.recipe(pRecipeId))
			.criteriaMerger(CriterionMerger.OR);
		pFinishedRecipeConsumer.accept(new Result(
			pRecipeId,
			this.blockIn, this.entityIn, this.mediaCost, this.result,
			this.advancement,
			new Identifier(pRecipeId.getNamespace(), "recipes/brainsweep/" + pRecipeId.getPath())));
	}

	public record Result(Identifier id, StateIngredient blockIn, BrainsweepeeIngredient villagerIn,
						 long mediaCost, BlockState result, Advancement.Builder advancement,
						 Identifier advancementId) implements RecipeJsonProvider {
		@Override
		public void serialize(JsonObject json) {
			json.add("blockIn", this.blockIn.serialize());
			json.add("entityIn", this.villagerIn.serialize());
			json.addProperty("cost", this.mediaCost);
			json.add("result", StateIngredientHelper.serializeBlockState(this.result));
		}

		@Override
		public Identifier getRecipeId() {
			return this.id;
		}

		@Override
		public RecipeSerializer<?> getSerializer() {
			return HexRecipeStuffRegistry.BRAINSWEEP;
		}

		@Nullable
		@Override
		public JsonObject toAdvancementJson() {
			return this.advancement.toJson();
		}

		@Nullable
		@Override
		public Identifier getAdvancementId() {
			return this.advancementId;
		}
	}
}
