package at.petrak.hexcasting.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.advancements.FailToCastGreatSpellTrigger;
import at.petrak.hexcasting.api.advancements.MinMaxLongs;
import at.petrak.hexcasting.api.advancements.OvercastTrigger;
import at.petrak.hexcasting.api.advancements.SpendMediaTrigger;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.items.ItemLoreFragment;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.paucal.api.datagen.PaucalAdvancementSubProvider;
import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.AdvancementDisplay;
import net.minecraft.advancement.AdvancementFrame;
import net.minecraft.advancement.criterion.ConsumeItemCriterion;
import net.minecraft.advancement.criterion.ImpossibleCriterion;
import net.minecraft.advancement.criterion.InventoryChangedCriterion;
import net.minecraft.advancements.critereon.*;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.predicate.NumberRange;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.function.Consumer;

public class HexAdvancements extends PaucalAdvancementSubProvider {
    public static final OvercastTrigger.Instance ENLIGHTEN =
        new OvercastTrigger.Instance(LootContextPredicate.EMPTY,
            NumberRange.IntRange.ANY,
            // add a little bit of slop here. use 80% or more health ...
            NumberRange.FloatRange.atLeast(0.8),
            // and be left with under 1 healthpoint (half a heart)
            // TODO this means if 80% of your health is less than half a heart, so if you have 2.5 hearts or
            //  less, you can't become enlightened.
            NumberRange.FloatRange.between(Double.MIN_NORMAL, 1.0));

    public HexAdvancements() {
        super(HexAPI.MOD_ID);
    }

    @Override
    public void accept(RegistryWrapper.WrapperLookup provider, Consumer<Advancement> consumer) {
        var root = Advancement.Builder.create()
            // what an ergonomic design decision
            // i am so happy that data generators are the future
            .display(new AdvancementDisplay(new ItemStack(Items.BUDDING_AMETHYST),
                Text.translatable("advancement.hexcasting:root"),
                Text.translatable("advancement.hexcasting:root.desc"),
                new Identifier("minecraft", "textures/block/calcite.png"),
                AdvancementFrame.TASK, true, true, true))
            // the only thing making this vaguely tolerable is the knowledge the json files are worse somehow
            .criterion("has_charged_amethyst", InventoryChangedCriterion.Conditions.items(
                ItemPredicate.Builder.create().tag(HexTags.Items.GRANTS_ROOT_ADVANCEMENT).build()))
            .build(consumer, prefix("root")); // how the hell does one even read this

        //Creative Debug Unlocker
        Advancement.Builder.create()
            .display(new AdvancementDisplay(new ItemStack(HexItems.CREATIVE_UNLOCKER),
                Text.translatable("advancement.hexcasting:creative_unlocker"),
                Text.translatable("advancement.hexcasting:creative_unlocker.desc"),
                new Identifier("minecraft", "textures/block/calcite.png"),
                AdvancementFrame.TASK, true, false, true))
            .parent(root)
            .criterion("has_creative_unlocker", InventoryChangedCriterion.Conditions.items(
                ItemPredicate.Builder.create().items(HexItems.CREATIVE_UNLOCKER).build()))
            .build(consumer, prefix("creative_unlocker"));

        // weird names so we have alphabetical parity
        Advancement.Builder.create()
            .display(simpleDisplay(Items.GLISTERING_MELON_SLICE, "wasteful_cast", AdvancementFrame.TASK))
            .parent(root)
            .criterion("waste_amt", new SpendMediaTrigger.Instance(LootContextPredicate.EMPTY,
                MinMaxLongs.ANY,
                MinMaxLongs.atLeast(89 * MediaConstants.DUST_UNIT / 10)))
            .build(consumer, prefix("aaa_wasteful_cast"));
        Advancement.Builder.create()
            .display(simpleDisplay(HexItems.CHARGED_AMETHYST, "big_cast", AdvancementFrame.TASK))
            .parent(root)
            .criterion("cast_amt", new SpendMediaTrigger.Instance(LootContextPredicate.EMPTY,
                MinMaxLongs.atLeast(64 * MediaConstants.CRYSTAL_UNIT),
                MinMaxLongs.ANY))
            .build(consumer, prefix("aab_big_cast"));

        var impotence = Advancement.Builder.create()
            .display(simpleDisplay(Items.BLAZE_POWDER, "y_u_no_cast_angy", AdvancementFrame.TASK))
            .parent(root)
            .criterion("did_the_thing",
                new FailToCastGreatSpellTrigger.Instance(LootContextPredicate.EMPTY))
            .build(consumer, prefix("y_u_no_cast_angy"));

        var opened_eyes = Advancement.Builder.create()
            .display(simpleDisplay(Items.ENDER_EYE, "opened_eyes", AdvancementFrame.TASK))
            .parent(impotence)
            .criterion("health_used",
                new OvercastTrigger.Instance(LootContextPredicate.EMPTY,
                    NumberRange.IntRange.ANY,
                    NumberRange.FloatRange.ANY,
                    // you can't just kill yourself
                    NumberRange.FloatRange.atLeast(0.0)))
            .build(consumer, prefix("opened_eyes"));

        Advancement.Builder.create()
            .display(new AdvancementDisplay(new ItemStack(Items.MUSIC_DISC_11),
                Text.translatable("advancement.hexcasting:enlightenment"),
                Text.translatable("advancement.hexcasting:enlightenment.desc"),
                null,
                AdvancementFrame.CHALLENGE, true, true, true))
            .parent(opened_eyes)
            .criterion("health_used", ENLIGHTEN)
            .build(consumer, prefix("enlightenment"));

        var loreRoot = Advancement.Builder.create()
            .display(simpleDisplayWithBackground(HexBlocks.AKASHIC_LIGATURE, "lore", AdvancementFrame.GOAL,
                modLoc("textures/block/slate.png")))
            .criterion("used_item", new ConsumeItemCriterion.Conditions(LootContextPredicate.EMPTY,
                ItemPredicate.Builder.create().items(HexItems.LORE_FRAGMENT).build()))
            .build(consumer, prefix("lore"));

        for (var advId : ItemLoreFragment.NAMES) {
            Advancement.Builder.create()
                .display(new AdvancementDisplay(new ItemStack(HexItems.LORE_FRAGMENT),
                    Text.translatable("advancement." + advId), Text.empty(),
                    null, AdvancementFrame.TASK, true, true, true))
                .parent(loreRoot)
                .criterion(ItemLoreFragment.CRITEREON_KEY, new ImpossibleCriterion.Conditions())
                .build(consumer, advId.toString());
        }

//        super.registerAdvancements(consumer, fileHelper);
    }
}
