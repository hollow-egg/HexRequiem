package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.common.items.storage.ItemScroll;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexCreativeTabs {
    public static void registerCreativeTabs(BiConsumer<ItemGroup, Identifier> r) {
        for (var e : TABS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<Identifier, ItemGroup> TABS = new LinkedHashMap<>();

    public static final ItemGroup HEX = register("hexcasting", ItemGroup.create(ItemGroup.Row.TOP, 7)
            .icon(() -> new ItemStack(HexItems.SPELLBOOK)));

    public static final ItemGroup SCROLLS = register("scrolls", ItemGroup.create(ItemGroup.Row.TOP, 7)
            .icon(() -> ItemScroll.withPerWorldPattern(new ItemStack(HexItems.SCROLL_LARGE),"")));

    private static ItemGroup register(String name, ItemGroup.Builder tabBuilder) {
        var tab = tabBuilder.displayName(Text.translatable("itemGroup.hexcasting." + name)).build();
        var old = TABS.put(modLoc(name), tab);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return tab;
    }
}
