package at.petrak.hexcasting.datagen.recipe.builders;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.advancement.criterion.CriterionConditions;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.util.Identifier;

// Largely adapted from the following classes:
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/content/contraptions/processing/ProcessingOutput.java
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/foundation/data/recipe/ProcessingRecipeGen.java
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/content/contraptions/processing/ProcessingRecipeBuilder.java
// https://github.com/Creators-of-Create/Create/blob/82be76d8934af03b4e52cad6a9f74a4175ba7b05/src/main/java/com/simibubi/create/content/contraptions/processing/ProcessingRecipeSerializer.java
public class CreateCrushingRecipeBuilder implements CraftingRecipeJsonBuilder {
    private String group = "";
    private Ingredient input;
    private final List<ProcessingOutput> results = new ArrayList<>();
    private int processingTime = 100;

    @Override
    public @NotNull CreateCrushingRecipeBuilder criterion(@NotNull String name, @NotNull CriterionConditions trigger) {
        return this;
    }

    @Override
    public @NotNull CreateCrushingRecipeBuilder group(@Nullable String name) {
        group = name;
        return this;
    }

    public CreateCrushingRecipeBuilder duration(int duration) {
        this.processingTime = duration;
        return this;
    }

    public CreateCrushingRecipeBuilder withInput(ItemConvertible item) {
        return withInput(Ingredient.ofItems(item));
    }

    public CreateCrushingRecipeBuilder withInput(ItemStack stack) {
        return withInput(Ingredient.ofStacks(stack));
    }

    public CreateCrushingRecipeBuilder withInput(Ingredient ingredient) {
        this.input = ingredient;
        return this;
    }

    public CreateCrushingRecipeBuilder withOutput(ItemConvertible output) {
        return withOutput(1f, output, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, ItemConvertible output) {
        return withOutput(chance, output, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(ItemConvertible output, int count) {
        return withOutput(1f, output, count);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, ItemConvertible output, int count) {
        return withOutput(new ItemStack(output, count), chance);
    }

    public CreateCrushingRecipeBuilder withOutput(ItemStack output, float chance) {
        this.results.add(new ItemProcessingOutput(output, chance));
        return this;
    }

    public CreateCrushingRecipeBuilder withOutput(String name) {
        return withOutput(1f, name, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(String name, int count) {
        return withOutput(1f, name, count);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, String name) {
        return withOutput(chance, name, 1);
    }

    public CreateCrushingRecipeBuilder withOutput(float chance, String name, int count) {
        this.results.add(new CompatProcessingOutput(name, count, chance));
        return this;
    }

    @Override
    public @NotNull Item getOutputItem() {
        return Items.AIR; // Irrelevant, we implement serialization ourselves
    }

    @Override
    public void offerTo(@NotNull Consumer<RecipeJsonProvider> consumer, @NotNull Identifier resourceLocation) {
        consumer.accept(new CrushingRecipe(resourceLocation));
    }

    public class CrushingRecipe implements RecipeJsonProvider {

        private final Identifier id;

        public CrushingRecipe(Identifier id) {
            this.id = id;
        }

        @Override
        public void serialize(@NotNull JsonObject json) {
            json.addProperty("type", "create:crushing");

            if (!group.isEmpty()) {
                json.addProperty("group", group);
            }

            JsonArray jsonIngredients = new JsonArray();
            JsonArray jsonOutputs = new JsonArray();

            jsonIngredients.add(input.toJson());

            results.forEach(o -> jsonOutputs.add(o.serialize()));

            json.add("ingredients", jsonIngredients);
            json.add("results", jsonOutputs);

            int processingDuration = processingTime;
            if (processingDuration > 0) {
                json.addProperty("processingTime", processingDuration);
            }
        }

        @Override
        public @NotNull Identifier getRecipeId() {
            return id;
        }

        @Override
        public @NotNull RecipeSerializer<?> getSerializer() {
            return RecipeSerializer.SHAPELESS; // Irrelevant, we implement serialization ourselves
        }

        @Override
        public JsonObject toAdvancementJson() {
            return null;
        }

        @Override
        public Identifier getAdvancementId() {
            return null;
        }
    }

}
