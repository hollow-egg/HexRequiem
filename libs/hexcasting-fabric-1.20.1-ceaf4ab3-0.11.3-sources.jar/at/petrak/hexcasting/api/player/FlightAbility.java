package at.petrak.hexcasting.api.player;

import net.minecraft.registry.RegistryKey;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * @param timeLeft sentinel of -1 for infinite
 * @param radius   sentinel of negative for infinite
 */
public record FlightAbility(int timeLeft, RegistryKey<World> dimension, Vec3d origin, double radius) {
}
