package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * An iota with no data associated with it.
 */
public class NullIota extends Iota {
    private static final Object NULL_SUBSTITUTE = new Object();

    public static final Text DISPLAY =
        Text.translatable("hexcasting.tooltip.null_iota").formatted(Formatting.GRAY);

    public NullIota() {
        // We have to pass *something* here, but there's nothing that actually needs to go there,
        // so we just do this i guess
        super(HexIotaTypes.NULL, NULL_SUBSTITUTE);
    }

    @Override
    public boolean isTruthy() {
        return false;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that);
    }

    @Override
    public @NotNull NbtElement serialize() {
        return new NbtCompound();
    }

    public static IotaType<NullIota> TYPE = new IotaType<>() {
        @Nullable
        @Override
        public NullIota deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException {
            return new NullIota();
        }

        @Override
        public Text display(NbtElement tag) {
            return DISPLAY;
        }

        @Override
        public int color() {
            return 0xff_aaaaaa;
        }
    };
}
