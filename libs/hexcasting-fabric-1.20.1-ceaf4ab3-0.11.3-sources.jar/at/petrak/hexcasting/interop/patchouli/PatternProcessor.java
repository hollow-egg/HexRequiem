package at.petrak.hexcasting.interop.patchouli;

import net.minecraft.client.resource.language.I18n;
import net.minecraft.world.World;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;

public class PatternProcessor implements IComponentProcessor {
    private String translationKey;

    @Override
    public void setup(World level, IVariableProvider vars) {
        if (vars.has("header"))
            translationKey = vars.get("header").asString();
        else {
            IVariable key = vars.get("op_id");
            String opName = key.asString();

            String prefix = "hexcasting.action.";
            boolean hasOverride = I18n.hasTranslation(prefix + "book." + opName);
            translationKey = prefix + (hasOverride ? "book." : "") + opName;
        }
    }

    @Override
    public IVariable process(World level, String key) {
        if (key.equals("translation_key")) {
            return IVariable.wrap(translationKey);
        }

        return null;
    }
}
