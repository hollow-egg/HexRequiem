package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.samsthenerd.inline.api.InlineAPI;
import com.samsthenerd.inline.api.data.EntityInlineData;
import com.samsthenerd.inline.api.data.PlayerHeadData;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EntityIota extends Iota {
    public EntityIota(@NotNull Entity e) {
        super(HexIotaTypes.ENTITY, e);
    }

    public Entity getEntity() {
        return (Entity) this.payload;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof EntityIota dent
            && this.getEntity() == dent.getEntity();
    }

    @Override
    public boolean isTruthy() {
        return true;
    }

    @Override
    public @NotNull
    NbtElement serialize() {
        var out = new NbtCompound();
        out.putUuid("uuid", this.getEntity().getUuid());
        out.putString("name", Text.Serializer.toJson(getEntityNameWithInline(true)));
        return out;
    }

    @Override
    public Text display() {
        return getEntityNameWithInline(false).copy().formatted(Formatting.AQUA);
    }

    private Text getEntityNameWithInline(boolean fearSerializer){
        MutableText baseName = this.getEntity().getName().copy();
        Text inlineEnt = null;
        if(this.getEntity() instanceof PlayerEntity player){
            inlineEnt = new PlayerHeadData(player.getGameProfile()).asText(!fearSerializer);
            inlineEnt = inlineEnt.copyContentOnly().fillStyle(InlineAPI.INSTANCE.withSizeModifier(inlineEnt.getStyle(), 1.5));
        } else{
            if(fearSerializer){ // we don't want to have to serialize an entity just to display it
                inlineEnt = EntityInlineData.fromType(this.getEntity().getType()).asText(!fearSerializer);
            } else {
                inlineEnt = EntityInlineData.fromEntity(this.getEntity()).asText(!fearSerializer);
            }
        }
        return baseName.append(Text.literal(": ")).append(inlineEnt);
    }

    public static IotaType<EntityIota> TYPE = new IotaType<>() {
        @Nullable
        @Override
        public EntityIota deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException {
            var ctag = HexUtils.downcast(tag, NbtCompound.TYPE);
            NbtElement uuidTag = ctag.get("uuid");
            if (uuidTag == null) {
                return null;
            }
            var uuid = NbtHelper.toUuid(uuidTag);
            var entity = world.getEntity(uuid);
            if (entity == null) {
                return null;
            }
            return new EntityIota(entity);
        }

        @Override
        public Text display(NbtElement tag) {
            if (!(tag instanceof NbtCompound ctag)) {
                return Text.translatable("hexcasting.spelldata.entity.whoknows");
            }
            if (!ctag.contains("name", NbtElement.STRING_TYPE)) {
                return Text.translatable("hexcasting.spelldata.entity.whoknows");
            }
            var nameJson = ctag.getString("name");
//            return Component.literal(nameJson);
            return Text.Serializer.fromLenientJson(nameJson).formatted(Formatting.AQUA);
        }

        @Override
        public int color() {
            return 0xff_55ffff;
        }
    };
}
