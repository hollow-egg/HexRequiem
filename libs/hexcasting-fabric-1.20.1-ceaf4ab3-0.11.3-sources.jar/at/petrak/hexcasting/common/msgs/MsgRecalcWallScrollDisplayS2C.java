package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.common.entities.EntityWallScroll;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import I;
import Z;

/**
 * Sent S->C to have a wall scroll recalculate its pattern, to get readability offset.
 */
public record MsgRecalcWallScrollDisplayS2C(int entityId, boolean showStrokeOrder) implements IMessage {
    public static final Identifier ID = modLoc("redoscroll");

    public static MsgRecalcWallScrollDisplayS2C deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);
        var id = buf.readVarInt();
        var showStrokeOrder = buf.readBoolean();
        return new MsgRecalcWallScrollDisplayS2C(id, showStrokeOrder);
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        buf.writeVarInt(entityId);
        buf.writeBoolean(showStrokeOrder);
    }

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static void handle(MsgRecalcWallScrollDisplayS2C msg) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var mc = MinecraftClient.getInstance();
                var entity = mc.world.getEntityById(msg.entityId);
                if (entity instanceof EntityWallScroll scroll
                    && scroll.getShowsStrokeOrder() != msg.showStrokeOrder) {
                    scroll.recalculateDisplay();
                }
            }
        });
    }
}
