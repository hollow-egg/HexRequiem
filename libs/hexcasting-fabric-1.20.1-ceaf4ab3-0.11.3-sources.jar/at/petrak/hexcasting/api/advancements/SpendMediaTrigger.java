package at.petrak.hexcasting.api.advancements;

import com.google.gson.JsonObject;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.advancement.criterion.AbstractCriterionConditions;
import net.minecraft.advancements.critereon.*;
import net.minecraft.predicate.entity.AdvancementEntityPredicateDeserializer;
import net.minecraft.predicate.entity.AdvancementEntityPredicateSerializer;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class SpendMediaTrigger extends AbstractCriterion<SpendMediaTrigger.Instance> {
    private static final Identifier ID = new Identifier("hexcasting", "spend_media");

    private static final String TAG_MEDIA_SPENT = "media_spent";
    private static final String TAG_MEDIA_WASTED = "media_wasted";

    @Override
    public Identifier getId() {
        return ID;
    }

    @Override
    protected Instance conditionsFromJson(JsonObject json, LootContextPredicate predicate,
        AdvancementEntityPredicateDeserializer context) {
        return new Instance(predicate,
            MinMaxLongs.fromJson(json.get(TAG_MEDIA_SPENT)),
            MinMaxLongs.fromJson(json.get(TAG_MEDIA_WASTED)));
    }

    public void trigger(ServerPlayerEntity player, long mediaSpent, long mediaWasted) {
        super.trigger(player, inst -> inst.test(mediaSpent, mediaWasted));
    }

    public static class Instance extends AbstractCriterionConditions {
        protected final MinMaxLongs mediaSpent;
        protected final MinMaxLongs mediaWasted;

        public Instance(LootContextPredicate predicate, MinMaxLongs mediaSpent,
            MinMaxLongs mediaWasted) {
            super(SpendMediaTrigger.ID, predicate);
            this.mediaSpent = mediaSpent;
            this.mediaWasted = mediaWasted;
        }

        @Override
        public Identifier getId() {
            return ID;
        }

        @Override
        public JsonObject toJson(AdvancementEntityPredicateSerializer ctx) {
            JsonObject json = super.toJson(ctx);
            if (!this.mediaSpent.isDummy()) {
                json.add(TAG_MEDIA_SPENT, this.mediaSpent.toJson());
            }
            if (!this.mediaWasted.isDummy()) {
                json.add(TAG_MEDIA_WASTED, this.mediaWasted.toJson());
            }
            return json;
        }

        private boolean test(long mediaSpentIn, long mediaWastedIn) {
            return this.mediaSpent.matches(mediaSpentIn) && this.mediaWasted.matches(mediaWastedIn);
        }
    }
}
