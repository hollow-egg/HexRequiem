package at.petrak.hexcasting.common.msgs;

import io.netty.buffer.ByteBuf;
import net.minecraft.block.enums.Instrument;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import D;
import I;

public record MsgBeepS2C(Vec3d target, int note, Instrument instrument) implements IMessage {
    public static final Identifier ID = modLoc("beep");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static MsgBeepS2C deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);
        var x = buf.readDouble();
        var y = buf.readDouble();
        var z = buf.readDouble();
        var note = buf.readInt();
        var instrument = buf.readEnumConstant(Instrument.class);
        return new MsgBeepS2C(new Vec3d(x, y, z), note, instrument);
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        buf.writeDouble(this.target.x);
        buf.writeDouble(this.target.y);
        buf.writeDouble(this.target.z);
        buf.writeInt(this.note);
        buf.writeEnumConstant(instrument);
    }

    public static void handle(MsgBeepS2C msg) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var minecraft = MinecraftClient.getInstance();
                var world = minecraft.world;
                if (world != null) {
                    float pitch = (float) Math.pow(2, (msg.note() - 12) / 12.0);
                    world.playSound(msg.target().x, msg.target().y, msg.target().z,
                        msg.instrument().getSound().value(), SoundCategory.PLAYERS, 3, pitch, false);
                    world.addParticle(ParticleTypes.NOTE, msg.target().x, msg.target().y + 0.2, msg.target().z,
                        msg.note() / 24.0, 0, 0);
                }
            }
        });
    }
}
