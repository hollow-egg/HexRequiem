package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class BrainsweepingEvents {
    public static ActionResult interactWithBrainswept(PlayerEntity player, World world, Hand hand,
        Entity entity, @Nullable EntityHitResult hitResult) {
        if (entity instanceof MobEntity mob && IXplatAbstractions.INSTANCE.isBrainswept(mob)) {
            // As in, this interaction "successfully" consumes the result and doesn't pass it on
            return ActionResult.SUCCESS;
        }

        return ActionResult.PASS;
    }

    public static ActionResult copyBrainsweepPostTransformation(LivingEntity original, LivingEntity outcome) {
        if (original instanceof MobEntity mOriginal && outcome instanceof MobEntity mOutcome
            && IXplatAbstractions.INSTANCE.isBrainswept(mOriginal)) {
            IXplatAbstractions.INSTANCE.setBrainsweepAddlData(mOutcome);
        }
        return ActionResult.PASS;
    }
}
