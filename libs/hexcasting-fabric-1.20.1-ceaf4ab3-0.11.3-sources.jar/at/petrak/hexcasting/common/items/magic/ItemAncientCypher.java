package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.utils.NBTHelper;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtElement;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

public class ItemAncientCypher extends ItemCypher {
    public static final String TAG_PATTERNS = "patterns";
    public static final String TAG_HEX_NAME = "hex_name";

    public ItemAncientCypher(Settings pProperties) {
        super(pProperties);
    }

    @Override
    public void clearHex(ItemStack stack) {
        super.clearHex(stack);
        NBTHelper.remove(stack, TAG_HEX_NAME);
    }

    @Override
    public Text getName(ItemStack pStack) {
        var descID = this.getTranslationKey(pStack);
        var hexName = NBTHelper.getString(pStack, TAG_HEX_NAME);
        if (hexName != null) {
            return Text.translatable(descID + ".preset", Text.translatable(hexName));
        } else {
            return Text.translatable(descID);
        }
    }

    @Override
    public void appendTooltip(ItemStack pStack, @Nullable World pLevel, List<Text> pTooltipComponents,
        TooltipContext pIsAdvanced) {
        // display media fullness as usual
        super.appendTooltip(pStack, pLevel, pTooltipComponents, pIsAdvanced);

        // also show contained spell
        var patternsTag = NBTHelper.getList(pStack, TAG_PATTERNS, NbtElement.COMPOUND_TYPE);
        if (patternsTag != null) {
            var storedHex = Text.translatable("hexcasting.tooltip.stored_hex");
            for (var iotaTag : patternsTag) {
                var iotaTagC = NBTHelper.getAsCompound(iotaTag);
                var iotaComponent = IotaType.getDisplay(iotaTagC).copy();
                storedHex.append(iotaComponent.formatted(Formatting.DARK_PURPLE));
            }
            pTooltipComponents.add(storedHex);
        }
    }
}
