package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.common.items.storage.ItemAbacus;
import at.petrak.hexcasting.common.items.storage.ItemSpellbook;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import io.netty.buffer.ByteBuf;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import D;
import I;
import Z;

/**
 * Sent client->server when the client shift+scrolls with a shift-scrollable item
 * or scrolls in the spellcasting UI.
 */
public record MsgShiftScrollC2S(double mainHandDelta, double offHandDelta, boolean isCtrl, boolean invertSpellbook,
                                boolean invertAbacus) implements IMessage {
    public static final Identifier ID = modLoc("scroll");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static MsgShiftScrollC2S deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);
        var mainHandDelta = buf.readDouble();
        var offHandDelta = buf.readDouble();
        var isCtrl = buf.readBoolean();
        var invertSpellbook = buf.readBoolean();
        var invertAbacus = buf.readBoolean();
        return new MsgShiftScrollC2S(mainHandDelta, offHandDelta, isCtrl, invertSpellbook, invertAbacus);
    }

    public void serialize(PacketByteBuf buf) {
        buf.writeDouble(this.mainHandDelta);
        buf.writeDouble(this.offHandDelta);
        buf.writeBoolean(this.isCtrl);
        buf.writeBoolean(this.invertSpellbook);
        buf.writeBoolean(this.invertAbacus);
    }

    public void handle(MinecraftServer server, ServerPlayerEntity sender) {
        server.execute(() -> {
            handleForHand(sender, Hand.MAIN_HAND, mainHandDelta);
            handleForHand(sender, Hand.OFF_HAND, offHandDelta);
        });
    }

    private void handleForHand(ServerPlayerEntity sender, Hand hand, double delta) {
        if (delta != 0) {
            var stack = sender.getStackInHand(hand);

            if (stack.getItem() == HexItems.SPELLBOOK) {
                spellbook(sender, hand, stack, delta);
            } else if (stack.getItem() == HexItems.ABACUS) {
                abacus(sender, hand, stack, delta);
            }
        }
    }

    private void spellbook(ServerPlayerEntity sender, Hand hand, ItemStack stack, double delta) {
        if (invertSpellbook) {
            delta = -delta;
        }

        var newIdx = ItemSpellbook.rotatePageIdx(stack, delta < 0.0);

        var len = ItemSpellbook.highestPage(stack);

        var sealed = ItemSpellbook.isSealed(stack);

        MutableText component;
        if (hand == Hand.OFF_HAND && stack.hasCustomName()) {
            if (sealed) {
                component = Text.translatable("hexcasting.tooltip.spellbook.page_with_name.sealed",
                    Text.literal(String.valueOf(newIdx)).formatted(Formatting.WHITE),
                    Text.literal(String.valueOf(len)).formatted(Formatting.WHITE),
                    Text.literal("").formatted(stack.getRarity().formatting, Formatting.ITALIC)
                        .append(stack.getName()),
                    Text.translatable("hexcasting.tooltip.spellbook.sealed").formatted(Formatting.GOLD));
            } else {
                component = Text.translatable("hexcasting.tooltip.spellbook.page_with_name",
                    Text.literal(String.valueOf(newIdx)).formatted(Formatting.WHITE),
                    Text.literal(String.valueOf(len)).formatted(Formatting.WHITE),
                    Text.literal("").formatted(stack.getRarity().formatting, Formatting.ITALIC)
                        .append(stack.getName()));
            }

        } else {
            if (sealed) {
                component = Text.translatable("hexcasting.tooltip.spellbook.page.sealed",
                    Text.literal(String.valueOf(newIdx)).formatted(Formatting.WHITE),
                    Text.literal(String.valueOf(len)).formatted(Formatting.WHITE),
                    Text.translatable("hexcasting.tooltip.spellbook.sealed").formatted(Formatting.GOLD));
            } else {
                component = Text.translatable("hexcasting.tooltip.spellbook.page",
                    Text.literal(String.valueOf(newIdx)).formatted(Formatting.WHITE),
                    Text.literal(String.valueOf(len)).formatted(Formatting.WHITE));
            }
        }

        sender.sendMessage(component.formatted(Formatting.GRAY), true);
    }

    private void abacus(ServerPlayerEntity sender, Hand hand, ItemStack stack, double delta) {
        if (invertAbacus) {
            delta = -delta;
        }

        var increase = delta < 0;
        double num = NBTHelper.getDouble(stack, ItemAbacus.TAG_VALUE);

        double shiftDelta;
        float pitch;
        if (hand == Hand.MAIN_HAND) {
            shiftDelta = this.isCtrl ? 10 : 1;
            pitch = this.isCtrl ? 0.7f : 0.9f;
        } else {
            shiftDelta = this.isCtrl ? 0.01 : 0.1;
            pitch = this.isCtrl ? 1.3f : 1.0f;
        }

        int scale = Math.max((int) Math.floor(Math.abs(delta)), 1);

        num += scale * shiftDelta * (increase ? 1 : -1);
        NBTHelper.putDouble(stack, ItemAbacus.TAG_VALUE, num);

        pitch *= (increase ? 1.05f : 0.95f);
        pitch += (Math.random() - 0.5) * 0.1;
        sender.getWorld().playSound(null, sender.getX(), sender.getY(), sender.getZ(),
            HexSounds.ABACUS, SoundCategory.PLAYERS, 0.5f, pitch);

        var datumTag = HexItems.ABACUS.readIotaTag(stack);
        if (datumTag != null) {
            var popup = IotaType.getDisplay(datumTag);
            sender.sendMessage(
                Text.translatable("hexcasting.tooltip.abacus", popup).formatted(Formatting.GREEN), true);
        }
    }
}
