package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.datafixers.util.Pair;
import javax.annotation.Nullable;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import java.util.List;
import java.util.Objects;

// Take notes from ForgeRegistryEntry
public abstract class IotaType<T extends Iota> {

    /**
     * Spell datums are stored as such: {@code { "type": "modid:type", "datum": a_tag }}.
     * <p>
     * The {@code type} key is given when registering the spell datum type; this method
     * deserializes the tag associated with {@code "datum"}.
     * <p>
     * Returning {@code null} makes the resulting datum be {@link NullIota}.
     * Throwing an exception raises a mishap.
     */
    @Nullable
    public abstract T deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException;

    /**
     * Get a display of this datum from the {@code data} tag, <i>without</i> the world.
     * This is for use on the client.
     */
    public abstract Text display(NbtElement tag);

    /**
     * Get the color associated with this datum type.
     */
    public abstract int color();

    /**
     * Get a display component that's the name of this iota type.
     */
    public Text typeName() {
        var key = HexIotaTypes.REGISTRY.getId(this);
        return Text.translatable("hexcasting.iota." + key)
            .styled(style -> style.withColor(TextColor.fromRgb(color())));
    }

    public static NbtCompound serialize(Iota iota) {
        var type = iota.getType();
        var typeId = HexIotaTypes.REGISTRY.getId(type);
        if (typeId == null) {
            throw new IllegalStateException(
                "Tried to serialize an unregistered iota type. Iota: " + iota
                    + " ; Type" + type.getClass().getTypeName());
        }

        // We check if it's too big on serialization; if it is we just return a garbage.
        if (isTooLargeToSerialize(List.of(iota), 0)) {
            // Garbage will never be too large so we just recurse
            return serialize(new GarbageIota());
        }
        var dataTag = iota.serialize();
        var out = new NbtCompound();
        out.putString(HexIotaTypes.KEY_TYPE, typeId.toString());
        out.put(HexIotaTypes.KEY_DATA, dataTag);
        return out;
    }

    public static boolean isTooLargeToSerialize(Iterable<Iota> examinee) {
        return isTooLargeToSerialize(examinee, 1);
    }

    private static boolean isTooLargeToSerialize(Iterable<Iota> examinee, int startingCount) {
        int totalSize = startingCount;
        for (Iota iota : examinee) {
            if (iota.depth() >= HexIotaTypes.MAX_SERIALIZATION_DEPTH)
                return true;
            totalSize += iota.size();
        }
        return totalSize >= HexIotaTypes.MAX_SERIALIZATION_TOTAL;
    }

    /**
     * This method attempts to find the type from the {@code type} key.
     * See {@link IotaType#serialize(Iota)} for the storage format.
     *
     * @return {@code null} if it cannot get the type.
     */
    @org.jetbrains.annotations.Nullable
    public static IotaType<?> getTypeFromTag(NbtCompound tag) {
        if (!tag.contains(HexIotaTypes.KEY_TYPE, NbtElement.STRING_TYPE)) {
            return null;
        }
        var typeKey = tag.getString(HexIotaTypes.KEY_TYPE);
        if (!Identifier.isValid(typeKey)) {
            return null;
        }
        var typeLoc = new Identifier(typeKey);
        return HexIotaTypes.REGISTRY.get(typeLoc);
    }

    /**
     * Attempt to deserialize an iota from a tag.
     * <br>
     * Iotas are saved as such:
     * <code>
     * {
     * "type": "hexcasting:atype",
     * "data": {...}
     * }
     * </code>
     */
    public static Iota deserialize(NbtCompound tag, ServerWorld world) {
        var type = getTypeFromTag(tag);
        if (type == null) {
            return new GarbageIota();
        }
        var data = tag.get(HexIotaTypes.KEY_DATA);
        if (data == null) {
            return new GarbageIota();
        }
        Iota deserialized;
        try {
            deserialized = Objects.requireNonNullElse(type.deserialize(data, world), new NullIota());
        } catch (IllegalArgumentException exn) {
            HexAPI.LOGGER.warn("Caught an exception deserializing an iota", exn);
            deserialized = new GarbageIota();
        }
        return deserialized;
    }

    private static Text brokenIota() {
        return Text.translatable("hexcasting.spelldata.unknown")
            .formatted(Formatting.GRAY, Formatting.ITALIC);
    }

    public static Text getDisplay(NbtCompound tag) {
        var type = getTypeFromTag(tag);
        if (type == null) {
            return brokenIota();
        }
        var data = tag.get(HexIotaTypes.KEY_DATA);
        if (data == null) {
            return brokenIota();
        }
        return type.display(data);
    }

    public static OrderedText getDisplayWithMaxWidth(NbtCompound tag, int maxWidth, TextRenderer font) {
        var type = getTypeFromTag(tag);
        if (type == null) {
            return brokenIota().asOrderedText();
        }
        var data = tag.get(HexIotaTypes.KEY_DATA);
        if (data == null) {
            return brokenIota().asOrderedText();
        }
        var display = type.display(data);
        var splitted = font.wrapLines(display, maxWidth - font.getWidth("..."));
        if (splitted.isEmpty())
            return OrderedText.EMPTY;
        else if (splitted.size() == 1)
            return splitted.get(0);
        else {
            var first = splitted.get(0);
            return OrderedText.innerConcat(first,
                Text.literal("...").formatted(Formatting.GRAY).asOrderedText());
        }
    }

    public static int getColor(NbtCompound tag) {
        var type = getTypeFromTag(tag);
        if (type == null) {
            return HexUtils.ERROR_COLOR;
        }
        return type.color();
    }
}
