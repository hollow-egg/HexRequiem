package at.petrak.hexcasting.common.entities;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.common.items.storage.ItemScroll;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.common.msgs.MsgNewWallScrollS2C;
import at.petrak.hexcasting.common.msgs.MsgRecalcWallScrollDisplayS2C;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class EntityWallScroll extends AbstractDecorationEntity {
    private static final TrackedData<Boolean> SHOWS_STROKE_ORDER = DataTracker.registerData(
        EntityWallScroll.class,
        TrackedDataHandlerRegistry.BOOLEAN);

    public ItemStack scroll;
    @Nullable
    public HexPattern pattern;
    public boolean isAncient;
    public int blockSize;

    public EntityWallScroll(EntityType<? extends EntityWallScroll> type, World world) {
        super(type, world);
    }

    public EntityWallScroll(World world, BlockPos pos, Direction dir, ItemStack scroll, boolean showStrokeOrder,
        int blockSize) {
        super(HexEntities.WALL_SCROLL, world, pos);
        this.setFacing(dir);
        this.blockSize = blockSize;

        this.dataTracker.set(SHOWS_STROKE_ORDER, showStrokeOrder);
        this.scroll = scroll;
        this.recalculateDisplay();
        this.updateAttachmentPosition();
    }

    public void recalculateDisplay() {
        NbtCompound patternTag = NBTHelper.getCompound(scroll, ItemScroll.TAG_PATTERN);
        if (patternTag != null) {
            this.pattern = HexPattern.fromNBT(patternTag);
            this.isAncient = NBTHelper.hasString(scroll, ItemScroll.TAG_OP_ID);
        } else {
            this.pattern = null;
            this.isAncient = false;
        }
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(SHOWS_STROKE_ORDER, false);
    }

    public boolean getShowsStrokeOrder() {
        return this.dataTracker.get(SHOWS_STROKE_ORDER);
    }

    public void setShowsStrokeOrder(boolean b) {
        this.dataTracker.set(SHOWS_STROKE_ORDER, b);
    }

    @Override
    public int getWidthPixels() {
        return 16 * blockSize;
    }

    @Override
    public int getHeightPixels() {
        return 16 * blockSize;
    }

    @Override
    public void onBreak(@Nullable Entity pBrokenEntity) {
        if (this.getWorld().getGameRules().getBoolean(GameRules.DO_ENTITY_DROPS)) {
            this.playSound(SoundEvents.ENTITY_PAINTING_BREAK, 1.0F, 1.0F);
            if (pBrokenEntity instanceof PlayerEntity player) {
                if (player.getAbilities().creativeMode) {
                    return;
                }
            }

            this.dropStack(this.scroll);
        }
    }

    @Override
    public ActionResult interactAt(PlayerEntity pPlayer, Vec3d pVec, Hand pHand) {
        var handStack = pPlayer.getStackInHand(pHand);
        if (handStack.isOf(HexItems.AMETHYST_DUST) && !this.getShowsStrokeOrder()) {
            if (!pPlayer.getAbilities().creativeMode) {
                handStack.decrement(1);
            }
            this.setShowsStrokeOrder(true);

            pPlayer.getWorld().playSoundFromEntity(pPlayer, this, HexSounds.SCROLL_DUST, SoundCategory.PLAYERS, 1f, 1f);

            if (pPlayer.getWorld() instanceof ServerWorld slevel) {
                IXplatAbstractions.INSTANCE.sendPacketNear(this.getPos(), 32.0, slevel,
                    new MsgRecalcWallScrollDisplayS2C(this.getId(), true));
            } else {
                // Beat the packet roundtrip to the punch to get a quicker visual
                this.recalculateDisplay();
            }
            return ActionResult.SUCCESS;
        }
        return super.interactAt(pPlayer, pVec, pHand);
    }

    @Override
    public void onPlace() {
        this.playSound(SoundEvents.ENTITY_PAINTING_PLACE, 1.0F, 1.0F);
    }

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() {
        return IXplatAbstractions.INSTANCE.toVanillaClientboundPacket(
            new MsgNewWallScrollS2C(new EntitySpawnS2CPacket(this),
                attachmentPos, facing, scroll, getShowsStrokeOrder(), blockSize));
    }

    public void readSpawnData(BlockPos pos, Direction dir, ItemStack scrollItem,
        boolean showsStrokeOrder, int blockSize) {
        this.attachmentPos = pos;
        this.scroll = scrollItem;
        this.blockSize = blockSize;

        this.setFacing(dir);
        this.setShowsStrokeOrder(showsStrokeOrder);

        this.recalculateDisplay();
        this.updateAttachmentPosition();
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound tag) {
        tag.putByte("direction", (byte) this.facing.ordinal());
        tag.put("scroll", HexUtils.serializeToNBT(this.scroll));
        tag.putBoolean("showsStrokeOrder", this.getShowsStrokeOrder());
        tag.putInt("blockSize", this.blockSize);
        super.writeCustomDataToNbt(tag);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound tag) {
        this.facing = Direction.values()[tag.getByte("direction")];
        this.scroll = ItemStack.fromNbt(tag.getCompound("scroll"));
        this.blockSize = tag.getInt("blockSize");

        this.setFacing(this.facing);
        this.setShowsStrokeOrder(tag.getBoolean("showsStrokeOrder"));

        this.recalculateDisplay();
        this.updateAttachmentPosition();

        super.readCustomDataFromNbt(tag);
    }

    @Override
    public void refreshPositionAndAngles(double pX, double pY, double pZ, float pYaw, float pPitch) {
        this.setPosition(pX, pY, pZ);
    }

    @Override
    public void updateTrackedPositionAndAngles(double pX, double pY, double pZ, float pYaw, float pPitch, int pPosRotationIncrements,
        boolean pTeleport) {
        BlockPos blockpos = this.attachmentPos.add((int) (pX - this.getX()), (int) (pY - this.getY()), (int) (pZ - this.getZ()));
        this.setPosition(blockpos.getX(), blockpos.getY(), blockpos.getZ());
    }

    @Nullable
    @Override
    public ItemStack getPickBlockStack() {
        return this.scroll.copy();
    }
}
