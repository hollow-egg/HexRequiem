package at.petrak.hexcasting.mixin;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.village.TradeOfferList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Prevents the villager from having any offers if it's brainswept
@Mixin(MerchantEntity.class)
public class MixinAbstractVillager {
    @Inject(method = "getOffers", at = @At("HEAD"), cancellable = true)
    private void nixOffers(CallbackInfoReturnable<TradeOfferList> cir) {
        var self = (MerchantEntity) (Object) this;
        if (IXplatAbstractions.INSTANCE.isBrainswept(self)) {
            cir.setReturnValue(new TradeOfferList());
        }
    }
}
