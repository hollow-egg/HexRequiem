package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.common.lib.HexAttributes;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class FabricPlayerMixin extends LivingEntity {
    protected FabricPlayerMixin(EntityType<? extends LivingEntity> entityType, World level) {
        super(entityType, level);
    }

    @Inject(at = @At("RETURN"), method = "createAttributes")
    private static void hex$addAttributes(CallbackInfoReturnable<DefaultAttributeContainer.Builder> cir) {
        var out = cir.getReturnValue();
        out.method_26867(HexAttributes.GRID_ZOOM);
        out.method_26867(HexAttributes.SCRY_SIGHT);
        out.method_26867(HexAttributes.FEEBLE_MIND);
        out.method_26867(HexAttributes.MEDIA_CONSUMPTION_MODIFIER);
        out.method_26867(HexAttributes.AMBIT_RADIUS);
        out.method_26867(HexAttributes.SENTINEL_RADIUS);
    }
}
