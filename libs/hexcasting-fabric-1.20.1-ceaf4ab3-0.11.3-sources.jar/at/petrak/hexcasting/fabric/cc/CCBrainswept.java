package at.petrak.hexcasting.fabric.cc;

import dev.onyxstudios.cca.api.v3.component.Component;
import dev.onyxstudios.cca.api.v3.component.sync.AutoSyncedComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;

public class CCBrainswept implements Component, AutoSyncedComponent {
    public static final String TAG_BRAINSWEPT = "brainswept";

    private final LivingEntity owner;

    public CCBrainswept(LivingEntity owner) {
        this.owner = owner;
    }

    private boolean brainswept = false;

    public boolean isBrainswept() {
        return this.brainswept;
    }

    public void setBrainswept(boolean brainswept) {
        this.brainswept = brainswept;
        HexCardinalComponents.BRAINSWEPT.sync(this.owner);
    }

    @Override
    public void applySyncPacket(PacketByteBuf buf) {
        AutoSyncedComponent.super.applySyncPacket(buf);
        if (owner instanceof MobEntity mob && brainswept)
            mob.clearGoalsAndTasks();
    }

    @Override
    public void readFromNbt(NbtCompound tag) {
        this.brainswept = tag.getBoolean(TAG_BRAINSWEPT);
    }

    @Override
    public void writeToNbt(NbtCompound tag) {
        tag.putBoolean(TAG_BRAINSWEPT, this.brainswept);
    }
}
