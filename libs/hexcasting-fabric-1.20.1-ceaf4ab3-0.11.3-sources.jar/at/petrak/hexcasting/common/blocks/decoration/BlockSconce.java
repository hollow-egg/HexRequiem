package at.petrak.hexcasting.common.blocks.decoration;

import D;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import net.minecraft.block.AmethystBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.Waterloggable;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.level.block.state.properties.*;

public class BlockSconce extends AmethystBlock implements Waterloggable {
    public static final DirectionProperty FACING = Properties.FACING;
    public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
    protected static VoxelShape AABB_UP = Block.createCuboidShape(4, 0, 4, 12, 1, 12);
    protected static VoxelShape AABB_DOWN = Block.createCuboidShape(4, 15, 4, 12, 16, 12);
    protected static VoxelShape AABB_NORTH = Block.createCuboidShape(4, 4, 15, 12, 12, 16);
    protected static VoxelShape AABB_SOUTH = Block.createCuboidShape(4, 4, 0, 12, 12, 1);
    protected static VoxelShape AABB_WEST = Block.createCuboidShape(15, 4, 4, 16, 12, 12);
    protected static VoxelShape AABB_EAST = Block.createCuboidShape(0, 4, 4, 1, 12, 12);

    public BlockSconce(Settings p_49795_) {
        super(p_49795_);
        this.setDefaultState(this.stateManager.getDefaultState()
            .with(WATERLOGGED, false).with(FACING, Direction.UP));
    }

    @Override
    public FluidState getFluidState(BlockState state) {
        return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState pState, BlockView pLevel, BlockPos pPos, ShapeContext pContext) {
        return switch (pState.get(FACING)) {
            case UP -> AABB_UP;
            case DOWN -> AABB_DOWN;
            case NORTH -> AABB_NORTH;
            case EAST -> AABB_EAST;
            case SOUTH -> AABB_SOUTH;
            case WEST -> AABB_WEST;
        };
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(FACING, WATERLOGGED);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext pContext) {
        FluidState fluidState = pContext.getWorld().getFluidState(pContext.getBlockPos());
        BlockState blockstate;
        blockstate = this.getDefaultState().with(FACING, pContext.getSide());
        blockstate = blockstate.with(WATERLOGGED,
                fluidState.isIn(FluidTags.WATER) && fluidState.getLevel() == 8);
        return blockstate;
    }
    
    @Override
    public BlockState getStateForNeighborUpdate(BlockState pState, Direction pFacing, BlockState pFacingState, WorldAccess pLevel,
        BlockPos pCurrentPos, BlockPos pFacingPos) {
        if (pState.get(WATERLOGGED)) {
            pLevel.scheduleFluidTick(pCurrentPos, Fluids.WATER, Fluids.WATER.getTickRate(pLevel));
        }

        return super.getStateForNeighborUpdate(pState, pFacing, pFacingState, pLevel, pCurrentPos, pFacingPos);
    }

    @Override
    public void randomDisplayTick(BlockState pState, World pLevel, BlockPos pPos, Random rand) {
        if (rand.nextFloat() < 0.8f) {
            var cx = pPos.getX() + 0.5;
            var cy = pPos.getY() + 0.5;
            var cz = pPos.getZ() + 0.5;
            //values for particle direction randomization
            //x 
            var dX = switch(pState.get(FACING)){
                    case EAST -> rand.nextTriangular(0.01f, 0.05f);
                    case WEST -> rand.nextTriangular(-0.01f, -0.05f);
                    default -> rand.nextTriangular(-0.01f, 0.01f);
            };
            //y
            var dY = switch(pState.get(FACING)){
                    case UP -> rand.nextTriangular(0.01f, 0.05f);
                    case DOWN -> rand.nextTriangular(-0.01f, -0.05f);
                    default -> rand.nextTriangular(-0.01f, 0.01f);
            };
            //z
            var dZ = switch(pState.get(FACING)){
                    case SOUTH -> rand.nextTriangular(0.01f, 0.05f);
                    case NORTH -> rand.nextTriangular(-0.01f, -0.05f);
                    default -> rand.nextTriangular(-0.01f, 0.01f);
            };
            int[] colors = {0xff_6f4fab, 0xff_b38ef3, 0xff_cfa0f3, 0xff_cfa0f3, 0xff_fffdd5};
            pLevel.addParticle(new ConjureParticleOptions(colors[rand.nextInt(colors.length)]), cx, cy, cz,
                dX, dY, dZ);
                
            if (rand.nextFloat() < 0.08f) {
                pLevel.playSound(cx, cy, cz,
                    SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1.0F,
                    0.5F + rand.nextFloat() * 1.2F, false);
            }
        }
    }
}
