package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.recipe.BrainsweepRecipe;
import at.petrak.hexcasting.common.recipe.HexRecipeStuffRegistry;
import org.jetbrains.annotations.Nullable;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class BrainsweepProcessor implements IComponentProcessor {
	private BrainsweepRecipe recipe;
	@Nullable
	private String exampleEntityString;

	@Override
	public void setup(World level, IVariableProvider vars) {
		var id = new Identifier(vars.get("recipe").asString());

		var recman = level.getRecipeManager();
		var brainsweepings = recman.listAllOfType(HexRecipeStuffRegistry.BRAINSWEEP_TYPE);
		for (var poisonApples : brainsweepings) {
			if (poisonApples.getId().equals(id)) {
				this.recipe = poisonApples;
				break;
			}
		}
	}

	@Override
	public IVariable process(World level, String key) {
		if (this.recipe == null) {
			return null;
		}

		switch (key) {
			case "header" -> {
				return IVariable.from(this.recipe.result().getBlock().getName());
			}
			case "input" -> {
				var inputStacks = this.recipe.blockIn().getDisplayedStacks();
				return IVariable.from(inputStacks.toArray(new ItemStack[0]));
			}
			case "result" -> {
				return IVariable.from(new ItemStack(this.recipe.result().getBlock()));
			}

			case "entity" -> {
				if (this.exampleEntityString == null) {
					var entity = this.recipe.entityIn().exampleEntity(MinecraftClient.getInstance().world);
					if (entity == null) {
						// oh dear
						return null;
					}
					var bob = new StringBuilder();
					bob.append(Registries.ENTITY_TYPE.getId(entity.getType()));

					var tag = new NbtCompound();
					entity.saveNbt(tag);
					bob.append(tag.toString());
					this.exampleEntityString = bob.toString();
				}

				return IVariable.wrap(this.exampleEntityString);
			}
			case "entityTooltip" -> {
				MinecraftClient mc = MinecraftClient.getInstance();
				return IVariable.wrapList(this.recipe.entityIn()
					.getTooltip(mc.options.advancedItemTooltips)
					.stream()
					.map(IVariable::from)
					.toList());
			}
			case "mediaCost" -> {
				record ItemCost(Item item, int cost) {
					public boolean dividesEvenly (int dividend) {
                        return dividend % cost == 0;
                    }
				}
				ItemCost[] costs  = {
						new ItemCost(HexItems.AMETHYST_DUST, (int)MediaConstants.DUST_UNIT),
						new ItemCost(Items.AMETHYST_SHARD, (int)MediaConstants.SHARD_UNIT),
						new ItemCost(HexItems.CHARGED_AMETHYST, (int)MediaConstants.CRYSTAL_UNIT),
				};

				// get evenly divisible ItemStacks
				List<IVariable> validItemStacks = Arrays.stream(costs)
						.filter(itemCost -> itemCost.dividesEvenly((int)this.recipe.mediaCost()))
						.map(validItemCost -> new ItemStack(validItemCost.item, (int) this.recipe.mediaCost() / validItemCost.cost))
						.map(IVariable::from)
						.toList();

				if (!validItemStacks.isEmpty()) {
					return IVariable.wrapList(validItemStacks);
				}
				// fallback: display in terms of dust
				return IVariable.from(new ItemStack(HexItems.AMETHYST_DUST, (int) (this.recipe.mediaCost() / MediaConstants.DUST_UNIT)));
			}
			default -> {
				return null;
			}
		}
	}
}
