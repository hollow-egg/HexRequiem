package at.petrak.hexcasting.common.blocks.behavior;

import at.petrak.hexcasting.common.lib.HexBlocks;
import net.minecraft.block.ComposterBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;

public final class HexComposting {

    public static void setup() {
        compost(HexBlocks.AMETHYST_EDIFIED_LEAVES, 0.3F);
        compost(HexBlocks.AVENTURINE_EDIFIED_LEAVES, 0.3F);
        compost(HexBlocks.CITRINE_EDIFIED_LEAVES, 0.3F);
    }

    private static void compost(ItemConvertible itemLike, float chance) {
        Item item = itemLike.asItem();

        if (item != Items.AIR) {
            ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(item, chance);
        }
    }
}
