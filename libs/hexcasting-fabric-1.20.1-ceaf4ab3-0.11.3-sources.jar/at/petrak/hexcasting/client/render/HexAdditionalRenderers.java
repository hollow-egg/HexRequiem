package at.petrak.hexcasting.client.render;

import ;
import F;
import I;
import at.petrak.hexcasting.api.client.ScryingLensOverlayRegistry;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.api.utils.QuaternionfUtils;
import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.lib.HexAttributes;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;
import net.minecraft.util.Language;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class HexAdditionalRenderers {
    public static void overlayLevel(MatrixStack ps, float partialTick) {
        var player = MinecraftClient.getInstance().player;
        if (player != null) {
            var sentinel = IXplatAbstractions.INSTANCE.getSentinel(player);
            if (sentinel != null && player.getWorld().getRegistryKey().equals(sentinel.dimension())) {
                renderSentinel(sentinel, player, ps, partialTick);
            }
        }
    }

    public static void overlayGui(DrawContext graphics, float partialTicks) {
        tryRenderScryingLensOverlay(graphics, partialTicks);
    }

    private static void renderSentinel(Sentinel sentinel, ClientPlayerEntity owner,
        MatrixStack ps, float partialTicks) {
        ps.push();

        // zero vector is the player
        var mc = MinecraftClient.getInstance();
        var camera = mc.gameRenderer.getCamera();
        var playerPos = camera.getPos();
        ps.translate(
            sentinel.position().x - playerPos.x,
            sentinel.position().y - playerPos.y,
            sentinel.position().z - playerPos.z);

        var time = ClientTickCounter.getTotal() / 2;
        var bobSpeed = 1f / 20;
        var magnitude = 0.1f;
        ps.translate(0, MathHelper.sin(bobSpeed * time) * magnitude, 0);
        var spinSpeed = 1f / 30;
        ps.multiply(QuaternionfUtils.fromXYZ(new Vector3f(0, spinSpeed * time, 0)));
        if (sentinel.extendsRange()) {
            ps.multiply(QuaternionfUtils.fromXYZ(new Vector3f(spinSpeed * time / 8f, 0, 0)));
        }

        float scale = 0.5f;
        ps.scale(scale, scale, scale);


        var tess = Tessellator.getInstance();
        var buf = tess.getBuffer();
        var neo = ps.peek().getPositionMatrix();
        RenderSystem.enableBlend();
        RenderSystem.setShader(GameRenderer::getRenderTypeLinesProgram);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.lineWidth(5f);

        var pigment = IXplatAbstractions.INSTANCE.getPigment(owner);
        var colProvider = pigment.getColorProvider();
        BiConsumer<float[], float[]> v = (l, r) -> {
            int lcolor = colProvider.getColor(time, new Vec3d(l[0], l[1], l[2])),
                rcolor = colProvider.getColor(time, new Vec3d(r[0], r[1], r[2]));
            var normal = new Vector3f(r[0] - l[0], r[1] - l[1], r[2] - l[2]);
            normal.normalize();
            buf.vertex(neo, l[0], l[1], l[2])
                .color(lcolor)
                .normal(ps.peek().getNormalMatrix(), normal.x(), normal.y(), normal.z())
                .next();
            buf.vertex(neo, r[0], r[1], r[2])
                .color(rcolor)
                .normal(ps.peek().getNormalMatrix(), -normal.x(), -normal.y(), -normal.z())
                .next();
        };

        // Icosahedron inscribed inside the unit sphere
        buf.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
        for (int side = 0; side <= 1; side++) {
            var ring = (side == 0) ? Icos.BOTTOM_RING : Icos.TOP_RING;
            var apex = (side == 0) ? Icos.BOTTOM : Icos.TOP;

            // top & bottom spider
            for (int i = 0; i < 5; i++) {
                v.accept(apex, ring[i]);
            }

            // ring around
            for (int i = 0; i < 5; i++) {
                v.accept(ring[i % 5], ring[(i + 1) % 5]);
            }
        }
        // center band
        for (int i = 0; i < 5; i++) {
            var bottom = Icos.BOTTOM_RING[i];
            v.accept(Icos.TOP_RING[(i + 2) % 5], bottom);
            v.accept(bottom, Icos.TOP_RING[(i + 3) % 5]);
        }
        tess.draw();

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        ps.pop();
    }

    private static class Icos {
        public static float[] TOP = {0, 1, 0};
        public static float[] BOTTOM = {0, -1, 0};
        public static float[][] TOP_RING = new float[5][];
        public static float[][] BOTTOM_RING = new float[5][];

        static {
            var theta = (float) MathHelper.atan2(0.5, 1);
            for (int i = 0; i < 5; i++) {
                var phi = (float) i / 5f * MathHelper.TAU;
                var x = MathHelper.cos(theta) * MathHelper.cos(phi);
                var y = MathHelper.sin(theta);
                var z = MathHelper.cos(theta) * MathHelper.sin(phi);
                TOP_RING[i] = new float[]{x, y, z};
                BOTTOM_RING[i] = new float[]{-x, -y, -z};
            }
        }
    }

    private static void tryRenderScryingLensOverlay(DrawContext graphics, float partialTicks) {
        var mc = MinecraftClient.getInstance();
        var ps = graphics.getMatrices();

        ClientPlayerEntity player = mc.player;
        ClientWorld level = mc.world;
        if (player == null || level == null) {
            return;
        }

        if (player.getAttributeValue(HexAttributes.SCRY_SIGHT) <= 0.0 || player.getAttributeValue(HexAttributes.FEEBLE_MIND) > 0)
            return;

        var hitRes = mc.crosshairTarget;
        if (hitRes != null && hitRes.getType() == HitResult.Type.BLOCK) {
            var bhr = (BlockHitResult) hitRes;
            var pos = bhr.getBlockPos();
            var bs = level.getBlockState(pos);

            var lines = ScryingLensOverlayRegistry.getLines(bs, pos, player, level, bhr.getSide());

            int totalHeight = 8;
            List<Pair<ItemStack, List<StringVisitable>>> actualLines = Lists.newArrayList();

            var window = mc.getWindow();
            var maxWidth = (int) (window.getScaledWidth() / 2f * 0.8f);

            for (var pair : lines) {
                totalHeight += mc.textRenderer.fontHeight + 6;
                var text = pair.getSecond();
                var textLines = mc.textRenderer.getTextHandler().wrapLines(text, maxWidth, Style.EMPTY);

                actualLines.add(Pair.of(pair.getFirst(), textLines));

                if (textLines.size() > 1) {
                    totalHeight += mc.textRenderer.fontHeight * (textLines.size() - 1);
                }
            }

            if (!lines.isEmpty()) {
                var x = window.getScaledWidth() / 2f + 8f;
                var y = window.getScaledHeight() / 2f - totalHeight;
                ps.push();
                ps.translate(x, y, 0);

                for (var pair : actualLines) {
                    var stack = pair.getFirst();
                    if (!stack.isEmpty()) {
                        // this draws centered in the Y ...
                        graphics.drawItem(pair.getFirst(), 0, 0);
                    }
                    int tx = stack.isEmpty() ? 0 : 18;
                    int ty = 5;
                    // but this draws where y=0 is the baseline
                    var text = pair.getSecond();

                    for (var line : text) {
                        var actualLine = Language.getInstance().reorder(line);
                        graphics.drawTextWithShadow(mc.textRenderer, actualLine, tx, ty, 0xffffffff);
                        ps.translate(0, mc.textRenderer.fontHeight, 0);
                    }
                    if (text.isEmpty()) {
                        ps.translate(0, mc.textRenderer.fontHeight, 0);
                    }
                    ps.translate(0, 6, 0);
                }

                ps.pop();
            }
        }
    }
}
