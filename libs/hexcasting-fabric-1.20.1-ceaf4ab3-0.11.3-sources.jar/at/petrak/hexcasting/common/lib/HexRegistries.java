package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.sideeffects.EvalSound;
import at.petrak.hexcasting.api.casting.eval.vm.ContinuationFrame;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexRegistries {
    public static final RegistryKey<Registry<ActionRegistryEntry>> ACTION = RegistryKey.ofRegistry(modLoc("action"));
    public static final RegistryKey<Registry<SpecialHandler.Factory<?>>> SPECIAL_HANDLER = RegistryKey.ofRegistry(modLoc("special_handler"));
    public static final RegistryKey<Registry<IotaType<?>>> IOTA_TYPE = RegistryKey.ofRegistry(modLoc("iota_type"));
    public static final RegistryKey<Registry<Arithmetic>> ARITHMETIC = RegistryKey.ofRegistry(modLoc("arithmetic"));
    public static final RegistryKey<Registry<ContinuationFrame.Type<?>>> CONTINUATION_TYPE = RegistryKey.ofRegistry(modLoc("continuation_type"));
    public static final RegistryKey<Registry<EvalSound>> EVAL_SOUND = RegistryKey.ofRegistry(modLoc("eval_sound"));
}
