package at.petrak.hexcasting.fabric.mixin;

import ;
import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.fabric.loot.FabricHexLootModJankery;
import at.petrak.hexcasting.mixin.accessor.AccessorLootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.server.DataPackContents;

@Mixin(DataPackContents.class)
public class FabricMixinReloadableServerResources {
    // Add the amethyst shard
    @Inject(method = "loadResources", at = @At("RETURN"), cancellable = true)
    private static void onLoadResources(CallbackInfoReturnable<CompletableFuture<DataPackContents>> cir) {
        cir.setReturnValue(cir.getReturnValue().thenApply((rsr) -> {
            var amethystTable = rsr.method_29469().getLootTable(class_2246.field_27161.method_26162());
            var theCoolerAmethystTable = (AccessorLootTable) amethystTable;
            var oldFuncs = theCoolerAmethystTable.hex$getFunctions();
            var newFuncs = Arrays.copyOf(oldFuncs, oldFuncs.length + 1);
            var shardReducer = rsr.method_29469().getElement(new class_8488<>(class_8490.field_44497, FabricHexLootModJankery.FUNC_AMETHYST_SHARD_REDUCER));
            if (shardReducer != null) {
                newFuncs[newFuncs.length - 1] = shardReducer;
                theCoolerAmethystTable.hex$setFunctions(newFuncs);
                theCoolerAmethystTable.hex$setCompositeFunction(class_131.method_594(newFuncs));
            } else {
                HexAPI.LOGGER.warn("{} was not found?", FabricHexLootModJankery.FUNC_AMETHYST_SHARD_REDUCER);
            }
            return rsr;
        }));
    }
}
