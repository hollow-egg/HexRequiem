package at.petrak.hexcasting.api.casting.eval;

import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/**
 * Kinda like {@link CastingEnvironment} but for executing mishaps.
 * <p>
 * To avoid horrible O(mn) scope problems we offer a set of stock bad effects.
 * The player is exposed nullably if you like though.
 */
public abstract class MishapEnvironment {
    @Nullable
    protected final ServerPlayerEntity caster;
    protected final ServerWorld world;

    protected MishapEnvironment(ServerWorld world, @Nullable ServerPlayerEntity caster) {
        this.caster = caster;
        this.world = world;
    }

    public abstract void yeetHeldItemsTowards(Vec3d targetPos);

    public abstract void dropHeldItems();

    public abstract void drown();

    public abstract void damage(float healthProportion);

    public abstract void removeXp(int amount);

    public abstract void blind(int ticks);

    protected void yeetItem(ItemStack stack, Vec3d srcPos, Vec3d delta) {
        var entity = new ItemEntity(
            this.world,
            srcPos.x, srcPos.y, srcPos.z,
            stack,
            delta.x + (Math.random() - 0.5) * 0.1,
            delta.y + (Math.random() - 0.5) * 0.1,
            delta.z + (Math.random() - 0.5) * 0.1
        );
        entity.setPickupDelay(40);
        this.world.tryLoadEntity(entity);
    }
}
