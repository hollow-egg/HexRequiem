package at.petrak.hexcasting.common.recipe.ingredient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.JsonOps;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import java.util.*;

public class StateIngredientHelper {
    public static StateIngredient of(Block block) {
        return new StateIngredientBlock(block);
    }

    public static StateIngredient of(BlockState state) {
        return new StateIngredientBlockState(state);
    }

    public static StateIngredient of(TagKey<Block> tag) {
        return of(tag.id());
    }

    public static StateIngredient of(Identifier id) {
        return new StateIngredientTag(id);
    }

    public static StateIngredient of(Collection<Block> blocks) {
        return new StateIngredientBlocks(blocks);
    }

    public static StateIngredient tagExcluding(TagKey<Block> tag, StateIngredient... excluded) {
        return new StateIngredientTagExcluding(tag.id(), List.of(excluded));
    }

    public static StateIngredient deserialize(JsonObject object) {
        switch (JsonHelper.getString(object, "type")) {
            case "tag":
                return new StateIngredientTag(new Identifier(JsonHelper.getString(object, "tag")));
            case "block":
                return new StateIngredientBlock(
                        Registries.BLOCK.get(new Identifier(JsonHelper.getString(object, "block"))));
            case "state":
                return new StateIngredientBlockState(readBlockState(object));
            case "blocks":
                List<Block> blocks = new ArrayList<>();
                for (JsonElement element : JsonHelper.getArray(object, "blocks")) {
                    blocks.add(Registries.BLOCK.get(new Identifier(element.getAsString())));
                }
                return new StateIngredientBlocks(blocks);
            case "tag_excluding":
                Identifier tag = new Identifier(JsonHelper.getString(object, "tag"));
                List<StateIngredient> ingr = new ArrayList<>();
                for (JsonElement element : JsonHelper.getArray(object, "exclude")) {
                    ingr.add(deserialize(JsonHelper.asObject(element, "exclude entry")));
                }
                return new StateIngredientTagExcluding(tag, ingr);
            default:
                throw new JsonParseException("Unknown type!");
        }
    }

    /**
     * Deserializes a state ingredient, but removes air from its data,
     * and returns null if the ingredient only matched air.
     */
    @Nullable
    public static StateIngredient tryDeserialize(JsonObject object) {
        StateIngredient ingr = deserialize(object);
        if (ingr instanceof StateIngredientTag sit) {
            if (sit.resolve().findAny().isEmpty()) {
                return null;
            }
            return ingr;
        }
        if (ingr instanceof StateIngredientBlock || ingr instanceof StateIngredientBlockState) {
            if (ingr.test(Blocks.AIR.getDefaultState())) {
                return null;
            }
        } else if (ingr instanceof StateIngredientBlocks sib) {
            Collection<Block> blocks = sib.blocks;
            List<Block> list = new ArrayList<>(blocks);
            if (list.removeIf(b -> b == Blocks.AIR)) {
                if (list.size() == 0) {
                    return null;
                }
                return of(list);
            }
        }
        return ingr;
    }

    public static StateIngredient read(PacketByteBuf buffer) {
        switch (buffer.readVarInt()) {
            case 0:
                int count = buffer.readVarInt();
                Set<Block> set = new HashSet<>();
                for (int i = 0; i < count; i++) {
                    int id = buffer.readVarInt();
                    Block block = Registries.BLOCK.get(id);
                    set.add(block);
                }
                return new StateIngredientBlocks(set);
            case 1:
                return new StateIngredientBlock(Registries.BLOCK.get(buffer.readVarInt()));
            case 2:
                return new StateIngredientBlockState(Block.getStateFromRawId(buffer.readVarInt()));
            default:
                throw new IllegalArgumentException("Unknown input discriminator!");
        }
    }

    /**
     * Writes data about the block state to the provided json object.
     */
    public static JsonObject serializeBlockState(BlockState state) {
        NbtCompound nbt = NbtHelper.fromBlockState(state);
        renameTag(nbt, "Name", "name");
        renameTag(nbt, "Properties", "properties");
        Dynamic<net.minecraft.nbt.NbtElement> dyn = new Dynamic<>(NbtOps.INSTANCE, nbt);
        return dyn.convert(JsonOps.INSTANCE).getValue().getAsJsonObject();
    }

    /**
     * Reads the block state from the provided json object.
     */
    public static BlockState readBlockState(JsonObject object) {
        NbtCompound nbt = (NbtCompound) new Dynamic<>(JsonOps.INSTANCE, object).convert(NbtOps.INSTANCE).getValue();
        renameTag(nbt, "name", "Name");
        renameTag(nbt, "properties", "Properties");
        String name = nbt.getString("Name");
        Identifier id = Identifier.tryParse(name);
        if (id == null || !Registries.BLOCK.getOrEmpty(id).isPresent()) {
            throw new IllegalArgumentException("Invalid or unknown block ID: " + name);
        }
        return NbtHelper.toBlockState(Registries.BLOCK.getReadOnlyWrapper(), nbt);
    }

    @Deprecated
    @Nonnull
    public static List<ItemStack> toStackList(StateIngredient input) {
        return input.getDisplayedStacks();
    }

    private static void renameTag(NbtCompound tag, String from, String to) {
        var t = tag.get(from);
        if (t != null) {
            tag.remove(from);
            tag.put(to, t);
        }
    }
}