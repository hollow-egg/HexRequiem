package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.client.render.PatternTextureManager;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public class PatternTexturesCommand
{
    public static void add(LiteralArgumentBuilder<ServerCommandSource> cmd) {
        // TODO: do we want these in release ??
        cmd.then(CommandManager.literal("textureToggle")
                .requires(dp -> dp.hasPermissionLevel(CommandManager.field_31840))
                .executes(ctx -> {
                    PatternTextureManager.useTextures = !PatternTextureManager.useTextures;
                    String log = (PatternTextureManager.useTextures ? "Enabled" : "Disabled") + " pattern texture rendering. This is meant for debugging.";
                    ctx.getSource().sendFeedback(() -> Text.literal(log), true);
                    return 1;
                }));
        cmd.then(CommandManager.literal("textureRepaint")
                .requires(dp -> dp.hasPermissionLevel(CommandManager.field_31840))
                .executes(ctx -> {
                    PatternTextureManager.repaint();
                    ctx.getSource().sendFeedback(() -> Text.literal("Repainting pattern textures. This is meant for debugging."), true);
                    return 1;
                }));
    }
}