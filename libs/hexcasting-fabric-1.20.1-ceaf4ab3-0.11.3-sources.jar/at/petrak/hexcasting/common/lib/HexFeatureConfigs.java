package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import com.mojang.serialization.JsonOps;
import java.util.OptionalInt;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.collection.DataPool;
import net.minecraft.util.math.intprovider.ConstantIntProvider;
import net.minecraft.world.gen.feature.TreeFeatureConfig;
import net.minecraft.world.gen.feature.size.TwoLayersFeatureSize;
import net.minecraft.world.gen.foliage.LargeOakFoliagePlacer;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;
import net.minecraft.world.gen.stateprovider.WeightedBlockStateProvider;
import net.minecraft.world.gen.trunk.LargeOakTrunkPlacer;

public class HexFeatureConfigs {
    public static void dumpConfigs() {
        // Used to generate the tree data json files
        // Call this after the game is properly bootstrapped and copy the output logs to data/hexcasting/worldgen/configured_feature/${name}.json
        // This should be done in DataGen, but I was unable to make that function. - dashkal16
        HexAPI.LOGGER.info(TreeFeatureConfig.CODEC.encodeStart(JsonOps.INSTANCE, AMETHYST_EDIFIED_TREE_CONFIG));
        HexAPI.LOGGER.info(TreeFeatureConfig.CODEC.encodeStart(JsonOps.INSTANCE, AVENTURINE_EDIFIED_TREE_CONFIG));
        HexAPI.LOGGER.info(TreeFeatureConfig.CODEC.encodeStart(JsonOps.INSTANCE, CITRINE_EDIFIED_TREE_CONFIG));
    }

    public static final TreeFeatureConfig AMETHYST_EDIFIED_TREE_CONFIG = akashicTree(HexBlocks.AMETHYST_EDIFIED_LEAVES, HexBlocks.EDIFIED_LOG_AMETHYST);
    public static final TreeFeatureConfig AVENTURINE_EDIFIED_TREE_CONFIG = akashicTree(HexBlocks.AVENTURINE_EDIFIED_LEAVES, HexBlocks.EDIFIED_LOG_AVENTURINE);
    public static final TreeFeatureConfig CITRINE_EDIFIED_TREE_CONFIG = akashicTree(HexBlocks.CITRINE_EDIFIED_LEAVES, HexBlocks.EDIFIED_LOG_CITRINE);

    private static TreeFeatureConfig akashicTree(Block leaves, Block altLog) {
        return new TreeFeatureConfig.Builder(
                new WeightedBlockStateProvider(
                        DataPool.<BlockState>builder()
                                .add(HexBlocks.EDIFIED_LOG.getDefaultState(), 8)
                                .add(altLog.getDefaultState(), 1)
                                .build()),
                // baseHeight, heightRandA, heightRandB
                new LargeOakTrunkPlacer(5, 5, 3),
                BlockStateProvider.of(leaves),
                // radius, offset, height
                new LargeOakFoliagePlacer(ConstantIntProvider.create(1), ConstantIntProvider.create(5), 5),
                // limit, lower size, upper size, minclippedheight
                new TwoLayersFeatureSize(0, 0, 0, OptionalInt.of(6))
        ).build();
    }
}
