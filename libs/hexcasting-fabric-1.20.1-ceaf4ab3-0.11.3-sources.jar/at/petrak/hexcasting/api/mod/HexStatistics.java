package at.petrak.hexcasting.api.mod;

import at.petrak.hexcasting.api.misc.MediaConstants;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.stat.StatFormatter;
import net.minecraft.stat.Stats;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexStatistics {
    public static final Identifier MEDIA_USED = makeCustomStat("media_used",
        mediamount -> StatFormatter.DEFAULT.format((int) (mediamount / MediaConstants.DUST_UNIT)));
    public static final Identifier MEDIA_OVERCAST = makeCustomStat("media_overcast",
        mediamount -> StatFormatter.DEFAULT.format((int) (mediamount / MediaConstants.DUST_UNIT)));
    public static final Identifier PATTERNS_DRAWN = makeCustomStat("patterns_drawn", StatFormatter.DEFAULT);
    public static final Identifier SPELLS_CAST = makeCustomStat("spells_cast", StatFormatter.DEFAULT);

    public static void register() {
        // wake up java
    }

    private static Identifier makeCustomStat(String key, StatFormatter formatter) {
        Identifier resourcelocation = modLoc(key);
        Registry.register(Registries.CUSTOM_STAT, key, resourcelocation);
        Stats.CUSTOM.getOrCreateStat(resourcelocation, formatter);
        return resourcelocation;
    }
}
