package at.petrak.hexcasting.client.model;

import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.ElytraEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/1.19.x/Xplat/src/main/java/vazkii/botania/client/model/BotaniaModelLayers.java
public class HexModelLayers {
    public static final EntityModelLayer ALTIORA = make("altiora");

    public static final EntityModelLayer ROBES = make("robes");

    private static EntityModelLayer make(String name) {
        return make(name, "main");
    }

    private static EntityModelLayer make(String name, String layer) {
        // Don't add to vanilla's ModelLayers. It seems to only be used for error checking
        // And would be annoying to do under Forge's parallel mod loading
        return new EntityModelLayer(modLoc(name), layer);
    }

    // moving this stuff into the same file:
    // https://github.com/VazkiiMods/Botania/blob/1.19.x/Xplat/src/main/java/vazkii/botania/client/model/BotaniaLayerDefinitions.java
    public static void init(BiConsumer<EntityModelLayer, Supplier<TexturedModelData>> consumer) {
        consumer.accept(ALTIORA, ElytraEntityModel::getTexturedModelData);
        consumer.accept(ROBES, HexRobesModels::variant1);
    }
}
