package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import I;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.village.VillagerProfession;
import net.minecraft.village.VillagerType;
import net.minecraft.world.World;

/**
 * Special case for villagers so we can have biome/profession/level reqs
 */
public class VillagerIngredient extends BrainsweepeeIngredient {
    public final @Nullable VillagerProfession profession;
    public final @Nullable VillagerType biome;
    public final int minLevel;

    public VillagerIngredient(
        @Nullable VillagerProfession profession,
        @Nullable VillagerType biome,
        int minLevel
    ) {
        this.profession = profession;
        this.biome = biome;
        this.minLevel = minLevel;
    }

    @Override
    public boolean test(Entity entity, ServerWorld level) {
        if (!(entity instanceof VillagerEntity villager)) return false;

        var data = villager.getVillagerData();

        return (this.profession == null || this.profession.equals(data.getProfession()))
            && (this.biome == null || this.biome.equals(data.getType()))
            && this.minLevel <= data.getLevel();
    }

    @Override
    public Entity exampleEntity(World level) {
        var biome = Objects.requireNonNullElse(this.biome, VillagerType.PLAINS);
        var profession = Objects.requireNonNullElse(this.profession, VillagerProfession.TOOLSMITH);
        var tradeLevel = Math.min(this.minLevel, 1);

        var out = new VillagerEntity(EntityType.VILLAGER, level);

        var data = out.getVillagerData();
        data
            .withProfession(profession)
            .withType(biome)
            .withLevel(tradeLevel);
        out.setVillagerData(data);

        // just random bullshit go to try and get it to update for god's sake
        var tag = new NbtCompound();
        out.saveNbt(tag);

        return out;
    }

    @Override
    public List<Text> getTooltip(boolean advanced) {
        List<Text> tooltip = new ArrayList<>();
        tooltip.add(this.getName());

        if (advanced) {
            if (minLevel >= 5) {
                tooltip.add(Text.translatable("hexcasting.tooltip.brainsweep.level", 5)
                    .formatted(Formatting.DARK_GRAY));
            } else if (minLevel > 1) {
                tooltip.add(Text.translatable("hexcasting.tooltip.brainsweep.min_level", minLevel)
                    .formatted(Formatting.DARK_GRAY));
            }

            if (this.biome != null) {
                tooltip.add(Text.literal(this.biome.toString()).formatted(Formatting.DARK_GRAY));
            }

            if (this.profession != null) {
                tooltip.add(Text.literal(this.profession.toString()).formatted(Formatting.DARK_GRAY));
            }
        }

        tooltip.add(BrainsweepeeIngredient.getModNameComponent(
            this.profession == null
                ? "minecraft"
                : Registries.VILLAGER_PROFESSION.getId(this.profession).getNamespace()));

        return tooltip;
    }

    @Override
    public Text getName() {
        MutableText component = Text.literal("");

        boolean addedAny = false;

        if (minLevel >= 5) {
            component.append(Text.translatable("merchant.level.5"));
            addedAny = true;
        } else if (minLevel > 1) {
            component.append(Text.translatable("merchant.level." + minLevel));
            addedAny = true;
        } else if (profession != null) {
            component.append(Text.translatable("merchant.level.1"));
            addedAny = true;
        }

        if (biome != null) {
            if (addedAny) {
                component.append(" ");
            }
            var biomeLoc = Registries.VILLAGER_TYPE.getId(this.biome);
            component.append(Text.translatable("biome." + biomeLoc.getNamespace() + "." + biomeLoc.getPath()));
            addedAny = true;
        }

        if (profession != null) {
            // We've for sure added something
            component.append(" ");
            var professionLoc = Registries.VILLAGER_PROFESSION.getId(this.profession);
            // TODO: what's the convention used for modded villager types?
            // Villager::getTypeName implies that it there's no namespace information.
            // i hope there is some convention
            component.append(Text.translatable("entity.minecraft.villager." + professionLoc.getPath()));
        } else {
            if (addedAny) {
                component.append(" ");
            }
            component.append(EntityType.VILLAGER.getName());
        }

        return component;
    }

    @Override
    public JsonObject serialize() {
        var obj = new JsonObject();
        obj.addProperty("type", Type.VILLAGER.asString());

        if (this.profession != null) {
            obj.addProperty("profession", this.profession.toString());
        }
        if (this.biome != null) {
            obj.addProperty("biome", this.biome.toString());
        }
        obj.addProperty("minLevel", this.minLevel);
        return obj;
    }

    @Override
    public void write(PacketByteBuf buf) {
        if (this.profession != null) {
            buf.writeVarInt(1);
            buf.writeVarInt(Registries.VILLAGER_PROFESSION.getRawId(this.profession));
        } else {
            buf.writeVarInt(0);
        }
        if (this.biome != null) {
            buf.writeVarInt(1);
            buf.writeVarInt(Registries.VILLAGER_TYPE.getRawId(this.biome));
        } else {
            buf.writeVarInt(0);
        }
        buf.writeInt(this.minLevel);
    }

    public static VillagerIngredient deserialize(JsonObject json) {
        VillagerProfession profession = null;
        if (json.has("profession") && !json.get("profession").isJsonNull()) {
            profession = Registries.VILLAGER_PROFESSION.get(new Identifier(JsonHelper.getString(json,
                "profession")));
        }
        VillagerType biome = null;
        if (json.has("biome") && !json.get("biome").isJsonNull()) {
            biome = Registries.VILLAGER_TYPE.get(new Identifier(JsonHelper.getString(json, "biome")));
        }
        int minLevel = JsonHelper.getInt(json, "minLevel");
        return new VillagerIngredient(profession, biome, minLevel);
    }

    public static VillagerIngredient read(PacketByteBuf buf) {
        VillagerProfession profession = null;
        var hasProfession = buf.readVarInt();
        if (hasProfession != 0) {
            profession = Registries.VILLAGER_PROFESSION.get(buf.readVarInt());
        }
        VillagerType biome = null;
        var hasBiome = buf.readVarInt();
        if (hasBiome != 0) {
            biome = Registries.VILLAGER_TYPE.get(buf.readVarInt());
        }
        int minLevel = buf.readInt();
        return new VillagerIngredient(profession, biome, minLevel);
    }

    @Override
    public Type ingrType() {
        return Type.VILLAGER;
    }

    @Override
    public String getSomeKindOfReasonableIDForEmi() {
        var bob = new StringBuilder();
        if (this.profession != null) {
            var profLoc = Registries.VILLAGER_PROFESSION.getId(this.profession);
            bob.append(profLoc.getNamespace())
                .append("//")
                .append(profLoc.getPath());
        } else {
            bob.append("null");
        }
        bob.append("_");
        if (this.biome != null) {
            var biomeLoc = Registries.VILLAGER_TYPE.getId(this.biome);
            bob.append(biomeLoc.getNamespace())
                .append("//")
                .append(biomeLoc.getPath());
        } else {
            bob.append("null");
        }

        bob.append(this.minLevel);
        return bob.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VillagerIngredient that = (VillagerIngredient) o;
        return minLevel == that.minLevel && Objects.equals(profession, that.profession) && Objects.equals(biome,
            that.biome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(profession, biome, minLevel);
    }
}
