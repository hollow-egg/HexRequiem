package at.petrak.hexcasting.common.blocks.akashic;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.common.items.storage.ItemScroll;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class BlockAkashicBookshelf extends Block implements AkashicFloodfiller, BlockEntityProvider, IForgeLikeBlock {
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;
    public static final BooleanProperty HAS_BOOKS = BooleanProperty.of("has_books");

    public BlockAkashicBookshelf(Settings p_49795_) {
        super(p_49795_);
        this.setDefaultState(this.getStateManager().getDefaultState()
            .with(FACING, Direction.NORTH)
            .with(HAS_BOOKS, false));
    }

    @Override
    public ActionResult onUse(BlockState pState, World pLevel, BlockPos pPos, PlayerEntity pPlayer, Hand pHand,
        BlockHitResult pHit) {
        if (pLevel.getBlockEntity(pPos) instanceof BlockEntityAkashicBookshelf shelf) {
            var stack = pPlayer.getStackInHand(pHand);
            if (stack.getItem() instanceof ItemScroll scroll) {
                if (!pLevel.isClient()) {
                    scroll.writeDatum(stack, new PatternIota(shelf.getPattern()));
                }
                pLevel.playSound(pPlayer, pPos, HexSounds.SCROLL_SCRIBBLE, SoundCategory.BLOCKS, 1f, 1f);
                return ActionResult.success(pLevel.isClient);
            } else if (pPlayer.isSneaky() && pHand == Hand.MAIN_HAND && stack.isEmpty()) {
                if (!pLevel.isClient()) {
                    shelf.clearIota();
                }

                pLevel.playSound(pPlayer, pPos, HexSounds.SCROLL_SCRIBBLE, SoundCategory.BLOCKS,
                    1f, 0.8f);
                return ActionResult.success(pLevel.isClient);
            }
        }

        return ActionResult.PASS;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, HAS_BOOKS);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return this.getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
    }

    @SoftImplement("forge")
    public float getEnchantPowerBonus(BlockState state, WorldView level, BlockPos pos) {
        return hasEnchantPowerBonus(state, level, pos) ? 1 : 0;
    }

    @Override
    public boolean hasEnchantPowerBonus(BlockState state, WorldView level, BlockPos pos) {
        return true;
    }

    @Override
    public boolean hasComparatorOutput(BlockState pState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState pState, World pLevel, BlockPos pPos) {
        return pState.get(HAS_BOOKS) ? 15 : 0; // TODO have an iota -> comparator value mapping?
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pPos, BlockState pState) {
        return new BlockEntityAkashicBookshelf(pPos, pState);
    }

    public BlockState rotate(BlockState pState, BlockRotation pRot) {
        return pState.with(FACING, pRot.rotate(pState.get(FACING)));
    }

    public BlockState mirror(BlockState pState, BlockMirror pMirror) {
        return pState.rotate(pMirror.getRotation(pState.get(FACING)));
    }
}
