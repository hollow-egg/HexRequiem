package at.petrak.hexcasting.datagen.recipe.builders;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public record ItemProcessingOutput(ItemStack stack, float chance) implements ProcessingOutput {
    @Override
    public JsonObject serialize() {
        JsonObject json = new JsonObject();
        Identifier resourceLocation = Registries.ITEM.getId(stack.getItem());
        json.addProperty("item", resourceLocation.toString());
        int count = stack.getCount();
        if (count != 1) {
            json.addProperty("count", count);
        }
        if (stack.hasNbt()) {
            json.add("nbt", JsonParser.parseString(stack.getNbt().toString()));
        }
        if (chance != 1) {
            json.addProperty("chance", chance);
        }
        return json;
    }
}
