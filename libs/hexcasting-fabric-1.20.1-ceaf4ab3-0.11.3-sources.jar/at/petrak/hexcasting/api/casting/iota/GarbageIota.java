package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Random;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * this is LITERALLY a copy of NullIota but I can't see how to do it any better, i hate java generics
 */
public class GarbageIota extends Iota {
    private static final Object NULL_SUBSTITUTE = new Object();

    public static final Text DISPLAY = Text.literal("arimfexendrapuse")
        .formatted(Formatting.DARK_GRAY, Formatting.OBFUSCATED);

    private static final Random RANDOM = new Random();

    public GarbageIota() {
        // We have to pass *something* here, but there's nothing that actually needs to go there,
        // so we just do this i guess
        super(HexIotaTypes.GARBAGE, NULL_SUBSTITUTE);
    }

    @Override
    public boolean isTruthy() {
        return false;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that);
    }

    @Override
    public @NotNull NbtElement serialize() {
        return new NbtCompound();
    }

    public static IotaType<GarbageIota> TYPE = new IotaType<>() {
        @Nullable
        @Override
        public GarbageIota deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException {
            return new GarbageIota();
        }

        @Override
        public Text display(NbtElement tag) {
            return DISPLAY;
        }

        @Override
        public int color() {
            return 0xff_505050;
        }
    };
}
