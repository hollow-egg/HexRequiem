package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import net.minecraft.client.item.TooltipData;
import net.minecraft.util.Identifier;

/**
 * Used for displaying patterns on the tooltips for scrolls and slates.
 *
 * @see at.petrak.hexcasting.client.gui.PatternTooltipComponent the client-side renderer for this
 */
public record PatternTooltip(HexPattern pattern, Identifier background) implements TooltipData {
}
