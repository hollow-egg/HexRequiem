package at.petrak.hexcasting.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import javax.annotation.Nullable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;

@Mixin(ItemUsageContext.class)
public interface AccessorUseOnContext {
    @Invoker("<init>")
    static ItemUsageContext hex$new(World $$0, @Nullable PlayerEntity $$1, Hand $$2, ItemStack $$3,
        BlockHitResult $$4) {
        throw new IllegalStateException();
    }
}
