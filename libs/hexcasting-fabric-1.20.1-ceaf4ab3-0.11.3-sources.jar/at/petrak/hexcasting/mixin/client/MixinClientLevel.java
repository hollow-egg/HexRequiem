package at.petrak.hexcasting.mixin.client;

import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(ClientWorld.class)
public abstract class MixinClientLevel {

    @Inject(method = "doAnimateTick",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;animateTick" +
            "(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;" +
            "Lnet/minecraft/core/BlockPos;Lnet/minecraft/util/RandomSource;)V"),
        locals = LocalCapture.CAPTURE_FAILSOFT)
    public void addBuddingAmethystParticles(int $$0, int $$1, int $$2, int $$3, Random rand, Block $$5,
        BlockPos.Mutable pos, CallbackInfo ci, int trueX, int trueY, int trueZ, BlockState state) {
        ClientWorld self = ((ClientWorld) (Object) this);

        if (state.isOf(Blocks.BUDDING_AMETHYST)) {
            ParticleEffect options = new ConjureParticleOptions(0x8932b8);
            Vec3d center = Vec3d.ofCenter(pos);
            for (Direction direction : Direction.values()) {
                int dX = direction.getOffsetX();
                int dY = direction.getOffsetY();
                int dZ = direction.getOffsetZ();

                int count = rand.nextInt(10) / 5;
                for (int i = 0; i < count; i++) {
                    double pX = center.x + (dX == 0 ? MathHelper.nextDouble(rand, -0.5D, 0.5D) : (double) dX * 0.55D);
                    double pY = center.y + (dY == 0 ? MathHelper.nextDouble(rand, -0.5D, 0.5D) : (double) dY * 0.55D);
                    double pZ = center.z + (dZ == 0 ? MathHelper.nextDouble(rand, -0.5D, 0.5D) : (double) dZ * 0.55D);
                    self.addParticle(options, pX, pY, pZ, 0, 0, 0);
                }
            }
        }
    }

}
