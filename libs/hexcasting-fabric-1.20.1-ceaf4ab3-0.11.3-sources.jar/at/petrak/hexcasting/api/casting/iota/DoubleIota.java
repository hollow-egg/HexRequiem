package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import net.minecraft.nbt.NbtDouble;
import net.minecraft.nbt.NbtElement;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DoubleIota extends Iota {
    public static final double TOLERANCE = 0.0001;

    public DoubleIota(double d) {
        super(HexIotaTypes.DOUBLE, d);
    }

    public double getDouble() {
        return HexUtils.fixNAN((Double) this.payload);
    }

    @Override
    public boolean isTruthy() {
        return this.getDouble() != 0.0;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof DoubleIota dd
            && tolerates(this.getDouble(), dd.getDouble());
    }

    public static boolean tolerates(double a, double b) {
        return Math.abs(a - b) < TOLERANCE;
    }

    @Override
    public @NotNull NbtElement serialize() {
        return NbtDouble.of(this.getDouble());
    }

    public static IotaType<DoubleIota> TYPE = new IotaType<>() {
        @Nullable
        @Override
        public DoubleIota deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException {
            return DoubleIota.deserialize(tag);
        }

        @Override
        public Text display(NbtElement tag) {
            return DoubleIota.display(DoubleIota.deserialize(tag).getDouble());
        }

        @Override
        public int color() {
            return 0xff_55ff55;
        }
    };

    public static DoubleIota deserialize(NbtElement tag) throws IllegalArgumentException {
        var dtag = HexUtils.downcast(tag, NbtDouble.TYPE);
        return new DoubleIota(dtag.doubleValue());
    }

    public static Text display(double d) {
        return Text.literal(String.format("%.2f", d)).formatted(Formatting.GREEN);
    }
}
