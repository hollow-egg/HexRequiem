package at.petrak.hexcasting.api.casting.eval.env;

import at.petrak.hexcasting.api.casting.circles.CircleExecutionState;
import at.petrak.hexcasting.api.casting.eval.MishapEnvironment;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

public class CircleMishapEnv extends MishapEnvironment {
    protected final CircleExecutionState execState;

    protected CircleMishapEnv(ServerWorld world, CircleExecutionState execState) {
        super(world, null);
        this.execState = execState;
    }

    @Override
    public void yeetHeldItemsTowards(Vec3d targetPos) {

    }

    @Override
    public void dropHeldItems() {

    }

    @Override
    public void drown() {

    }

    @Override
    public void damage(float healthProportion) {

    }

    @Override
    public void removeXp(int amount) {

    }

    @Override
    public void blind(int ticks) {

    }
}
