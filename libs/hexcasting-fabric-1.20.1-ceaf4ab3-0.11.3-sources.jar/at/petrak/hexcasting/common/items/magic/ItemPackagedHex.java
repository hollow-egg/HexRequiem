package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.eval.ExecutionClientView;
import at.petrak.hexcasting.api.casting.eval.env.PackagedItemCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.item.HexHolderItem;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.common.msgs.MsgNewSpiralPatternsS2C;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.stat.Stat;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

/**
 * Item that holds a list of patterns in it ready to be cast
 */
public abstract class ItemPackagedHex extends ItemMediaHolder implements HexHolderItem {
    public static final String TAG_PROGRAM = "patterns";
    public static final String TAG_PIGMENT = "pigment";
    public static final Identifier HAS_PATTERNS_PRED = modLoc("has_patterns");

    public ItemPackagedHex(Settings pProperties) {
        super(pProperties);
    }

    public abstract boolean breakAfterDepletion();

    public abstract int cooldown();

    @Override
    public boolean canRecharge(ItemStack stack) {
        return !breakAfterDepletion();
    }

    @Override
    public boolean canProvideMedia(ItemStack stack) {
        return false;
    }

    @Override
    public boolean hasHex(ItemStack stack) {
        return NBTHelper.hasList(stack, TAG_PROGRAM, NbtElement.COMPOUND_TYPE);
    }

    @Override
    public @Nullable List<Iota> getHex(ItemStack stack, ServerWorld level) {
        var patsTag = NBTHelper.getList(stack, TAG_PROGRAM, NbtElement.COMPOUND_TYPE);

        if (patsTag == null) {
            return null;
        }

        var out = new ArrayList<Iota>();
        for (var patTag : patsTag) {
            NbtCompound tag = NBTHelper.getAsCompound(patTag);
            out.add(IotaType.deserialize(tag, level));
        }
        return out;
    }

    @Override
    public void writeHex(ItemStack stack, List<Iota> program, @Nullable FrozenPigment pigment, long media) {
        NbtList patsTag = new NbtList();
        for (Iota pat : program) {
            patsTag.add(IotaType.serialize(pat));
        }

        NBTHelper.putList(stack, TAG_PROGRAM, patsTag);
        if (pigment != null)
            NBTHelper.putCompound(stack, TAG_PIGMENT, pigment.serializeToNBT());

        withMedia(stack, media, media);
    }

    @Override
    public void clearHex(ItemStack stack) {
        NBTHelper.remove(stack, TAG_PROGRAM);
        NBTHelper.remove(stack, TAG_PIGMENT);
        NBTHelper.remove(stack, TAG_MEDIA);
        NBTHelper.remove(stack, TAG_MAX_MEDIA);
    }

    @Override
    public @Nullable FrozenPigment getPigment(ItemStack stack) {
        var ctag = NBTHelper.getCompound(stack, TAG_PIGMENT);
        if (ctag == null)
            return null;
        return FrozenPigment.fromNBT(ctag);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand usedHand) {
        var stack = player.getStackInHand(usedHand);
        if (!hasHex(stack)) {
            return TypedActionResult.fail(stack);
        }

        if (world.isClient) {
            return TypedActionResult.success(stack);
        }

        List<Iota> instrs = getHex(stack, (ServerWorld) world);
        if (instrs == null) {
            return TypedActionResult.fail(stack);
        }
        var sPlayer = (ServerPlayerEntity) player;
        var ctx = new PackagedItemCastEnv(sPlayer, usedHand);
        var vm = CastingVM.empty(ctx);
        var clientView = vm.queueExecuteAndWrapIotas(instrs, sPlayer.getServerWorld());

        var patterns = instrs.stream()
                .filter(i -> i instanceof PatternIota)
                .map(i -> ((PatternIota) i).getPattern())
                .toList();
        var packet = new MsgNewSpiralPatternsS2C(sPlayer.getUuid(), patterns, 140);
        IXplatAbstractions.INSTANCE.sendPacketToPlayer(sPlayer, packet);
        IXplatAbstractions.INSTANCE.sendPacketTracking(sPlayer, packet);

        boolean broken = breakAfterDepletion() && getMedia(stack) == 0;

        Stat<?> stat;
        if (broken) {
            stat = Stats.BROKEN.getOrCreateStat(this);
        } else {
            stat = Stats.USED.getOrCreateStat(this);
        }
        player.incrementStat(stat);

        sPlayer.getItemCooldownManager().set(this, this.cooldown());

        if (clientView.getResolutionType().getSuccess()) {
            // Somehow we lost spraying particles on each new pattern, so do it here
            // this also nicely prevents particle spam on trinkets
            new ParticleSpray(player.getPos(), new Vec3d(0.0, 1.5, 0.0), 0.4, Math.PI / 3, 30)
                    .sprayParticles(sPlayer.getServerWorld(), ctx.getPigment());
        }

        var sound = ctx.getSound().sound();
        if (sound != null) {
            var soundPos = sPlayer.getPos();
            sPlayer.getWorld().playSound(null, soundPos.x, soundPos.y, soundPos.z,
                    sound, SoundCategory.PLAYERS, 1f, 1f);
        }

        if (broken) {
            stack.decrement(1);
            player.sendToolBreakStatus(usedHand);
            return TypedActionResult.consume(stack);
        } else {
            return TypedActionResult.success(stack);
        }
    }

    @Override
    public UseAction getUseAction(ItemStack pStack) {
        return UseAction.BLOCK;
    }
}
