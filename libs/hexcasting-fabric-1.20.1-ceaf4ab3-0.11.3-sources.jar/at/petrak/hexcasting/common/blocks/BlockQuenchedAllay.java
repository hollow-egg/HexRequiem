package at.petrak.hexcasting.common.blocks;

import at.petrak.hexcasting.common.blocks.entity.BlockEntityQuenchedAllay;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class BlockQuenchedAllay extends Block implements BlockEntityProvider {
    public static final int VARIANTS = 4;

    public BlockQuenchedAllay(Settings properties) {
        super(properties);
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new BlockEntityQuenchedAllay(this, pos, state);
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.INVISIBLE;
    }

    @Override
    public void randomDisplayTick(BlockState state, World level, BlockPos pos, Random rand) {
        ParticleEffect options = new ConjureParticleOptions(0x8932b8);
        Vec3d center = Vec3d.ofCenter(pos);
        for (Direction direction : Direction.values()) {
            int dX = direction.getOffsetX();
            int dY = direction.getOffsetY();
            int dZ = direction.getOffsetZ();

            int count = rand.nextInt(10) / 4;
            for (int i = 0; i < count; i++) {
                double pX = center.x + (dX == 0 ? MathHelper.nextDouble(rand, -0.5D, 0.5D) : (double) dX * 0.55D);
                double pY = center.y + (dY == 0 ? MathHelper.nextDouble(rand, -0.5D, 0.5D) : (double) dY * 0.55D);
                double pZ = center.z + (dZ == 0 ? MathHelper.nextDouble(rand, -0.5D, 0.5D) : (double) dZ * 0.55D);
                double vPerp = MathHelper.nextDouble(rand, 0.0, 0.01);
                double vX = vPerp * dX;
                double vY = vPerp * dY;
                double vZ = vPerp * dZ;
                level.addParticle(options, pX, pY, pZ, vX, vY, vZ);
            }
        }
    }
}
