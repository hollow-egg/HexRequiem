package at.petrak.hexcasting.common.recipe.ingredient;

import com.google.common.collect.ImmutableSet;
import com.google.gson.JsonObject;
import javax.annotation.Nonnull;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StateIngredientTag extends StateIngredientBlocks {
	private final TagKey<Block> tag;

	public StateIngredientTag(Identifier tag) {
		super(ImmutableSet.of());
		this.tag = TagKey.of(RegistryKeys.BLOCK, tag);
	}

	public Stream<Block> resolve() {
		return StreamSupport.stream(Registries.BLOCK.iterateEntries(tag).spliterator(), false)
			.map(RegistryEntry::value);
	}

	@Override
	public boolean test(BlockState state) {
		return state.isIn(tag);
	}

	@Override
	public BlockState pick(Random random) {
		var values = resolve().toList();
		if (values.isEmpty()) {
			return null;
		}
		return values.get(random.nextInt(values.size())).getDefaultState();
	}

	@Override
	public JsonObject serialize() {
		JsonObject object = new JsonObject();
		object.addProperty("type", "tag");
		object.addProperty("tag", tag.id().toString());
		return object;
	}

	@Override
	public List<ItemStack> getDisplayedStacks() {
		return resolve()
			.filter(b -> b.asItem() != Items.AIR)
			.map(ItemStack::new)
			.collect(Collectors.toList());
	}

	@Nonnull
	@Override
	protected List<Block> getBlocks() {
		return resolve().toList();
	}

	@Override
	public List<BlockState> getDisplayed() {
		return resolve().map(Block::getDefaultState).collect(Collectors.toList());
	}

	public Identifier getTagId() {
		return tag.id();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		return tag.equals(((StateIngredientTag) o).tag);
	}

	@Override
	public int hashCode() {
		return tag.hashCode();
	}

	@Override
	public String toString() {
		return "StateIngredientTag{" + tag + "}";
	}
}
