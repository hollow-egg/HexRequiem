package at.petrak.hexcasting.api.casting.eval.env;

import at.petrak.hexcasting.api.casting.eval.MishapEnvironment;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.common.lib.HexDamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class PlayerBasedMishapEnv extends MishapEnvironment {
    public PlayerBasedMishapEnv(ServerPlayerEntity player) {
        super(player.getServerWorld(), player);
    }

    @Override
    public void yeetHeldItemsTowards(Vec3d targetPos) {
        var pos = this.caster.getPos();
        var delta = targetPos.subtract(pos).normalize().multiply(0.5);

        for (var hand : Hand.values()) {
            var stack = this.caster.getStackInHand(hand);
            this.caster.setStackInHand(hand, ItemStack.EMPTY);
            this.yeetItem(stack, pos, delta);
        }
    }

    @Override
    public void dropHeldItems() {
        var delta = this.caster.getRotationVector();
        this.yeetHeldItemsTowards(this.caster.getPos().add(delta));
    }

    @Override
    public void damage(float healthProportion) {
        Mishap.trulyHurt(this.caster, this.caster.getDamageSources().create(HexDamageTypes.OVERCAST), this.caster.getHealth() * healthProportion);
    }

    @Override
    public void drown() {
        if (this.caster.getAir() < 200) {
            this.caster.damage(this.caster.getDamageSources().drown(), 2f);
        }
        this.caster.setAir(0);
    }

    @Override
    public void removeXp(int amount) {
        this.caster.addExperience(-amount);
    }

    @Override
    public void blind(int ticks) {
        this.caster.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, ticks));
    }
}
