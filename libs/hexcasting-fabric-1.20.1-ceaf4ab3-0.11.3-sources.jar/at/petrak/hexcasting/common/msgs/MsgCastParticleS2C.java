package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import io.netty.buffer.ByteBuf;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import D;
import I;

/**
 * Sent server->client to spray particles everywhere.
 */
public record MsgCastParticleS2C(ParticleSpray spray, FrozenPigment colorizer) implements IMessage {
    public static final Identifier ID = modLoc("cprtcl");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    public static MsgCastParticleS2C deserialize(ByteBuf buffer) {
        var buf = new PacketByteBuf(buffer);
        var posX = buf.readDouble();
        var posY = buf.readDouble();
        var posZ = buf.readDouble();
        var velX = buf.readDouble();
        var velY = buf.readDouble();
        var velZ = buf.readDouble();
        var fuzziness = buf.readDouble();
        var spread = buf.readDouble();
        var count = buf.readInt();
        var tag = buf.readUnlimitedNbt();
        var colorizer = FrozenPigment.fromNBT(tag);
        return new MsgCastParticleS2C(
            new ParticleSpray(new Vec3d(posX, posY, posZ), new Vec3d(velX, velY, velZ), fuzziness, spread, count),
            colorizer);
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        buf.writeDouble(this.spray.getPos().x);
        buf.writeDouble(this.spray.getPos().y);
        buf.writeDouble(this.spray.getPos().z);
        buf.writeDouble(this.spray.getVel().x);
        buf.writeDouble(this.spray.getVel().y);
        buf.writeDouble(this.spray.getVel().z);
        buf.writeDouble(this.spray.getFuzziness());
        buf.writeDouble(this.spray.getSpread());
        buf.writeInt(this.spray.getCount());
        buf.writeNbt(this.colorizer.serializeToNBT());
    }


    private static final Random RANDOM = new Random();

    // https://math.stackexchange.com/questions/44689/how-to-find-a-random-axis-or-unit-vector-in-3d
    private static Vec3d randomInCircle(double maxTh) {
        var th = RANDOM.nextDouble(0.0, maxTh + 0.001);
        var z = RANDOM.nextDouble(-1.0, 1.0);
        return new Vec3d(Math.sqrt(1.0 - z * z) * Math.cos(th), Math.sqrt(1.0 - z * z) * Math.sin(th), z);
    }

    public static void handle(MsgCastParticleS2C msg) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var colProvider = msg.colorizer().getColorProvider();
                for (int i = 0; i < msg.spray().getCount(); i++) {
                    // For the colors, pick any random time to get a mix of colors

                    var offset = randomInCircle(MathHelper.TAU).normalize()
                        .multiply(RANDOM.nextFloat() * msg.spray().getFuzziness() / 2);
                    var pos = msg.spray().getPos().add(offset);

                    var phi = Math.acos(1.0 - RANDOM.nextDouble() * (1.0 - Math.cos(msg.spray().getSpread())));
                    var theta = Math.PI * 2.0 * RANDOM.nextDouble();
                    var v = msg.spray().getVel().normalize();
                    // pick any old vector to get a vector normal to v with
                    Vec3d k;
                    if (v.x == 0.0 && v.y == 0.0) {
                        // oops, pick a *different* normal
                        k = new Vec3d(1.0, 0.0, 0.0);
                    } else {
                        k = v.crossProduct(new Vec3d(0.0, 0.0, 1.0));
                    }
                    var velUnlen = v.multiply(Math.cos(phi))
                        .add(k.multiply(Math.sin(phi) * Math.cos(theta)))
                        .add(v.crossProduct(k).multiply(Math.sin(phi) * Math.sin(theta)));
                    var vel = velUnlen.multiply(msg.spray().getVel().length() / 20);

                    var color = colProvider.getColor(ClientTickCounter.getTotal(), velUnlen);

                    MinecraftClient.getInstance().world.addParticle(
                        new ConjureParticleOptions(color),
                        pos.x, pos.y, pos.z,
                        vel.x, vel.y, vel.z
                    );
                }
            }
        });
    }
}
