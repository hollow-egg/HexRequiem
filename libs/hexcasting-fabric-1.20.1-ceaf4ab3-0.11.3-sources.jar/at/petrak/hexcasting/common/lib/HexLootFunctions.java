package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.common.loot.AddPerWorldPatternToScrollFunc;
import at.petrak.hexcasting.common.loot.AddHexToAncientCypherFunc;
import at.petrak.hexcasting.common.loot.AmethystReducerFunc;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.loot.function.LootFunctionType;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexLootFunctions {
    public static void registerSerializers(BiConsumer<LootFunctionType, Identifier> r) {
        for (var e : LOOT_FUNCS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<Identifier, LootFunctionType> LOOT_FUNCS = new LinkedHashMap<>();

    public static final LootFunctionType PATTERN_SCROLL = register("pattern_scroll",
        new LootFunctionType(new AddPerWorldPatternToScrollFunc.Serializer()));
    public static final LootFunctionType HEX_CYPHER = register("hex_cypher",
        new LootFunctionType(new AddHexToAncientCypherFunc.Serializer()));
    public static final LootFunctionType AMETHYST_SHARD_REDUCER = register("amethyst_shard_reducer",
        new LootFunctionType(new AmethystReducerFunc.Serializer()));

    private static LootFunctionType register(String id, LootFunctionType lift) {
        var old = LOOT_FUNCS.put(modLoc(id), lift);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return lift;
    }
}
