package at.petrak.hexcasting.api.player;

import net.minecraft.registry.RegistryKey;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * A null sentinel means no sentinel
 */
public record Sentinel(boolean extendsRange, Vec3d position, RegistryKey<World> dimension) {
}
