package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.api.utils.NBTHelper;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.stream.Stream;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import static at.petrak.hexcasting.common.items.storage.ItemFocus.NUM_VARIANTS;

import I;

public class ItemSpellbook extends Item implements IotaHolderItem, VariantItem {
    public static String TAG_SELECTED_PAGE = "page_idx";
    // this is a CompoundTag of string numerical keys to SpellData
    // it is 1-indexed, so that 0/0 can be the special case of "it is empty"
    public static String TAG_PAGES = "pages";

    // this stores the names of pages, to be restored when you scroll
    // it is 1-indexed, and the 0-case for TAG_PAGES will be treated as 1
    public static String TAG_PAGE_NAMES = "page_names";

    // this stores the sealed status of each page, to be restored when you scroll
    // it is 1-indexed, and the 0-case for TAG_PAGES will be treated as 1
    public static String TAG_SEALED = "sealed_pages";

    // this stores which variant of the spellbook should be rendered
    public static final String TAG_VARIANT = "variant";

    public static final int MAX_PAGES = 64;

    public ItemSpellbook(Settings properties) {
        super(properties);
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World level, List<Text> tooltip,
        TooltipContext isAdvanced) {
        boolean sealed = isSealed(stack);
        boolean empty = false;
        if (NBTHelper.hasNumber(stack, TAG_SELECTED_PAGE)) {
            var pageIdx = NBTHelper.getInt(stack, TAG_SELECTED_PAGE);
            int highest = highestPage(stack);
            if (highest != 0) {
                if (sealed) {
                    tooltip.add(Text.translatable("hexcasting.tooltip.spellbook.page.sealed",
                            Text.literal(String.valueOf(pageIdx)).formatted(Formatting.WHITE),
                            Text.literal(String.valueOf(highest)).formatted(Formatting.WHITE),
                            Text.translatable("hexcasting.tooltip.spellbook.sealed").formatted(Formatting.GOLD))
                        .formatted(Formatting.GRAY));
                } else {
                    tooltip.add(Text.translatable("hexcasting.tooltip.spellbook.page",
                            Text.literal(String.valueOf(pageIdx)).formatted(Formatting.WHITE),
                            Text.literal(String.valueOf(highest)).formatted(Formatting.WHITE))
                        .formatted(Formatting.GRAY));
                }
            } else {
                empty = true;
            }
        } else {
            empty = true;
        }

        if (empty) {
            boolean overridden = NBTHelper.hasString(stack, TAG_OVERRIDE_VISUALLY);
            if (sealed) {
                if (overridden) {
                    tooltip.add(Text.translatable("hexcasting.tooltip.spellbook.sealed").formatted(
                        Formatting.GOLD));
                } else {
                    tooltip.add(Text.translatable("hexcasting.tooltip.spellbook.empty.sealed",
                            Text.translatable("hexcasting.tooltip.spellbook.sealed").formatted(Formatting.GOLD))
                        .formatted(Formatting.GRAY));
                }
            } else if (!overridden) {
                tooltip.add(
                    Text.translatable("hexcasting.tooltip.spellbook.empty").formatted(Formatting.GRAY));
            }
        }

        IotaHolderItem.appendHoverText(this, stack, tooltip, isAdvanced);

        super.appendTooltip(stack, level, tooltip, isAdvanced);
    }

    @Override
    public void inventoryTick(ItemStack stack, World pLevel, Entity pEntity, int pSlotId, boolean pIsSelected) {
        int index = getPage(stack, 0);
        NBTHelper.putInt(stack, TAG_SELECTED_PAGE, index);

        int shiftedIdx = Math.max(1, index);
        String nameKey = String.valueOf(shiftedIdx);
        NbtCompound names = NBTHelper.getOrCreateCompound(stack, TAG_PAGE_NAMES);
        if (stack.hasCustomName()) {
            names.putString(nameKey, Text.Serializer.toJson(stack.getName()));
        } else {
            names.remove(nameKey);
        }
    }

    public static boolean arePagesEmpty(ItemStack stack) {
        NbtCompound tag = NBTHelper.getCompound(stack, TAG_PAGES);
        return tag == null || tag.isEmpty();
    }

    @Override
    public @Nullable
    NbtCompound readIotaTag(ItemStack stack) {
        int idx = getPage(stack, 1);
        var key = String.valueOf(idx);
        var tag = NBTHelper.getCompound(stack, TAG_PAGES);
        if (tag != null && tag.contains(key, NbtElement.COMPOUND_TYPE)) {
            return tag.getCompound(key);
        } else {
            return null;
        }
    }

    @Override
    public boolean writeable(ItemStack stack) {
        return !isSealed(stack);
    }

    @Override
    public boolean canWrite(ItemStack stack, Iota datum) {
        return datum == null || !isSealed(stack);
    }

    @Override
    public void writeDatum(ItemStack stack, Iota datum) {
        if (datum != null && isSealed(stack)) {
            return;
        }

        int idx = getPage(stack, 1);
        var key = String.valueOf(idx);
        NbtCompound pages = NBTHelper.getCompound(stack, TAG_PAGES);
        if (pages != null) {
            if (datum == null) {
                pages.remove(key);
                NBTHelper.remove(NBTHelper.getCompound(stack, TAG_SEALED), key);
            } else {
                pages.put(key, IotaType.serialize(datum));
            }

            if (pages.isEmpty()) {
                NBTHelper.remove(stack, TAG_PAGES);
            }
        } else if (datum != null) {
            NBTHelper.getOrCreateCompound(stack, TAG_PAGES).put(key, IotaType.serialize(datum));
        } else {
            NBTHelper.remove(NBTHelper.getCompound(stack, TAG_SEALED), key);
        }
    }

    public static int getPage(ItemStack stack, int ifEmpty) {
        if (arePagesEmpty(stack)) {
            return ifEmpty;
        } else if (NBTHelper.hasNumber(stack, TAG_SELECTED_PAGE)) {
            int index = NBTHelper.getInt(stack, TAG_SELECTED_PAGE);
            if (index == 0) {
                index = 1;
            }
            return index;
        } else {
            return 1;
        }
    }

    public static void setSealed(ItemStack stack, boolean sealed) {
        int index = getPage(stack, 1);

        String nameKey = String.valueOf(index);
        NbtCompound names = NBTHelper.getOrCreateCompound(stack, TAG_SEALED);

        if (!sealed) {
            names.remove(nameKey);
        } else {
            names.putBoolean(nameKey, true);
        }

        if (names.isEmpty()) {
            NBTHelper.remove(stack, TAG_SEALED);
        } else {
            NBTHelper.putCompound(stack, TAG_SEALED, names);
        }

    }

    public static boolean isSealed(ItemStack stack) {
        int index = getPage(stack, 1);

        String nameKey = String.valueOf(index);
        NbtCompound names = NBTHelper.getCompound(stack, TAG_SEALED);
        return NBTHelper.getBoolean(names, nameKey);
    }

    public static int highestPage(ItemStack stack) {
        NbtCompound tag = NBTHelper.getCompound(stack, TAG_PAGES);
        if (tag == null) {
            return 0;
        }
        return tag.getKeys().stream().flatMap(s -> {
            try {
                return Stream.of(Integer.parseInt(s));
            } catch (NumberFormatException e) {
                return Stream.empty();
            }
        }).max(Integer::compare).orElse(0);
    }

    public static int rotatePageIdx(ItemStack stack, boolean increase) {
        int idx = getPage(stack, 0);
        if (idx != 0) {
            idx += increase ? 1 : -1;
            idx = Math.max(1, idx);
        }
        idx = MathHelper.clamp(idx, 0, MAX_PAGES);
        NBTHelper.putInt(stack, TAG_SELECTED_PAGE, idx);

        NbtCompound names = NBTHelper.getCompound(stack, TAG_PAGE_NAMES);
        int shiftedIdx = Math.max(1, idx);
        String nameKey = String.valueOf(shiftedIdx);
        String name = NBTHelper.getString(names, nameKey);
        if (name != null) {
            stack.setCustomName(Text.Serializer.fromJson(name));
        } else {
            stack.removeCustomName();
        }

        return idx;
    }

    @Override
    public int numVariants() {
        return NUM_VARIANTS;
    }

    @Override
    public void setVariant(ItemStack stack, int variant) {
        if (!isSealed(stack))
            NBTHelper.putInt(stack, TAG_VARIANT, clampVariant(variant));
    }
}
