package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import I;
import Z;

// https://github.com/VazkiiMods/Botania/blob/1.18.x/Xplat/src/main/java/vazkii/botania/network/clientbound/PacketSpawnDoppleganger.java
public record MsgNewWallScrollS2C(EntitySpawnS2CPacket inner, BlockPos pos, Direction dir, ItemStack scrollItem,
                                  boolean showsStrokeOrder, int blockSize) implements IMessage {
    public static final Identifier ID = modLoc("wallscr");

    @Override
    public Identifier getFabricId() {
        return ID;
    }

    @Override
    public void serialize(PacketByteBuf buf) {
        inner.write(buf);
        buf.writeBlockPos(pos);
        buf.writeByte(dir.ordinal());
        buf.writeItemStack(scrollItem);
        buf.writeBoolean(showsStrokeOrder);
        buf.writeVarInt(blockSize);
    }

    public static MsgNewWallScrollS2C deserialize(PacketByteBuf buf) {
        var inner = new EntitySpawnS2CPacket(buf);
        var pos = buf.readBlockPos();
        var dir = HexUtils.getSafe(Direction.values(), buf.readByte());
        var scroll = buf.readItemStack();
        var strokeOrder = buf.readBoolean();
        var blockSize = buf.readVarInt();
        return new MsgNewWallScrollS2C(inner, pos, dir, scroll, strokeOrder, blockSize);
    }

    public static void handle(MsgNewWallScrollS2C self) {
        MinecraftClient.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                var player = MinecraftClient.getInstance().player;
                if (player != null) {
                    player.networkHandler.onEntitySpawn(self.inner);
                    var e = player.getWorld().getEntityById(self.inner.getId());
                    if (e instanceof EntityWallScroll scroll) {
                        scroll.readSpawnData(self.pos, self.dir, self.scrollItem, self.showsStrokeOrder,
                            self.blockSize);
                    }
                }
            }
        });
    }
}
