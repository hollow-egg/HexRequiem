package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import net.minecraft.nbt.NbtByte;
import net.minecraft.nbt.NbtElement;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BooleanIota extends Iota {
    public BooleanIota(boolean d) {
        super(HexIotaTypes.BOOLEAN, d);
    }

    public boolean getBool() {
        return (boolean) this.payload;
    }

    @Override
    public boolean isTruthy() {
        return this.getBool();
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof BooleanIota b
            && this.getBool() == b.getBool();
    }

    @Override
    public @NotNull NbtElement serialize() {
        // there is no boolean tag :(
        return NbtByte.of(this.getBool());
    }

    public static IotaType<BooleanIota> TYPE = new IotaType<>() {
        @Nullable
        @Override
        public BooleanIota deserialize(NbtElement tag, ServerWorld world) throws IllegalArgumentException {
            return BooleanIota.deserialize(tag);
        }

        @Override
        public Text display(NbtElement tag) {
            return BooleanIota.display(BooleanIota.deserialize(tag).getBool());
        }

        @Override
        public int color() {
            // We can't set red or green ... so do yellow, I guess
            return 0xff_ffff55;
        }
    };

    public static BooleanIota deserialize(NbtElement tag) throws IllegalArgumentException {
        var dtag = HexUtils.downcast(tag, NbtByte.TYPE);
        return new BooleanIota(dtag.byteValue() != 0);
    }

    public static Text display(boolean b) {
        return Text.translatable(b ? "hexcasting.tooltip.boolean_true" : "hexcasting.tooltip.boolean_false")
            .formatted(b ? Formatting.DARK_GREEN : Formatting.DARK_RED);
    }
}
