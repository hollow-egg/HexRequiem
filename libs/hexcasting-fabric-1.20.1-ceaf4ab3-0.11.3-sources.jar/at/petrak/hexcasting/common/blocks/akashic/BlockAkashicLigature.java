package at.petrak.hexcasting.common.blocks.akashic;

import net.minecraft.block.Block;

public class BlockAkashicLigature extends Block implements AkashicFloodfiller {
    public BlockAkashicLigature(Settings properties) {
        super(properties);
    }
}
