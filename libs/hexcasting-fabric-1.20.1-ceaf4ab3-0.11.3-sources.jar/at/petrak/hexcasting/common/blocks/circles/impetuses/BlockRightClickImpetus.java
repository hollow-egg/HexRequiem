package at.petrak.hexcasting.common.blocks.circles.impetuses;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class BlockRightClickImpetus extends BlockAbstractImpetus {
    public BlockRightClickImpetus(Settings p_49795_) {
        super(p_49795_);
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pPos, BlockState pState) {
        return new BlockEntityRightClickImpetus(pPos, pState);
    }

    @Override
    public ActionResult onUse(BlockState pState, World pLevel, BlockPos pPos, PlayerEntity pPlayer, Hand pHand,
        BlockHitResult pHit) {
        if (!pPlayer.isSneaking()) {
            var tile = pLevel.getBlockEntity(pPos);
            if (tile instanceof BlockEntityRightClickImpetus impetus) {
                if (pPlayer instanceof ServerPlayerEntity serverPlayer) {
//                    impetus.activateSpellCircle(serverPlayer);
                    impetus.startExecution(serverPlayer);
                }
                return ActionResult.SUCCESS;
            }
        }
        return ActionResult.PASS;
    }
}
