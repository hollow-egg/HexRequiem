package at.petrak.hexcasting.xplat;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADHexHolder;
import at.petrak.hexcasting.api.addldata.ADIotaHolder;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.addldata.ADVariantItem;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.eval.sideeffects.EvalSound;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.eval.vm.ContinuationFrame;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.AltioraAbility;
import at.petrak.hexcasting.api.player.FlightAbility;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.common.msgs.IMessage;
import at.petrak.hexcasting.interop.pehkui.PehkuiInterop;
import com.mojang.authlib.GameProfile;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.ServiceLoader;
import java.util.ServiceLoader.Provider;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * more like IHexplatAbstracts lmaooooooo
 */
public interface IXplatAbstractions {
    Platform platform();

    boolean isModPresent(String id);

    boolean isPhysicalClient();

    void initPlatformSpecific();

    void sendPacketToPlayer(ServerPlayerEntity target, IMessage packet);

    void sendPacketNear(Vec3d pos, double radius, ServerWorld dimension, IMessage packet);

    void sendPacketTracking(Entity entity, IMessage packet);

    // https://github.com/VazkiiMods/Botania/blob/13b7bcd9cbb6b1a418b0afe455662d29b46f1a7f/Xplat/src/main/java/vazkii/botania/xplat/IXplatAbstractions.java#L157
    Packet<ClientPlayPacketListener> toVanillaClientboundPacket(IMessage message);

//    double getReachDistance(Player player);

    // Things that used to be caps

    /**
     * Doesn't actually knock out its AI or anything anymore, just sets caps/ccs
     */
    // heheheheh addled data
    void setBrainsweepAddlData(MobEntity mob);

    boolean isBrainswept(MobEntity mob);

    @Nullable FrozenPigment setPigment(PlayerEntity target, @Nullable FrozenPigment colorizer);

    void setSentinel(PlayerEntity target, @Nullable Sentinel sentinel);

    void setFlight(ServerPlayerEntity target, @Nullable FlightAbility flight);

    void setAltiora(PlayerEntity target, @Nullable AltioraAbility altiora);

    void setStaffcastImage(ServerPlayerEntity target, @Nullable CastingImage image);

    void setPatterns(ServerPlayerEntity target, List<ResolvedPattern> patterns);

    @Nullable FlightAbility getFlight(ServerPlayerEntity player);

    @Nullable AltioraAbility getAltiora(PlayerEntity player);

    FrozenPigment getPigment(PlayerEntity player);

    @Nullable Sentinel getSentinel(PlayerEntity player);

    CastingVM getStaffcastVM(ServerPlayerEntity player, Hand hand);

    List<ResolvedPattern> getPatternsSavedInUi(ServerPlayerEntity player);

    void clearCastingData(ServerPlayerEntity player);

    @Nullable
    ADMediaHolder findMediaHolder(ItemStack stack);

    @Nullable
    ADMediaHolder findMediaHolder(ServerPlayerEntity player);

    @Nullable
    ADIotaHolder findDataHolder(ItemStack stack);

    @Nullable
    ADIotaHolder findDataHolder(Entity entity);

    @Nullable
    ADHexHolder findHexHolder(ItemStack stack);

    @Nullable ADVariantItem findVariantHolder(ItemStack stack);

    // coooollooorrrs

    boolean isPigment(ItemStack stack);

    ColorProvider getColorProvider(FrozenPigment pigment);

    // Items

    /**
     * No-op on forge (use a SoftImplement)
     */
    Item.Settings addEquipSlotFabric(EquipmentSlot slot);

    // Blocks

    <T extends BlockEntity> BlockEntityType<T> createBlockEntityType(BiFunction<BlockPos, BlockState, T> func,
        Block... blocks);

    boolean tryPlaceFluid(World level, Hand hand, BlockPos pos, Fluid fluid);

    boolean drainAllFluid(World level, BlockPos pos);

    // misc

    boolean isCorrectTierForDrops(ToolMaterial tier, BlockState bs);

    Ingredient getUnsealedIngredient(ItemStack stack);

    IXplatTags tags();

    LootCondition.Builder isShearsCondition();

    String getModName(String namespace);

    /**
     * Registry for actions.
     * <p>
     * There's some internal caching (so we can directly look up signatures in a map, for example)
     * but this registry is the source of truth.
     */
    Registry<ActionRegistryEntry> getActionRegistry();

    Registry<SpecialHandler.Factory<?>> getSpecialHandlerRegistry();

    Registry<IotaType<?>> getIotaTypeRegistry();

    Registry<Arithmetic> getArithmeticRegistry();
    Registry<ContinuationFrame.Type<?>> getContinuationTypeRegistry();

    Registry<EvalSound> getEvalSoundRegistry();

    GameProfile HEXCASTING = new GameProfile(UUID.fromString("8BE7E9DA-1667-11EE-BE56-0242AC120002"), "[HexCasting]");

    boolean isBreakingAllowed(ServerWorld world, BlockPos pos, BlockState state, @Nullable PlayerEntity player);

    boolean isPlacingAllowed(ServerWorld world, BlockPos pos, ItemStack blockStack, @Nullable PlayerEntity player);

    // interop

    PehkuiInterop.ApiAbstraction getPehkuiApi();

    ///

    IXplatAbstractions INSTANCE = find();

    private static IXplatAbstractions find() {
        var providers = ServiceLoader.load(IXplatAbstractions.class).stream().toList();
        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.get(0);
            HexAPI.LOGGER.debug("Instantiating xplat impl: " + provider.type().getName());
            return provider.get();
        }
    }

}
