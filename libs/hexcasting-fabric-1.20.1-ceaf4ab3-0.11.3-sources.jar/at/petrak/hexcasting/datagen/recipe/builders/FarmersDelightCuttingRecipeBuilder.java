package at.petrak.hexcasting.datagen.recipe.builders;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.advancement.criterion.CriterionConditions;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class FarmersDelightCuttingRecipeBuilder implements CraftingRecipeJsonBuilder {
    private String group = "";
    private final List<ProcessingOutput> outputs = Lists.newArrayList();
    private Ingredient input;
    private FarmersDelightToolIngredient toolAction;
    private SoundEvent sound;

    @Override
    public FarmersDelightCuttingRecipeBuilder criterion(String s, CriterionConditions criterionTriggerInstance) {
        return this;
    }

    @Override
    public @NotNull FarmersDelightCuttingRecipeBuilder group(@Nullable String name) {
        group = name;
        return this;
    }

    @Override
    public Item getOutputItem() {
        return Items.AIR; // Irrelevant, we implement serialization ourselves
    }

    public FarmersDelightCuttingRecipeBuilder withInput(ItemConvertible item) {
        return withInput(Ingredient.ofItems(item));
    }

    public FarmersDelightCuttingRecipeBuilder withInput(ItemStack stack) {
        return withInput(Ingredient.ofStacks(stack));
    }

    public FarmersDelightCuttingRecipeBuilder withInput(Ingredient ingredient) {
        this.input = ingredient;
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(ItemConvertible output) {
        return withOutput(1f, output, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, ItemConvertible output) {
        return withOutput(chance, output, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(ItemConvertible output, int count) {
        return withOutput(1f, output, count);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, ItemConvertible output, int count) {
        return withOutput(new ItemStack(output, count), chance);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(ItemStack output, float chance) {
        this.outputs.add(new ItemProcessingOutput(output, chance));
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(String name) {
        return withOutput(1f, name, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(String name, int count) {
        return withOutput(1f, name, count);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, String name) {
        return withOutput(chance, name, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, String name, int count) {
        this.outputs.add(new CompatProcessingOutput(name, count, chance));
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withTool(FarmersDelightToolIngredient ingredient) {
        this.toolAction = ingredient;
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withSound(SoundEvent sound) {
        this.sound = sound;
        return this;
    }

    @Override
    public void offerTo(Consumer<RecipeJsonProvider> consumer, Identifier resourceLocation) {
        consumer.accept(new CuttingRecipe(resourceLocation));
    }

    public class CuttingRecipe implements RecipeJsonProvider {

        private final Identifier id;

        public CuttingRecipe(Identifier id) {
            this.id = id;
        }

        @Override
        public void serialize(@NotNull JsonObject json) {
            json.addProperty("type", "farmersdelight:cutting");

            if (!group.isEmpty()) {
                json.addProperty("group", group);
            }

            JsonArray jsonIngredients = new JsonArray();
            JsonArray jsonOutputs = new JsonArray();

            jsonIngredients.add(input.toJson());

            outputs.forEach(o -> jsonOutputs.add(o.serialize()));

            json.add("ingredients", jsonIngredients);
            json.add("tool", toolAction.serialize());
            json.add("result", jsonOutputs);

            if (sound != null) {
                json.addProperty("sound", Registries.SOUND_EVENT.getId(sound).toString());
            }
        }

        @Override
        public @NotNull Identifier getRecipeId() {
            return id;
        }

        @Override
        public @NotNull RecipeSerializer<?> getSerializer() {
            return RecipeSerializer.SHAPELESS; // Irrelevant, we implement serialization ourselves
        }

        @Override
        public JsonObject toAdvancementJson() {
            return null;
        }

        @Override
        public Identifier getAdvancementId() {
            return null;
        }
    }
}
