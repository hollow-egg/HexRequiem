package at.petrak.hexcasting.api.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

public class DiscoveryHandlers {
    private static final List<BiFunction<PlayerEntity, String, ItemStack>> DEBUG_DISCOVERER = new ArrayList<>();

    public static ItemStack findDebugItem(PlayerEntity player, String type) {
        for (var discoverer : DEBUG_DISCOVERER) {
            var stack = discoverer.apply(player, type);
            if (!stack.isEmpty()) {
                return stack;
            }
        }
        return ItemStack.EMPTY;
    }

    public static void addDebugItemDiscoverer(BiFunction<PlayerEntity, String, ItemStack> discoverer) {
        DEBUG_DISCOVERER.add(discoverer);
    }
}
