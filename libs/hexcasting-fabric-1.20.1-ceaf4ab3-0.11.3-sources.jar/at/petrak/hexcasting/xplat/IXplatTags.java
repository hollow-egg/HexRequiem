package at.petrak.hexcasting.xplat;

import net.minecraft.item.Item;
import net.minecraft.registry.tag.TagKey;

// https://fabricmc.net/wiki/tutorial:tags#existing_common_tags
public interface IXplatTags {
    TagKey<Item> amethystDust();

    TagKey<Item> gems();
}
