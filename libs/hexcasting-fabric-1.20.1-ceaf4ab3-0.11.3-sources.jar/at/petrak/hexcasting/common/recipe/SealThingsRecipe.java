package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.items.storage.ItemFocus;
import at.petrak.hexcasting.common.items.storage.ItemSpellbook;
import at.petrak.hexcasting.common.lib.HexItems;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.SpecialCraftingRecipe;
import net.minecraft.recipe.SpecialRecipeSerializer;
import net.minecraft.recipe.book.CraftingRecipeCategory;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.world.World;

public class SealThingsRecipe extends SpecialCraftingRecipe {
    public final Sealee sealee;

    public static final SpecialRecipeSerializer<SealThingsRecipe> FOCUS_SERIALIZER =
        new SpecialRecipeSerializer<>(SealThingsRecipe::focus);
    public static final SpecialRecipeSerializer<SealThingsRecipe> SPELLBOOK_SERIALIZER =
        new SpecialRecipeSerializer<>(SealThingsRecipe::spellbook);

    public SealThingsRecipe(Identifier id, CraftingRecipeCategory category, Sealee sealee) {
        super(id, category);
        this.sealee = sealee;
    }


    @Override
    public boolean fits(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public boolean matches(RecipeInputInventory container, World level) {
        boolean foundComb = false;
        boolean foundSealee = false;

        for (int i = 0; i < container.size(); i++) {
            var stack = container.getStack(i);
            if (this.sealee.isCorrectSealee(stack)) {
                if (foundSealee) return false;
                foundSealee = true;
            } else if (stack.isIn(HexTags.Items.SEAL_MATERIALS)) {
                if (foundComb) return false;
                foundComb = true;
            }
        }

        return foundComb && foundSealee;
    }

    @Override
    public ItemStack assemble(RecipeInputInventory inv, DynamicRegistryManager registryAccess) {
        ItemStack sealee = ItemStack.EMPTY;

        for (int i = 0; i < inv.size(); i++) {
            var stack = inv.getStack(i);
            if (this.sealee.isCorrectSealee(stack)) {
                sealee = stack.copy();
                break;
            }
        }

        if (!sealee.isEmpty()) {
            this.sealee.seal(sealee);
            sealee.setCount(1);
        }

        return sealee;
    }

    @Override
    public @NotNull RecipeSerializer<?> getSerializer() {
        return switch (this.sealee) {
            case FOCUS -> FOCUS_SERIALIZER;
            case SPELLBOOK -> SPELLBOOK_SERIALIZER;
        };
    }

    public static SealThingsRecipe focus(Identifier id, CraftingRecipeCategory category) {
        return new SealThingsRecipe(id, category, Sealee.FOCUS);
    }

    public static SealThingsRecipe spellbook(Identifier id, CraftingRecipeCategory category) {
        return new SealThingsRecipe(id, category, Sealee.SPELLBOOK);
    }

    public enum Sealee implements StringIdentifiable {
        FOCUS,
        SPELLBOOK;

        @Override
        public String asString() {
            return this.name().toLowerCase(Locale.ROOT);
        }

        public boolean isCorrectSealee(ItemStack stack) {
            return switch (this) {
                case FOCUS -> stack.isOf(HexItems.FOCUS)
                    && HexItems.FOCUS.readIotaTag(stack) != null
                    && !ItemFocus.isSealed(stack);
                case SPELLBOOK -> stack.isOf(HexItems.SPELLBOOK)
                    && HexItems.SPELLBOOK.readIotaTag(stack) != null
                    && !ItemSpellbook.isSealed(stack);
            };
        }

        public void seal(ItemStack stack) {
            switch (this) {
                case FOCUS -> {
                    ItemFocus.seal(stack);
                }
                case SPELLBOOK -> {
                    ItemSpellbook.setSealed(stack, true);
                }
            }
        }
    }
}

