package at.petrak.hexcasting.common.recipe;

import I;
import J;
import at.petrak.hexcasting.common.recipe.ingredient.StateIngredient;
import at.petrak.hexcasting.common.recipe.ingredient.StateIngredientHelper;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredient;
import com.google.gson.JsonObject;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.RecipeType;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.world.World;
import org.jetbrains.annotations.NotNull;

// God I am a horrible person
public record BrainsweepRecipe(
	Identifier id,
	StateIngredient blockIn,
	BrainsweepeeIngredient entityIn,
	long mediaCost,
	BlockState result
) implements Recipe<Inventory> {
	public boolean matches(BlockState blockIn, Entity victim, ServerWorld level) {
		return this.blockIn.test(blockIn) && this.entityIn.test(victim, level);
	}

	@Override
	public Identifier getId() {
		return id;
	}

	@Override
	public RecipeType<?> getType() {
		return HexRecipeStuffRegistry.BRAINSWEEP_TYPE;
	}

	@Override
	public RecipeSerializer<?> getSerializer() {
		return HexRecipeStuffRegistry.BRAINSWEEP;
	}

	// in order to get this to be a "Recipe" we need to do a lot of bending-over-backwards
	// to get the implementation to be satisfied even though we never use it
	@Override
	public boolean matches(Inventory pContainer, World pLevel) {
		return false;
	}

	@Override
	public ItemStack craft(Inventory pContainer, DynamicRegistryManager access) {
		return ItemStack.EMPTY;
	}

	@Override
	public boolean fits(int pWidth, int pHeight) {
		return false;
	}

	@Override
	public ItemStack getOutput(DynamicRegistryManager registryAccess) {
		return ItemStack.EMPTY.copy();
	}

	// Because kotlin doesn't like doing raw, unchecked types
	// Can't blame it, but that's what we need to do
	@SuppressWarnings({"rawtypes", "unchecked"})
	public static BlockState copyProperties(BlockState original, BlockState copyTo) {
		for (Property prop : original.getProperties()) {
			if (copyTo.contains(prop)) {
				copyTo = copyTo.with(prop, original.get(prop));
			}
		}

		return copyTo;
	}

	public static class Serializer extends RecipeSerializerBase<BrainsweepRecipe> {
		@Override
		public @NotNull BrainsweepRecipe read(Identifier recipeID, JsonObject json) {
			var blockIn = StateIngredientHelper.deserialize(JsonHelper.getObject(json, "blockIn"));
			var villagerIn = BrainsweepeeIngredient.deserialize(JsonHelper.getObject(json, "entityIn"));
			var cost = JsonHelper.getInt(json, "cost");
			var result = StateIngredientHelper.readBlockState(JsonHelper.getObject(json, "result"));
			return new BrainsweepRecipe(recipeID, blockIn, villagerIn, cost, result);
		}

		@Override
		public void toNetwork(PacketByteBuf buf, BrainsweepRecipe recipe) {
			recipe.blockIn.write(buf);
			recipe.entityIn.wrapWrite(buf);
			buf.writeVarLong(recipe.mediaCost);
			buf.writeVarInt(Block.getRawIdFromState(recipe.result));
		}

		@Override
		public @NotNull BrainsweepRecipe read(Identifier recipeID, PacketByteBuf buf) {
			var blockIn = StateIngredientHelper.read(buf);
			var brainsweepeeIn = BrainsweepeeIngredient.read(buf);
			var cost = buf.readVarLong();
			var result = Block.getStateFromRawId(buf.readVarInt());
			return new BrainsweepRecipe(recipeID, blockIn, brainsweepeeIn, cost, result);
		}
	}
}
