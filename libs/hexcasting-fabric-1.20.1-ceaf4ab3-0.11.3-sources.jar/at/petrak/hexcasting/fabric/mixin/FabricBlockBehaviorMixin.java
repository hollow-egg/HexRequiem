package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.common.items.ItemJewelerHammer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractBlock.class)
public class FabricBlockBehaviorMixin {
    @Inject(method = "getDestroyProgress", at = @At("HEAD"), cancellable = true)
    private void destroyProgress(BlockState blockState, PlayerEntity player, BlockView blockGetter, BlockPos blockPos,
        CallbackInfoReturnable<Float> cir) {
        if (ItemJewelerHammer.shouldFailToBreak(player, blockState, blockPos)) {
            cir.setReturnValue(0F);
        }
    }
}
