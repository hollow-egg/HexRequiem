package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.api.item.MediaHolderItem;
import at.petrak.hexcasting.api.misc.DiscoveryHandlers;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.common.items.ItemLoreFragment;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import net.minecraft.advancement.Advancement;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Language;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemCreativeUnlocker extends Item implements MediaHolderItem {

    public static final String DISPLAY_MEDIA = "media";
    public static final String DISPLAY_PATTERNS = "patterns";

    static {
        DiscoveryHandlers.addDebugItemDiscoverer((player, type) -> {
            for (ItemStack item : player.getInventory().main) {
                if (isDebug(item, type)) {
                    return item;
                }
            }

            // Technically possible with commands!
            for (ItemStack item : player.getInventory().armor) {
                if (isDebug(item, type)) {
                    return item;
                }
            }

            for (ItemStack item : player.getInventory().offHand) {
                if (isDebug(item, type)) {
                    return item;
                }
            }
            return ItemStack.EMPTY;
        });
    }

    public static boolean isDebug(ItemStack stack) {
        return isDebug(stack, null);
    }

    public static boolean isDebug(ItemStack stack, String flag) {
        if (!stack.isOf(HexItems.CREATIVE_UNLOCKER) || !stack.hasCustomName()) {
            return false;
        }
        var keywords = Arrays.asList(stack.getName().getString().toLowerCase(Locale.ROOT).split(" "));
        if (!keywords.contains("debug")) {
            return false;
        }
        return flag == null || keywords.contains(flag);
    }

    public static Text infiniteMedia(World level) {
        String prefix = "item.hexcasting.creative_unlocker.";

        String emphasis = Language.getInstance().get(prefix + "for_emphasis");
        MutableText emphasized = Text.empty();
        for (int i = 0; i < emphasis.length(); i++) {
            emphasized.append(rainbow(Text.literal("" + emphasis.charAt(i)), i, level));
        }

        return emphasized;
    }

    public static final String TAG_EXTRACTIONS = "extractions";
    public static final String TAG_INSERTIONS = "insertions";

    public ItemCreativeUnlocker(Settings properties) {
        super(properties);
    }

    @Override
    public long getMedia(ItemStack stack) {
        return Long.MAX_VALUE;
    }

    @Override
    public long getMaxMedia(ItemStack stack) {
        return Long.MAX_VALUE;
    }

    @Override
    public void setMedia(ItemStack stack, long media) {
        // NO-OP
    }

    @Override
    public boolean canProvideMedia(ItemStack stack) {
        return true;
    }

    @Override
    public boolean canRecharge(ItemStack stack) {
        return true;
    }

    public static void addToIntArray(ItemStack stack, String tag, int n) {
        int[] arr = NBTHelper.getIntArray(stack, tag);
        if (arr == null) {
            arr = new int[0];
        }
        int[] newArr = Arrays.copyOf(arr, arr.length + 1);
        newArr[newArr.length - 1] = n;
        NBTHelper.putIntArray(stack, tag, newArr);
    }

    public static void addToLongArray(ItemStack stack, String tag, long n) {
        long[] arr = NBTHelper.getLongArray(stack, tag);
        if (arr == null) {
            arr = new long[0];
        }
        long[] newArr = Arrays.copyOf(arr, arr.length + 1);
        newArr[newArr.length - 1] = n;
        NBTHelper.putLongArray(stack, tag, newArr);
    }

    @Override
    public long withdrawMedia(ItemStack stack, long cost, boolean simulate) {
        // In case it's withdrawn through other means
        if (!simulate && isDebug(stack, DISPLAY_MEDIA)) {
            addToLongArray(stack, TAG_EXTRACTIONS, cost);
        }

        return cost < 0 ? getMedia(stack) : cost;
    }

    @Override
    public long insertMedia(ItemStack stack, long amount, boolean simulate) {
        // In case it's inserted through other means
        if (!simulate && isDebug(stack, DISPLAY_MEDIA)) {
            addToLongArray(stack, TAG_INSERTIONS, amount);
        }

        return amount < 0 ? getMaxMedia(stack) : amount;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return super.hasGlint(stack) || isDebug(stack);
    }

    @Override
    public void inventoryTick(ItemStack stack, World level, Entity entity, int slot, boolean selected) {
        if (isDebug(stack, DISPLAY_MEDIA) && !level.isClient) {
            debugDisplay(stack, TAG_EXTRACTIONS, "withdrawn", "all_media", entity);
            debugDisplay(stack, TAG_INSERTIONS, "inserted", "infinite_media", entity);
        }
    }

    private void debugDisplay(ItemStack stack, String tag, String langKey, String allKey, Entity entity) {
        long[] arr = NBTHelper.getLongArray(stack, tag);
        if (arr != null) {
            NBTHelper.remove(stack, tag);
            for (long i : arr) {
                if (i < 0) {
                    entity.sendMessage(Text.translatable("hexcasting.debug.media_" + langKey,
                            stack.toHoverableText(),
                            Text.translatable("hexcasting.debug." + allKey).formatted(Formatting.GRAY))
                        .formatted(Formatting.LIGHT_PURPLE));
                } else {
                    entity.sendMessage(Text.translatable("hexcasting.debug.media_" + langKey + ".with_dust",
                            stack.toHoverableText(),
                            Text.literal("" + i).formatted(Formatting.WHITE),
                            Text.literal(String.format("%.2f", i * 1.0 / MediaConstants.DUST_UNIT)).formatted(
                                Formatting.WHITE))
                        .formatted(Formatting.LIGHT_PURPLE));
                }
            }
        }
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        BlockEntity be = context.getWorld().getBlockEntity(context.getBlockPos());
        if (be instanceof BlockEntityAbstractImpetus impetus) {
            impetus.setInfiniteMedia();
            context.getWorld().playSound(null, context.getBlockPos(), HexSounds.SPELL_CIRCLE_FIND_BLOCK,
                SoundCategory.PLAYERS, 1f, 1f);
            return ActionResult.success(context.getWorld().isClient());
        }
        return ActionResult.PASS;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World level, LivingEntity consumer) {
        if (level instanceof ServerWorld slevel && consumer instanceof ServerPlayerEntity player) {
            var names = new ArrayList<>(ItemLoreFragment.NAMES);
            names.add(0, modLoc("root"));
            for (var name : names) {
                var rootAdv = slevel.getServer().getAdvancementLoader().get(name);
                if (rootAdv != null) {
                    var children = new ArrayList<Advancement>();
                    children.add(rootAdv);
                    addChildren(rootAdv, children);

                    var adman = player.getAdvancementTracker();

                    for (var kid : children) {
                        var progress = adman.getProgress(kid);
                        if (!progress.isDone()) {
                            for (String crit : progress.getUnobtainedCriteria()) {
                                adman.grantCriterion(kid, crit);
                            }
                        }
                    }
                }
            }
        }

        ItemStack copy = stack.copy();
        super.finishUsing(stack, level, consumer);
        return copy;
    }

    private static MutableText rainbow(MutableText component, int shift, World level) {
        if (level == null) {
            return component.formatted(Formatting.WHITE);
        }

        return component.styled((s) -> s.withColor(
            TextColor.fromRgb(MathHelper.hsvToRgb((level.getTime() + shift) * 2 % 360 / 360F, 1F, 1F))));
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World level, List<Text> tooltipComponents,
        TooltipContext isAdvanced) {
        Text emphasized = infiniteMedia(level);

        MutableText modName = Text.translatable("item.hexcasting.creative_unlocker.mod_name").styled(
            (s) -> s.withColor(ItemMediaHolder.HEX_COLOR));

        tooltipComponents.add(
            Text.translatable("hexcasting.spelldata.onitem", emphasized).formatted(Formatting.GRAY));
        tooltipComponents.add(Text.translatable("item.hexcasting.creative_unlocker.tooltip", modName).formatted(Formatting.GRAY));
    }

    private static void addChildren(Advancement root, List<Advancement> out) {
        for (Advancement kiddo : root.getChildren()) {
            out.add(kiddo);
            addChildren(kiddo, out);
        }
    }
}
