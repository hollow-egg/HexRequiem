package at.petrak.hexcasting.common.loot;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.api.utils.NBTHelper;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.items.storage.ItemScroll;
import at.petrak.hexcasting.common.lib.HexLootFunctions;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.ArrayList;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.context.LootContext;
import net.minecraft.loot.function.ConditionalLootFunction;
import net.minecraft.loot.function.LootFunctionType;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.random.Random;

/**
 * Slap a random per-world pattern on the scroll.
 * <p>
 * The function itself is only used on Fabric but the behavior {@link AddPerWorldPatternToScrollFunc#doStatic}
 * is used on both sides
 */
public class AddPerWorldPatternToScrollFunc extends ConditionalLootFunction {
    public AddPerWorldPatternToScrollFunc(LootCondition[] lootItemConditions) {
        super(lootItemConditions);
    }

    /**
     * This doesn't actually have any params so extract behaviour out for the benefit of forge
     */
    public static ItemStack doStatic(ItemStack stack, Random rand, ServerWorld overworld) {
        var perWorldKeys = new ArrayList<RegistryKey<ActionRegistryEntry>>();
        Registry<ActionRegistryEntry> regi = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : regi.getKeys()) {
            if (HexUtils.isOfTag(regi, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                perWorldKeys.add(key);
            }
        }
        var patternKey = perWorldKeys.get(rand.nextInt(perWorldKeys.size()));
        var pat = PatternRegistryManifest.getCanonicalStrokesPerWorld(patternKey, overworld);
        NBTHelper.putString(stack, ItemScroll.TAG_OP_ID, patternKey.getValue().toString());
        NBTHelper.put(stack, ItemScroll.TAG_PATTERN, pat.serializeToNBT());
        return stack;
    }

    @Override
    protected ItemStack process(ItemStack stack, LootContext ctx) {
        return doStatic(stack, ctx.getRandom(), ctx.getWorld().getServer().getOverworld());
    }

    @Override
    public LootFunctionType getType() {
        return HexLootFunctions.PATTERN_SCROLL;
    }

    public static class Serializer extends ConditionalLootFunction.Serializer<AddPerWorldPatternToScrollFunc> {
        @Override
        public void serialize(JsonObject json, AddPerWorldPatternToScrollFunc value, JsonSerializationContext ctx) {
            super.toJson(json, value, ctx);
        }

        @Override
        public AddPerWorldPatternToScrollFunc fromJson(JsonObject object, JsonDeserializationContext ctx,
            LootCondition[] conditions) {
            return new AddPerWorldPatternToScrollFunc(conditions);
        }
    }
}
