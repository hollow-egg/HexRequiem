package at.petrak.hexcasting.common.blocks.circles.impetuses;

import F;
import I;
import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import at.petrak.hexcasting.common.lib.HexSounds;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public class BlockEntityLookingImpetus extends BlockEntityAbstractImpetus {
    public static final int MAX_LOOK_AMOUNT = 30;
    public static final String TAG_LOOK_AMOUNT = "look_amount";

    private int lookAmount = 0;

    public BlockEntityLookingImpetus(BlockPos pWorldPosition, BlockState pBlockState) {
        super(HexBlockEntities.IMPETUS_LOOK_TILE, pWorldPosition, pBlockState);
    }

    // https://github.com/VazkiiMods/Botania/blob/2607bcd31c4eaeb617f7d1b3ec1c1db08f59add4/Common/src/main/java/vazkii/botania/common/block/tile/TileEnderEye.java#L27
    public static void serverTick(World level, BlockPos pos, BlockState bs, BlockEntityLookingImpetus self) {
        if (bs.get(BlockCircleComponent.ENERGIZED)) {
            return;
        }

        int prevLookAmt = self.lookAmount;
        int range = 20;
        var players = level.getNonSpectatingEntities(ServerPlayerEntity.class,
            new Box(pos.add(-range, -range, -range), pos.add(range, range, range)));

        ServerPlayerEntity looker = null;
        for (var player : players) {
            // might as well impl this heh
            var hat = player.getEquippedStack(EquipmentSlot.HEAD);
            // sadly `isEnderMask` requires the enderman
            if (!hat.isEmpty() && hat.isOf(Blocks.CARVED_PUMPKIN.asItem())) {
                continue;
            }

            var lookEnd = player.getRotationVector().multiply(range / 1.5f); // add some slop
            var hit = level.raycast(new RaycastContext(
                player.getEyePos(),
                player.getEyePos().add(lookEnd),
                RaycastContext.ShapeType.VISUAL,
                RaycastContext.FluidHandling.NONE,
                player
            ));
            if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos)) {
                looker = player;
                break;
            }
        }

        var newLook = MathHelper.clamp(
            prevLookAmt + (looker == null ? -1 : 1),
            0,
            MAX_LOOK_AMOUNT
        );
        if (newLook != prevLookAmt) {
            if (newLook == MAX_LOOK_AMOUNT) {
                self.lookAmount = 0;
                self.startExecution(looker);
            } else {
                if (newLook % 5 == 1) {
                    var t = (float) newLook / MAX_LOOK_AMOUNT;
                    var pitch = MathHelper.lerp(t, 0.5f, 1.2f);
                    var volume = MathHelper.lerp(t, 0.2f, 1.2f);
                    level.playSound(null, pos, HexSounds.IMPETUS_LOOK_TICK, SoundCategory.BLOCKS, volume, pitch);
                }
                self.lookAmount = newLook;
                self.markDirty();
            }
        }
    }

    @Override
    protected void saveModData(NbtCompound tag) {
        super.saveModData(tag);
        tag.putInt(TAG_LOOK_AMOUNT, this.lookAmount);
    }

    @Override
    protected void loadModData(NbtCompound tag) {
        super.loadModData(tag);
        this.lookAmount = tag.getInt(TAG_LOOK_AMOUNT);
    }
}
