package at.petrak.hexcasting.fabric.interop.emi;

import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredient;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.emi.emi.api.stack.EmiStack;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;
import static at.petrak.hexcasting.client.render.RenderLib.renderEntity;

public class BrainsweepeeEmiStack extends EmiStack {
    public final BrainsweepeeIngredient ingredient;
    private final Identifier id;

    public BrainsweepeeEmiStack(BrainsweepeeIngredient ingr) {
        this.ingredient = ingr;

        var bareId = this.ingredient.getSomeKindOfReasonableIDForEmi();
        this.id = modLoc(bareId);
    }

    @Override
    public EmiStack copy() {
        return new BrainsweepeeEmiStack(this.ingredient);
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public NbtCompound getNbt() {
        return null;
    }

    @Override
    public Object getKey() {
        return id;
    }

    @Override
    public Identifier getId() {
        return id;
    }

    @Override
    public List<Text> getTooltipText() {
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean advanced = mc.options.advancedItemTooltips;

        return ingredient.getTooltip(advanced);
    }

    @Override
    public List<TooltipComponent> getTooltip() {
        return getTooltipText().stream()
            .map(Text::asOrderedText)
            .map(TooltipComponent::of)
            .collect(Collectors.toList());
    }

    @Override
    public Text getName() {
        return ingredient.getName();
    }

    @Override
    public void render(DrawContext graphics, int x, int y, float delta, int flags) {
        if ((flags & RENDER_ICON) != 0) {
            MinecraftClient mc = MinecraftClient.getInstance();
            ClientWorld level = mc.world;
            if (level != null) {
                var example = this.ingredient.exampleEntity(level);

                RenderSystem.enableBlend();
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                renderEntity(graphics, example, level, x + 8, y + 16, ClientTickCounter.getTotal(), 8, 0, it -> it);
            }
        }

//		if ((flags & RENDER_REMAINDER) != 0) {
//			EmiRender.renderRemainderIcon(this, poseStack, x, y);
//		}
    }
}
