package at.petrak.hexcasting.api.block.circle;

import at.petrak.hexcasting.api.casting.circles.ICircleComponent;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

// Convenience impl of ICircleComponent
public abstract class BlockCircleComponent extends Block implements ICircleComponent {
    public static final BooleanProperty ENERGIZED = BooleanProperty.of("energized");

    public BlockCircleComponent(Settings p_49795_) {
        super(p_49795_);
    }

    @Override
    public BlockState startEnergized(BlockPos pos, BlockState bs, World world) {
        var newState = bs.with(ENERGIZED, true);
        world.setBlockState(pos, newState);

        return newState;
    }

    @Override
    public boolean isEnergized(BlockPos pos, BlockState bs, World world) {
        return bs.get(ENERGIZED);
    }

    @Override
    public BlockState endEnergized(BlockPos pos, BlockState bs, World world) {
        var newState = bs.with(ENERGIZED, false);
        world.setBlockState(pos, newState);
        return newState;
    }

    /**
     * Which direction points "up" or "out" for this block?
     * This is used for {@link ICircleComponent#canEnterFromDirection(Direction, BlockPos, BlockState, ServerWorld)}
     * as well as particles.
     */
    public Direction normalDir(BlockPos pos, BlockState bs, World world) {
        return normalDir(pos, bs, world, 16);
    }

    abstract public Direction normalDir(BlockPos pos, BlockState bs, World world, int recursionLeft);

    public static Direction normalDirOfOther(BlockPos other, World world, int recursionLeft) {
        if (recursionLeft <= 0) {
            return Direction.UP;
        }

        var stateThere = world.getBlockState(other);
        if (stateThere.getBlock() instanceof BlockCircleComponent bcc) {
            return bcc.normalDir(other, stateThere, world, recursionLeft - 1);
        } else {
            return Direction.UP;
        }
    }

    /**
     * How many blocks in the {@link BlockCircleComponent#normalDir(BlockPos, BlockState, World)} from the center
     * particles should be spawned in
     */
    abstract public float particleHeight(BlockPos pos, BlockState bs, World world);

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> pBuilder) {
        pBuilder.add(ENERGIZED);
    }

    @Override
    public boolean hasComparatorOutput(BlockState pState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState pState, World pLevel, BlockPos pPos) {
        return pState.get(ENERGIZED) ? 15 : 0;
    }

    public static BlockState placeStateDirAndSneak(BlockState stock, ItemPlacementContext ctx) {
        var dir = ctx.getPlayerLookDirection();
        if (ctx.getPlayer() != null && ctx.getPlayer().isSneaky()) {
            dir = dir.getOpposite();
        }
        return stock.with(Properties.FACING, dir);
    }
}
