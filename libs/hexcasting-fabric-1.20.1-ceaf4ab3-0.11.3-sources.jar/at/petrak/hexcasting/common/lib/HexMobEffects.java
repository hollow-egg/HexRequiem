package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.common.misc.HexMobEffect;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.util.Identifier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexMobEffects {
    public static void register(BiConsumer<StatusEffect, Identifier> r) {
        for (var e : EFFECTS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<Identifier, StatusEffect> EFFECTS = new LinkedHashMap<>();

    public static final StatusEffect ENLARGE_GRID = make("enlarge_grid",
        new HexMobEffect(StatusEffectCategory.BENEFICIAL, 0xc875ff))
        .addAttributeModifier(HexAttributes.GRID_ZOOM, "d4afaf0f-df37-4253-9fa7-029e8e4415d9",
            0.25, EntityAttributeModifier.Operation.MULTIPLY_TOTAL);
    public static final StatusEffect SHRINK_GRID = make("shrink_grid",
        new HexMobEffect(StatusEffectCategory.HARMFUL, 0xc0e660))
        .addAttributeModifier(HexAttributes.GRID_ZOOM, "1ce492a9-8bf5-4091-a482-c6d9399e448a",
            -0.2, EntityAttributeModifier.Operation.MULTIPLY_TOTAL);


    private static <T extends StatusEffect> T make(String id, T effect) {
        var old = EFFECTS.put(modLoc(id), effect);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return effect;
    }
}
