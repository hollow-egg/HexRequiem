package at.petrak.hexcasting.client.model;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.render.entity.model.EntityModelLayer;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexRobesModels {
    // This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into
    // this model's constructor
    public static final EntityModelLayer LAYER_LOCATION = new EntityModelLayer(modLoc("robes"), "main");

    public static TexturedModelData variant1() {
        ModelData meshdefinition = new ModelData();
        ModelPartData partdefinition = meshdefinition.getRoot();

        ModelPartData Hood = partdefinition.addChild("Hood",
            ModelPartBuilder.create()
                .uv(0, 0).cuboid(-8.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, new Dilation(0.0F))
                .uv(0, 16).cuboid(-8.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, new Dilation(0.0F)),
            ModelTransform.pivot(4.0F, -8.0F, -4.0F));

        ModelPartData Horns = partdefinition.addChild("Horns",
            ModelPartBuilder.create()
                .uv(24, 0).cuboid(-8.0F, 0.0F, 0.0F, 8.0F, 4.0F, 0.0F, new Dilation(0.0F))
                .uv(24, 0).mirrored().cuboid(9.5F, 0.0F, 0.0F, 8.0F, 4.0F, 0.0F, new Dilation(0.0F))
                .mirrored(false),
            ModelTransform.pivot(-4.8F, -8.2F, 0.0F));

        ModelPartData Torso = partdefinition.addChild("Torso",
            ModelPartBuilder.create()
                .uv(40, 0).cuboid(-8.0F, 0.0F, 0.0F, 8.0F, 12.0F, 4.0F, new Dilation(0.0F))
                .uv(40, 16).cuboid(-8.0F, 0.0F, 0.0F, 8.0F, 12.0F, 4.0F, new Dilation(0.0F)),
            ModelTransform.pivot(4.0F, 0.0F, -2.0F));

        ModelPartData Arms = partdefinition.addChild("Arms",
            ModelPartBuilder.create()
                .uv(0, 32).cuboid(-4.0F, 0.0F, 0.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.0F))
                .uv(0, 32).mirrored().cuboid(8.0F, 0.0F, 0.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.0F))
                .mirrored(false),
            ModelTransform.pivot(-4.0F, 0.0F, -2.0F));

        ModelPartData Skirt = partdefinition.addChild("Skirt", ModelPartBuilder.create(),
            ModelTransform.pivot(0.0F, 12.0F, -2.0F));

        ModelPartData Left_r1 = Skirt.addChild("Left_r1",
            ModelPartBuilder.create()
                .uv(48, 32).mirrored().cuboid(0.1F, 0.0F, -4.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.0F))
                .mirrored(false),
            ModelTransform.of(0.0F, 0.0F, 4.0F, 0.0F, 0.0F, -0.1309F));

        ModelPartData Right_r1 = Skirt.addChild("Right_r1",
            ModelPartBuilder.create()
                .uv(48, 32).cuboid(-4.0F, 0.0F, -4.0F, 4.0F, 12.0F, 4.0F, new Dilation(0.0F)),
            ModelTransform.of(0.0F, 0.0F, 4.0F, 0.0F, 0.0F, 0.1309F));

        ModelPartData Legs = partdefinition.addChild("Legs",
            ModelPartBuilder.create().uv(16, 41)
                .cuboid(-4.0F, 0.0F, 0.0F, 4.0F, 3.0F, 4.0F, new Dilation(0.0F))
                .uv(16, 41).cuboid(0.0F, 0.0F, 0.0F, 4.0F, 3.0F, 4.0F, new Dilation(0.0F)),
            ModelTransform.pivot(0.0F, 21.0F, -2.0F));

        return TexturedModelData.of(meshdefinition, 64, 64);
    }
}