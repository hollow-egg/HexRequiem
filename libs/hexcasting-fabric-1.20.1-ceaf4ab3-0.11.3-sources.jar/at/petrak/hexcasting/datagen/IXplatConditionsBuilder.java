package at.petrak.hexcasting.datagen;

import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;

public interface IXplatConditionsBuilder extends CraftingRecipeJsonBuilder {
    IXplatConditionsBuilder whenModLoaded(String modid);

    IXplatConditionsBuilder whenModMissing(String modid);
}
