package at.petrak.hexcasting.fabric.xplat;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADHexHolder;
import at.petrak.hexcasting.api.addldata.ADIotaHolder;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.addldata.ADVariantItem;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.eval.sideeffects.EvalSound;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.eval.vm.ContinuationFrame;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.AltioraAbility;
import at.petrak.hexcasting.api.player.FlightAbility;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.common.lib.HexRegistries;
import at.petrak.hexcasting.common.msgs.IMessage;
import at.petrak.hexcasting.fabric.cc.CCAltiora;
import at.petrak.hexcasting.fabric.cc.CCBrainswept;
import at.petrak.hexcasting.fabric.cc.CCFavoredPigment;
import at.petrak.hexcasting.fabric.cc.CCFlight;
import at.petrak.hexcasting.fabric.cc.CCPatterns;
import at.petrak.hexcasting.fabric.cc.CCSentinel;
import at.petrak.hexcasting.fabric.cc.CCStaffcastImage;
import at.petrak.hexcasting.fabric.cc.HexCardinalComponents;
import at.petrak.hexcasting.fabric.interop.trinkets.TrinketsApiInterop;
import at.petrak.hexcasting.fabric.recipe.FabricUnsealedIngredient;
import at.petrak.hexcasting.interop.HexInterop;
import at.petrak.hexcasting.interop.pehkui.PehkuiInterop;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatTags;
import at.petrak.hexcasting.xplat.Platform;
import com.google.common.base.Suppliers;
import com.mojang.serialization.Lifecycle;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.core.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.loot.condition.AnyOfLootCondition;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.condition.MatchToolLootCondition;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registry;
import net.minecraft.registry.SimpleDefaultedRegistry;
import net.minecraft.registry.SimpleRegistry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import virtuoel.pehkui.api.ScaleTypes;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class FabricXplatImpl implements IXplatAbstractions {
    @Override
    public Platform platform() {
        return Platform.FABRIC;
    }

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public boolean isModPresent(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }

    @Override
    public void initPlatformSpecific() {
        if (this.isModPresent(HexInterop.Fabric.TRINKETS_API_ID)) {
            TrinketsApiInterop.init();
        }
    }

//    @Override
//    public double getReachDistance(Player player) {
//        return ReachEntityAttributes.getReachDistance(player, 5.0);
//    }

    @Override
    public void sendPacketToPlayer(ServerPlayerEntity target, IMessage packet) {
        ServerPlayNetworking.send(target, packet.getFabricId(), packet.toBuf());
    }

    @Override
    public void sendPacketNear(Vec3d pos, double radius, ServerWorld dimension, IMessage packet) {
        sendPacketToPlayers(PlayerLookup.around(dimension, pos, radius), packet);
    }

    @Override
    public void sendPacketTracking(Entity entity, IMessage packet) {
        sendPacketToPlayers(PlayerLookup.tracking(entity), packet);
    }

    private void sendPacketToPlayers(Collection<ServerPlayerEntity> players, IMessage packet) {
        var pkt = ServerPlayNetworking.createS2CPacket(packet.getFabricId(), packet.toBuf());
        for (var p : players) {
            p.networkHandler.sendPacket(pkt);
        }
    }

    @Override
    public Packet<ClientPlayPacketListener> toVanillaClientboundPacket(IMessage message) {
        return ServerPlayNetworking.createS2CPacket(message.getFabricId(), message.toBuf());
    }

    @Override
    public void setBrainsweepAddlData(MobEntity mob) {
        var cc = HexCardinalComponents.BRAINSWEPT.get(mob);
        cc.setBrainswept(true);
        // CC API does the syncing for us
    }

    @Override
    public @Nullable FrozenPigment setPigment(PlayerEntity target, @Nullable FrozenPigment pigment) {
        var cc = HexCardinalComponents.FAVORED_PIGMENT.get(target);
        var old = cc.getPigment();
        cc.setPigment(pigment);
        return old;
    }

    @Override
    public void setSentinel(PlayerEntity target, @Nullable Sentinel sentinel) {
        var cc = HexCardinalComponents.SENTINEL.get(target);
        cc.setSentinel(sentinel);
    }

    @Override
    public void setFlight(ServerPlayerEntity target, FlightAbility flight) {
        var cc = HexCardinalComponents.FLIGHT.get(target);
        cc.setFlight(flight);
    }

    public void setAltiora(PlayerEntity target, @Nullable AltioraAbility altiora) {
        var cc = HexCardinalComponents.ALTIORA.get(target);
        cc.setAltiora(altiora);
    }

    public void setStaffcastImage(ServerPlayerEntity target, CastingImage image) {
        var cc = HexCardinalComponents.STAFFCAST_IMAGE.get(target);
        cc.setImage(image);
    }

    @Override
    public void setPatterns(ServerPlayerEntity target, List<ResolvedPattern> patterns) {
        var cc = HexCardinalComponents.PATTERNS.get(target);
        cc.setPatterns(patterns);
    }

    @Override
    public boolean isBrainswept(MobEntity mob) {
        var cc = HexCardinalComponents.BRAINSWEPT.get(mob);
        return cc.isBrainswept();
    }

    @Override
    public @Nullable FlightAbility getFlight(ServerPlayerEntity player) {
        var cc = HexCardinalComponents.FLIGHT.get(player);
        return cc.getFlight();
    }

    @Override
    public @Nullable AltioraAbility getAltiora(PlayerEntity player) {
        var cc = HexCardinalComponents.ALTIORA.get(player);
        return cc.getAltiora();
    }

    @Override
    public FrozenPigment getPigment(PlayerEntity player) {
        var cc = HexCardinalComponents.FAVORED_PIGMENT.get(player);
        return cc.getPigment();
    }

    @Override
    public Sentinel getSentinel(PlayerEntity player) {
        var cc = HexCardinalComponents.SENTINEL.get(player);
        return cc.getSentinel();
    }

    @Override
    public CastingVM getStaffcastVM(ServerPlayerEntity player, Hand hand) {
        var cc = HexCardinalComponents.STAFFCAST_IMAGE.get(player);
        return cc.getVM(hand);
    }

    @Override
    public List<ResolvedPattern> getPatternsSavedInUi(ServerPlayerEntity player) {
        var cc = HexCardinalComponents.PATTERNS.get(player);
        return cc.getPatterns();
    }

    @Override
    public void clearCastingData(ServerPlayerEntity player) {
        this.setStaffcastImage(player, null);
        this.setPatterns(player, List.of());
    }

    @Override
    public @Nullable
    ADMediaHolder findMediaHolder(ItemStack stack) {
        var cc = HexCardinalComponents.MEDIA_HOLDER.maybeGet(stack);
        return cc.orElse(null);
    }

    @Override
    public @Nullable ADMediaHolder findMediaHolder(ServerPlayerEntity player) {
        var cc = HexCardinalComponents.MEDIA_HOLDER.maybeGet(player);
        return cc.orElse(null);
    }

    @Override
    public @Nullable
    ADIotaHolder findDataHolder(ItemStack stack) {
        var cc = HexCardinalComponents.IOTA_HOLDER.maybeGet(stack);
        return cc.orElse(null);
    }

    @Override
    public @Nullable
    ADIotaHolder findDataHolder(Entity entity) {
        var cc = HexCardinalComponents.IOTA_HOLDER.maybeGet(entity);
        return cc.orElse(null);
    }

    @Override
    public @Nullable
    ADHexHolder findHexHolder(ItemStack stack) {
        var cc = HexCardinalComponents.HEX_HOLDER.maybeGet(stack);
        return cc.orElse(null);
    }

    @Override
    public @Nullable ADVariantItem findVariantHolder(ItemStack stack) {
        var cc = HexCardinalComponents.VARIANT_ITEM.maybeGet(stack);
        return cc.orElse(null);
    }

    @Override
    public boolean isPigment(ItemStack stack) {
        return HexCardinalComponents.PIGMENT.isProvidedBy(stack);
    }

    @Override
    public ColorProvider getColorProvider(FrozenPigment pigment) {
        var cc = HexCardinalComponents.PIGMENT.maybeGet(pigment.item());
        return cc.map(col -> col.provideColor(pigment.owner())).orElse(ColorProvider.MISSING);
    }

    @Override
    public <T extends BlockEntity> BlockEntityType<T> createBlockEntityType(BiFunction<BlockPos, BlockState, T> func,
        Block... blocks) {
        return FabricBlockEntityTypeBuilder.create(func::apply, blocks).build();
    }

    @Override
    @SuppressWarnings("UnstableApiUsage")
    public boolean tryPlaceFluid(World level, Hand hand, BlockPos pos, Fluid fluid) {
        Storage<FluidVariant> target = FluidStorage.SIDED.find(level, pos, Direction.UP);
        if (target == null) {
            return false;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            long insertedAmount = target.insert(FluidVariant.of(fluid), FluidConstants.BUCKET, transaction);
            if (insertedAmount > 0) {
                transaction.commit();
                return true;
            }
        }
        return false;
    }

    @Override
    @SuppressWarnings("UnstableApiUsage")
    public boolean drainAllFluid(World level, BlockPos pos) {
        Storage<FluidVariant> target = FluidStorage.SIDED.find(level, pos, Direction.UP);
        if (target == null) {
            return false;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            boolean any = false;
            for (var view : target) {
                long extracted = view.extract(view.getResource(), view.getAmount(), transaction);
                if (extracted > 0) {
                    any = true;
                }
            }

            if (any) {
                transaction.commit();
                return true;
            }
        }
        return false;
    }

    @Override
    public Ingredient getUnsealedIngredient(ItemStack stack) {
        return FabricUnsealedIngredient.of(stack);
    }

    // do a stupid hack from botania
    private static List<ItemStack> stacks(Item... items) {
        return Stream.of(items).map(ItemStack::new).toList();
    }

    private static final List<List<ItemStack>> HARVEST_TOOLS_BY_LEVEL = List.of(
        stacks(Items.WOODEN_PICKAXE, Items.WOODEN_AXE, Items.WOODEN_HOE, Items.WOODEN_SHOVEL),
        stacks(Items.STONE_PICKAXE, Items.STONE_AXE, Items.STONE_HOE, Items.STONE_SHOVEL),
        stacks(Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_HOE, Items.IRON_SHOVEL),
        stacks(Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_HOE, Items.DIAMOND_SHOVEL),
        stacks(Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE, Items.NETHERITE_HOE, Items.NETHERITE_SHOVEL)
    );

    @Override
    public boolean isCorrectTierForDrops(ToolMaterial tier, BlockState bs) {
        if (!bs.isToolRequired()) {
            return true;
        }

        int level = HexConfig.server()
            .opBreakHarvestLevelBecauseForgeThoughtItWasAGoodIdeaToImplementHarvestTiersUsingAnHonestToGodTopoSort();
        for (var tool : HARVEST_TOOLS_BY_LEVEL.get(level)) {
            if (tool.isSuitableFor(bs)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public Item.Settings addEquipSlotFabric(EquipmentSlot slot) {
        return new FabricItemSettings().equipmentSlot(s -> slot);
    }

    private static final IXplatTags TAGS = new IXplatTags() {
        @Override
        public TagKey<Item> amethystDust() {
            return HexTags.Items.create(new Identifier("c", "amethyst_dusts"));
        }

        @Override
        public TagKey<Item> gems() {
            return HexTags.Items.create(new Identifier("c", "gems"));
        }
    };

    @Override
    public IXplatTags tags() {
        return TAGS;
    }

    @Override
    public LootCondition.Builder isShearsCondition() {
        return AnyOfLootCondition.builder(
            MatchToolLootCondition.builder(ItemPredicate.Builder.create().items(Items.SHEARS)),
            MatchToolLootCondition.builder(ItemPredicate.Builder.create().tag(
                HexTags.Items.create(new Identifier("c", "shears"))))
        );
    }

    @Override
    public String getModName(String namespace) {
        if (namespace.equals("c")) {
            return "Common";
        }
        Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(namespace);
        if (container.isPresent()) {
            return container.get().getMetadata().getName();
        }
        return namespace;
    }

    private static final Supplier<Registry<ActionRegistryEntry>> ACTION_REGISTRY = Suppliers.memoize(() ->
        FabricRegistryBuilder.from(new SimpleRegistry<>(
                HexRegistries.ACTION,
                Lifecycle.stable()))
            .buildAndRegister()
    );
    private static final Supplier<Registry<SpecialHandler.Factory<?>>> SPECIAL_HANDLER_REGISTRY =
        Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new SimpleRegistry<>(
                    HexRegistries.SPECIAL_HANDLER,
                    Lifecycle.stable()))
                .buildAndRegister()
        );
    private static final Supplier<Registry<IotaType<?>>> IOTA_TYPE_REGISTRY = Suppliers.memoize(() ->
        FabricRegistryBuilder.from(new SimpleDefaultedRegistry<>(
                HexAPI.MOD_ID + ":null", HexRegistries.IOTA_TYPE,
                Lifecycle.stable(), false))
            .buildAndRegister()
    );

    private static final Supplier<Registry<Arithmetic>> ARITHMETIC_REGISTRY = Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new SimpleRegistry<>(
                    HexRegistries.ARITHMETIC,
                    Lifecycle.stable()))
                .buildAndRegister()
    );

    private static final Supplier<Registry<ContinuationFrame.Type<?>>> CONTINUATION_TYPE_REGISTRY = Suppliers.memoize(() ->
            FabricRegistryBuilder.from(new SimpleDefaultedRegistry<>(
                            HexAPI.MOD_ID + ":end", HexRegistries.CONTINUATION_TYPE,
                            Lifecycle.stable(), false))
                    .buildAndRegister()
    );

    private static final Supplier<Registry<EvalSound>> EVAL_SOUNDS_REGISTRY = Suppliers.memoize(() ->
        FabricRegistryBuilder.from(new SimpleDefaultedRegistry<>(
                HexAPI.MOD_ID + ":nothing", HexRegistries.EVAL_SOUND,
                Lifecycle.stable(), false))
            .buildAndRegister()
    );

    @Override
    public Registry<ActionRegistryEntry> getActionRegistry() {
        return ACTION_REGISTRY.get();
    }

    @Override
    public Registry<SpecialHandler.Factory<?>> getSpecialHandlerRegistry() {
        return SPECIAL_HANDLER_REGISTRY.get();
    }

    @Override
    public Registry<IotaType<?>> getIotaTypeRegistry() {
        return IOTA_TYPE_REGISTRY.get();
    }

    @Override
    public Registry<Arithmetic> getArithmeticRegistry() {
        return ARITHMETIC_REGISTRY.get();
    }

    @Override
    public Registry<ContinuationFrame.Type<?>> getContinuationTypeRegistry() {
        return CONTINUATION_TYPE_REGISTRY.get();
    }

    @Override
    public Registry<EvalSound> getEvalSoundRegistry() {
        return EVAL_SOUNDS_REGISTRY.get();
    }

    @Override
    public boolean isBreakingAllowed(ServerWorld world, BlockPos pos, BlockState state, @Nullable PlayerEntity player) {
        if (player == null)
            player = FakePlayer.get(world, HEXCASTING);
        return PlayerBlockBreakEvents.BEFORE.invoker()
            .beforeBlockBreak(world, player, pos, state, world.getBlockEntity(pos));
    }

    @Override
    public boolean isPlacingAllowed(ServerWorld world, BlockPos pos, ItemStack blockStack, @Nullable PlayerEntity player) {
        if (player == null)
            player = FakePlayer.get(world, HEXCASTING);
        ItemStack cached = player.getMainHandStack();
        player.setStackInHand(Hand.MAIN_HAND, blockStack.copy());
        var success = UseItemCallback.EVENT.invoker().interact(player, world, Hand.MAIN_HAND);
        player.setStackInHand(Hand.MAIN_HAND, cached);
        return success.getResult() == ActionResult.PASS; // No other mod tried to consume this
    }

    private static PehkuiInterop.ApiAbstraction PEHKUI_API = null;

    @Override
    public PehkuiInterop.ApiAbstraction getPehkuiApi() {
        if (!this.isModPresent(HexInterop.PEHKUI_ID)) {
            throw new IllegalArgumentException("cannot get the pehkui api without pehkui");
        }

        if (PEHKUI_API == null) {
            PEHKUI_API = new PehkuiInterop.ApiAbstraction() {
                @Override
                public float getScale(Entity e) {
                    return ScaleTypes.BASE.getScaleData(e).getScale();
                }

                @Override
                public void setScale(Entity e, float scale) {
                    ScaleTypes.BASE.getScaleData(e).setScale(scale);
                }
            };
        }
        return PEHKUI_API;
    }

}
