package at.petrak.hexcasting.api.advancements;

import com.google.gson.JsonObject;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.advancement.criterion.AbstractCriterionConditions;
import net.minecraft.advancements.critereon.*;
import net.minecraft.predicate.entity.AdvancementEntityPredicateDeserializer;
import net.minecraft.predicate.entity.AdvancementEntityPredicateSerializer;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class FailToCastGreatSpellTrigger extends AbstractCriterion<FailToCastGreatSpellTrigger.Instance> {
    private static final Identifier ID = new Identifier("hexcasting", "fail_to_cast_great_spell");

    @Override
    public Identifier getId() {
        return ID;
    }

    @Override
    protected Instance conditionsFromJson(JsonObject json, LootContextPredicate predicate, AdvancementEntityPredicateDeserializer context) {
        return new Instance(predicate);
    }

    public void trigger(ServerPlayerEntity player) {
        super.trigger(player, e -> true);
    }

    public static class Instance extends AbstractCriterionConditions {
        public Instance(LootContextPredicate predicate) {
            super(ID, predicate);
        }

        @Override
        public Identifier getId() {
            return ID;
        }

        public JsonObject toJson(AdvancementEntityPredicateSerializer pConditions) {
            return new JsonObject();
        }
    }
}
